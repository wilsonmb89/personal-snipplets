// Modules
import { NgModule } from '@angular/core';
import { MaterialModule } from './material/material.module';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BpmService } from './shared/services/bpm.service';

// Components
import { AppComponent } from './app.component';
import { LogoutComponent } from './shared/components/logout/logout.component';

// Services
import { CatalogosServiceService } from './shared/services/catalogos-service.service';
import { InterceptorService } from './shared/services/interceptor.service';
import { EncryptInterceptorService } from './shared/services/encrypt-inteceptor.service';
import { HttpErrorInterceptorService } from './shared/services/http-errors-interceptor.service';
import { HttpClientService } from './shared/services/HttpClient.service';
import { IndexedDBService } from './shared/services/indexedDB.service';
import { AuthGuardService } from './shared/services/auth-guard.service';
import { Transformation } from './shared/functions/util/Trasnformation';

// Functions
import { TimerClass } from './shared/functions/timer';
import { Encryption } from './shared/functions/encryption';
import { LogOutUtil } from './shared/functions/logout';

@NgModule({
  declarations: [
    AppComponent,
    LogoutComponent
  ],
  imports: [
    AppRoutingModule,
    MaterialModule,
    SharedModule,
    HttpClientModule,
    BrowserAnimationsModule,
    BrowserModule
  ],
  providers: [
    CatalogosServiceService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: EncryptInterceptorService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptorService,
      multi: true
    },
    HttpClientService,
    TimerClass,
    Encryption,
    LogOutUtil,
    BpmService,
    IndexedDBService,
    AuthGuardService,
    Transformation
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
