import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { Router } from "@angular/router";
import { CreatePdfService } from "../../../shared/services/create-pdf.service";
import { BpmService } from "../../../shared/services/bpm.service";
import { POMapping } from "../../functions/mapping/POMapping";
import { AppComponent } from "../../../app.component";
import { DataWrapper } from "../../../shared/models/formatos/DataWrapper";
import { AutoflowService } from '../../../shared/services/autoflow.service';
import { Transformation } from '../../../shared/functions/util/Trasnformation';
import { NOMBRES_ARCHIVOS } from '../../../shared/constants/codigosServicios.constant';

@Component({
  selector: "app-generic-modal",
  templateUrl: "./generic-modal.component.html",
  styleUrls: ["./generic-modal.component.scss"]
})
export class GenericModalComponent implements OnInit {
  @Input()
  public finalizarTarea: any;
  @Input()
  public bodyPdf: any;
  @Input()
  public data: any;
  @Input()
  public noFinalizarTarea: boolean;
  @Output() supportClicked: EventEmitter<boolean> = new EventEmitter<boolean>();

  public instanceId: string;
  public taskId: string;
  public enableClose = false;
  public isLoadingActive = false;
  public datosFlujoVP: any;
  public modalIsShowed;
  public poMapping: POMapping;

  constructor(
    private router: Router,
    private _pdfService: CreatePdfService,
    private _bpmService: BpmService,
    private app: AppComponent,
    private _autoflow: AutoflowService,
    private transformation: Transformation
  ) {
    this.poMapping = new POMapping();
  }

  ngOnInit() {
    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");
    this.datosFlujoVP = JSON.parse(sessionStorage.getItem("datosFlujo"));
    if (this.datosFlujoVP) {
      if (this.datosFlujoVP.imprimirPDF) {
        this.enableClose = true;
      }
    }
  }

  restrictList() {
    console.log(this.instanceId);
    this.router.navigate(["portal/bandeja-tareas"]);
  }

  generatePdf() {
    this.isLoadingActive = true;
    const dataWrapper = new DataWrapper("co.itau.apiformatos.adapter.pdfAdapter.impl.DataAdapterVinculacionImpl",  JSON.stringify(this.bodyPdf));
    this._pdfService.createPDF(dataWrapper).then(
      res => {
        console.log("Fomrulario Vinculacion: Response Generar PDF");
        console.log(res);
        const file = this.transformation.base64ToBlob(res.body, 'application/pdf');
        console.log(file);
        const fileURL = URL.createObjectURL(file);
        window.open(fileURL);
        // this.transformation.createAndDownloadBlobFile(file, NOMBRES_ARCHIVOS.VINCULACION);
        this.enableClose = true;
        this.isLoadingActive = false;
      },
      err => {
        console.log("Fomrulario Vinculacion: Error Generar PDF");
        console.error(err);
        this.isLoadingActive = false;
      }
    );
  }

  goToInbox() {
    console.log("INSTANCIA: " + this.instanceId);
    console.log("TASK: " + this.taskId);
    this.isLoadingActive = true;
    this._bpmService.endTask(this.finalizarTarea).then(
      res => {
        console.log("Generic Modal goToInbox(): Response finalizar actividad");
        console.log(res);
        this.app.global.id = "";
        this.app.global.showId = false;
        this.router.navigate(["portal/bandeja-tareas"]);
      },
      err => {
        console.log("Generic Modal goToInbox(): Error finalizar actividad");
        console.error(err);
        this.isLoadingActive = false;
      }
    );
  }

  goToCreateProduct() {
    console.log("INSTANCIA: " + this.instanceId);
    console.log("TASK: " + this.taskId);
    this.isLoadingActive = true;
    this._bpmService.endTask(this.finalizarTarea).then(
      res => {
        console.log("Generic Modal goToInbox(): Response finalizar actividad");
        console.log(res);
        this.app.global.id = "";
        this.app.global.showId = false;
        this._autoflow.nextPage(this.instanceId);
      },
      err => {
        console.log("Generic Modal goToInbox(): Error finalizar actividad");
        console.error(err);
        this.isLoadingActive = false;
      }
    );
  }

  closeProcess() {
    if (!this.noFinalizarTarea) {
      this.isLoadingActive = true;
      this._bpmService.endTask(this.finalizarTarea).then(
        res => {
          console.log("Notificar Rechazo Cliente: Response finalizar actividad");
          console.log(res);
        },
        err => {
          console.log("Notificar Rechazo Cliente: Error finalizar actividad");
          console.error(err);
          this.isLoadingActive = false;
        }
      );
    }
    sessionStorage.removeItem("instanceId");
    sessionStorage.removeItem("taskId");
    this.app.global.id = "";
    this.app.global.showId = false;
    this.router.navigate(["portal/bandeja-tareas"]);
  }

  support(value: boolean) {
    value = false;
    this.supportClicked.emit(value);
  }
}
