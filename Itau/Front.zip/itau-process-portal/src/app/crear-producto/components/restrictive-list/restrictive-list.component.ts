import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, HostListener } from '@angular/core';
import { SolicitudesServiceService } from "../../../shared/services/solicitudes-service.service";
import { ActivatedRoute, Router } from '@angular/router';
import { Solicitud } from '../../models/negocio/Solicitud';
import { BpmService } from '../../../shared/services/bpm.service';
import { FinalizarTarea } from '../../../shared/models/request/FinalizarTarea';
import { POMapping } from '../../functions/mapping/POMapping';
import { AppComponent } from "../../../app.component";
import { Transformation } from '../../../shared/functions/util/Trasnformation';
import { SolicitudListaRestrictivaSORMapping } from '../../functions/mapping/SolicitudListaRestrictivaSORMapping';
import { EventService } from '../../../shared/services/eventos.service';
import { EventMessage } from '../../../shared/models/eventos/message-eventos';
import { EVENT_MESSAGE_CONSTANTS, LEVEL, KEYS_INFORMACION_ADICIONAL_EVENTOS } from '../../../shared/constants/mensaje-eventos-constant';


@Component({
  selector: 'app-restrictive-list',
  templateUrl: './restrictive-list.component.html',
  styleUrls: ['./restrictive-list.component.scss']
})
export class RestrictiveListComponent implements OnInit {
  instanceId: string;
  taskId: string;
  public solicitud: Solicitud;
  public finalizarTarea: FinalizarTarea;
  public restrictiveListForm: FormGroup;
  public isLoadingActive = false;
  public nameOrId = false;
  public messageEvent: EventMessage;
  private OPERATION_EVENT_NAME = "decisionCumplimiento";
  public listsorMapping: SolicitudListaRestrictivaSORMapping;
  public poMapping: POMapping;
  public isSticky = false;

  constructor(
    private _solicitudesService: SolicitudesServiceService,
    private activatedRoute: ActivatedRoute,
    private _bpmService: BpmService,
    private router: Router,
    private app:  AppComponent,
    private transformation: Transformation,
    private _eventosService: EventService

  ) {
    window.scroll(0, 0);
    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");

    this.app.global.nombre = sessionStorage.getItem("fullname");
    this.app.global.id = sessionStorage.getItem("instanceId");
    this.app.global.showHeader = true;
    this.app.global.showId = true;
    this.listsorMapping = new SolicitudListaRestrictivaSORMapping();
    this.poMapping = new POMapping();
    this.app.global.scrollHide = true;
   }

   @HostListener('window:scroll', ['$event'])
   checkScroll() {
     this.isSticky = window.pageYOffset >= 10;
   }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
    });
    this._solicitudesService.getByInstanceId(this.instanceId).then(
      result => {
        if (!!result.body) {
          console.log("RESULTADO");
          console.log(result.body);
          this.solicitud = result.body;
        } else {
          console.warn("Listas restrictivas: Obtener Solicitud - No Hay Resultados");
        }
      },
      err => {
        console.log("Listas restrictivas: Error Obtener Solicitud");
        console.log(err);
      });

      this.restrictiveListForm = new FormGroup({
        respuestaCumplimientoControl: new FormControl('', [Validators.required, Validators.maxLength(200)]),
        causalCumplimientoControl: new FormControl('', [Validators.required, Validators.maxLength(1000)])
      });

      this.messageEvent = new EventMessage();
  }

  onSubmit() {
    const body = this.listsorMapping.mappingSolicitudListasRestrictivas(this.restrictiveListForm, this.solicitud);
    this.isLoadingActive = true;
    this._solicitudesService.createOrUpdate(body).then(
      res => {
        console.log("Listas restrictivas: Response guardado SOR");
        console.log(res);
        this.solicitud = res.body;
        const respuesta = this.transformation.changeTrueFalse(this.restrictiveListForm.get("respuestaCumplimientoControl").value);
        this.finalizarTarea = this.poMapping.mappingValidarConceptoCumplimientoPO(this.taskId, respuesta);

        const fullname = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido;
        const informacionBasica = {};
        informacionBasica[KEYS_INFORMACION_ADICIONAL_EVENTOS.NOMBRE] = fullname;
        informacionBasica[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_IDENTIFICACION] = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion;
        informacionBasica[KEYS_INFORMACION_ADICIONAL_EVENTOS.TIPO_IDENTIFICACION] = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion;

        const radicador = {};
        radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.USUARIO] = this.solicitud.datosSolicitud.radicador.usuarioRadicador;
        radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.NOMBRE] = this.solicitud.datosSolicitud.radicador.nombreRadicador;
        radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_IDENTIFICACION] = this.solicitud.datosSolicitud.radicador.numeroIdentificacion;
        radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.CODIGO_OFICINA] = this.solicitud.datosSolicitud.radicador.codOficina;

        let nombrelistas = "";
        if (!!this.solicitud.datosSolicitud.personaNatural[0].consultarListas && !!this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados
            && this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados.length > 0) {
              for (let idx = 0; idx < this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados.length; idx++) {
                  if (!!this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados[idx].listName) {
                    if (nombrelistas.search(this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados[idx].listName) === -1) {
                      if (idx === 0) {
                        nombrelistas = this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados[idx].listName;
                      } else {
                        nombrelistas = nombrelistas + "-" + this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados[idx].listName;
                      }
                    }
                  }
              }
        }

        let esPep = false;
        if (!!this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto) {
          if (this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.pep === "S") {
              if (nombrelistas.length === 0) {
                  nombrelistas = "MARCACION-FORMULARIO";
              } else {
                nombrelistas = nombrelistas + "-" + "MARCACION-FORMULARIO";
              }
              esPep = true;
          } else if (this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.mrp === "S" ||
                      this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.prp === "S" ||
                      this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.familiarPep === "S") {
                        if (nombrelistas.length === 0) {
                          nombrelistas = "MARCACION-FORMULARIO";
                        } else {
                          nombrelistas = nombrelistas + "-" + "MARCACION-FORMULARIO";
                        }
          }
        }

        if (!esPep) {
          if (this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados.length > 0) {
            for (let idx = 0; idx < this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados.length; idx++) {
              if (/PEP/gm.test(this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados[idx].detail)) {
                esPep = true;
                break;
              }
            }
          }
        }

        const messageBody = {};
        messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_SOLICITUD] = this.solicitud.numeroSolicitud;
        messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.RESPUESTA] = this.restrictiveListForm.get("respuestaCumplimientoControl").value;
        messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.CAUSAL] = this.restrictiveListForm.get("causalCumplimientoControl").value;
        messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.LISTAS_RESTRICTIVAS] = nombrelistas;
        messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.PEP] = esPep ? "S" : "N";
        messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.INFORMACION_BASICA] = informacionBasica;
        messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.RADICADOR] = radicador;

        this.messageEvent.api = EVENT_MESSAGE_CONSTANTS.API;
        this.messageEvent.level = LEVEL.TRACKINGPOINT;
        this.messageEvent.operation = this.OPERATION_EVENT_NAME;
        this.messageEvent.messageBody = messageBody;
        console.log(this.messageEvent);
        this._eventosService.sendEvent(this.messageEvent).then(
          res => {
            console.log("Listas restrictivas: Response enviar evento");
            console.log("RESPUESTA");
            console.log(res);
          },
          error => {
            console.log("Listas restrictivas: Error enviar evento");
            console.log(error);
          }
        );
        this._bpmService.endTask(this.finalizarTarea).then(
          res => {
            console.log("Listas restrictivas: Response Finalizar Actividad");
            console.log("RESPUESTA");
            console.log(res);
            this.app.global.id = "";
            this.app.global.showId = false;
            this.router.navigate(["portal/bandeja-tareas"]);
          },
          err => {
            console.log("Listas restrictivas: Error Finalizar Actividad");
            console.log(err);
            this.isLoadingActive = false;
          }
        );
      },
      err => {
        console.log("Listas restrictivas: Error guardado SOR");
        console.log(err);
        this.isLoadingActive = false;
      });
  }

  get formIsInValid(): boolean {
    return this.restrictiveListForm.invalid;
  }
}
