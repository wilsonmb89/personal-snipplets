import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestrictiveListComponent } from './restrictive-list.component';

describe('RestrictiveListComponent', () => {
  let component: RestrictiveListComponent;
  let fixture: ComponentFixture<RestrictiveListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestrictiveListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestrictiveListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
