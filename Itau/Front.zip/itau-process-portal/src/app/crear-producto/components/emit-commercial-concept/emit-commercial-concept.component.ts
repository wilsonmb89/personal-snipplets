import { Component, OnInit } from '@angular/core';
import { SolicitudesServiceService } from "../../../shared/services/solicitudes-service.service";
import { ActivatedRoute, Router } from "@angular/router";
import { Solicitud } from '../../models/negocio/Solicitud';
import { BpmService } from '../../../shared/services/bpm.service';
import { FinalizarTarea } from '../../../shared/models/request/FinalizarTarea';
import { POMapping } from '../../functions/mapping/POMapping';
import { AppComponent } from "../../../app.component";

@Component({
  selector: 'app-emit-commercial-concept',
  templateUrl: './emit-commercial-concept.component.html',
  styleUrls: ['./emit-commercial-concept.component.scss']
})
export class EmitCommercialConceptComponent implements OnInit {
  instanceId: string;
  taskId: string;
  public solicitud: Solicitud;
  public finalizarTarea: FinalizarTarea;
  public isLoadingActive = false;
  public poMapping: POMapping;

  constructor(
    private _solicitudesService: SolicitudesServiceService,
    private activatedRoute: ActivatedRoute,
    private _bpmService: BpmService,
    private router: Router,
    private app: AppComponent,
  ) {
    window.scroll(0, 0);
    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");
    this.app.global.nombre = sessionStorage.getItem("fullname");
    this.app.global.id = sessionStorage.getItem("instanceId");
    this.app.global.showHeader = true;
    this.app.global.showId = true;
    this.poMapping = new POMapping();
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
    });
    this._solicitudesService.getByInstanceId(this.instanceId).then(
      result => {
        if (!!result.body) {
          console.log("Emitir Concepto Comercial: consulta SOR");
          console.log(result);
          this.solicitud = result.body;
        } else {
          console.warn("Emitir Concepto Comercial: Consulta SOR - No hay Resultados");
        }
      },
      err => {
        console.log("Emitir Concepto Comercial: error consulta SOR");
        console.log(err);
      });
  }

  onSubmit() {
    this.isLoadingActive = true;
    this.finalizarTarea = this.poMapping.mappingGenericPO(this.taskId);
    this._bpmService.endTask(this.finalizarTarea).then(
      res => {
        console.log("Emitir Concepto Comercial: Response Finalizar Actividad");
        console.log(res);
        this.app.global.id = "";
        this.app.global.showId = false;
        this.router.navigate(["portal/bandeja-tareas"]);
        this.isLoadingActive = false;
      },
      err => {
        console.log("Emitir Concepto Comercial: Error Finalizar Actividad");
        console.log(err);
        this.isLoadingActive = false;
      });
  }
}
