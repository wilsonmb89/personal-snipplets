import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EmitCommercialConceptComponent } from './emit-commercial-concept.component';


describe('RestrictiveListDirectorComponent', () => {
  let component: EmitCommercialConceptComponent;
  let fixture: ComponentFixture<EmitCommercialConceptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmitCommercialConceptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmitCommercialConceptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
