import { SERVICE_RESPONSE, REJECT_USER } from "../../../shared/constants/modals.constant";
import { AutoflowService } from '../../../shared/services/autoflow.service';
import { Component, OnInit, HostListener } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { SolicitudesServiceService } from "../../../shared/services/solicitudes-service.service";
import { BpmService } from "../../../shared/services/bpm.service";
import { FinalizarTarea } from "../../../shared/models/request/FinalizarTarea";
import { ConsultaListasService } from "../../services/consulta-listas.service";
import { ConsultaListasMapping } from "../../functions/mapping/ConsultaListasMapping";
import { ConsultarClienteSORMapping } from "../../functions/mapping/ConsultarClienteSORMapping";
import { LLAVES_SOR } from "../../constants/LlavesSOR.constant";
import { POMapping } from "../../functions/mapping/POMapping";
import { Solicitud } from "../../models/negocio/Solicitud";
import { AppComponent } from '../../../app.component';
import { CatalogosServiceService } from "../../../shared/services/catalogos-service.service";
import { LLAVES_NOTIFICATION, CODIGO_NOTIFICACION, REQUEST_SEND_EMAIL_NOTIFICATION, FINISH_TASK_ENRUTAMIENTO, ID_SERVICE_BPM, RESPONSE_CONSULTA_CLIENTE } from '../../../shared/constants/codigosServicios.constant';
import { NotificationMapping } from '../../../shared/functions/mapping/NotificationMapping';
import { NotificationService } from '../../../shared/services/Notification.service';
import { environment } from '../../../../environments/environment';
import { ConsultaClienteService } from '../../services/consulta-cliente.service';
import { ConsultaClienteMapping } from '../../functions/mapping/ConsultaClienteMapping';
import { IniciarServicio } from '../../../shared/models/bpm/iniciarServicio';

@Component({
  selector: "app-consult-client",
  templateUrl: "./consult-client.component.html",
  styleUrls: ["./consult-client.component.scss"]
})
export class ConsultClientComponent implements OnInit {
  public isLoadingActive = false;
  public taskId: string;
  public instanceId: string;
  public totalResultados;
  public resultados;
  public listaRechazo = [];
  public listasRestrictivas = true;
  public finalizarTarea: FinalizarTarea;
  public listQueryForm: FormGroup;
  public documentValidForm: FormGroup;
  public modalIsShowed = false;
  public formErrorMsg = {};
  public body: Solicitud;
  public dataModal: any = {
    imagen: SERVICE_RESPONSE.imagen,
    principalText: SERVICE_RESPONSE.principalText,
    buttonText1: SERVICE_RESPONSE.buttonText1,
    button: SERVICE_RESPONSE.button,
    class: SERVICE_RESPONSE.class
  };

  public user: any = {
    documentId: "",
    firstLastname: "",
    secondLastname: "",
    name: ""
  };
  public sorMapping: ConsultarClienteSORMapping;
  public poMapping: POMapping;
  public consultaListasMapping: ConsultaListasMapping;
  public notificationMapping: NotificationMapping;
  public consultaClienteMapping: ConsultaClienteMapping;
  public solicitud: Solicitud;
  public noFinalizarTarea = false;
  public isSticky = false;
  public tipoDocCatalog: Array<any> = [];
  public codigosDocumento = ["1", "2", "3", "4", "5", "7", "11", "17", "24"]; // Codigos establecidos a mostrar en el menu de seleccion
  public tipoDocCatalogCedula;
  public customerInformation: any;
  public datosAdicionales: any;
  public datosBasicos: any;
  public nombre: string;
  public estadoCliente: string;
  public marcacionCore = false;
  public activePaddinBtn = false;
  public ciudades: any[];

  togglePepControlFocus = false;
  toggleMrpControlFocus = false;
  togglePrpControlFocus = false;
  toggleFamiliarPepControlFocus = false;

  constructor(
    private router: Router,
    private _service: SolicitudesServiceService,
    private _bpmService: BpmService,
    private _listService: ConsultaListasService,
    private _consultClient: ConsultaClienteService,
    private _catalogos: CatalogosServiceService,
    private app: AppComponent,
    private _autoflow: AutoflowService,
    private _notificationService: NotificationService,
  ) {
    this.app.global.nombre = sessionStorage.getItem("fullname");
    this.app.global.id = sessionStorage.getItem("instanceId");
    this.app.global.showHeader = true;
    this.app.global.scrollHide = true;
    this.app.global.showId = true;
    window.scroll(0, 0);
    this.sorMapping = new ConsultarClienteSORMapping();
    this.poMapping = new POMapping();
    this.consultaListasMapping = new ConsultaListasMapping();
    this.notificationMapping = new NotificationMapping();
    this.consultaClienteMapping = new ConsultaClienteMapping();
  }

  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    this.isSticky = window.pageYOffset >= 10;
  }

  ngOnInit(): void {
    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");
    this.getDocumentTYpe();

    this.listQueryForm = new FormGroup({
      documentId: new FormControl("", [Validators.required, Validators.maxLength(10), Validators.pattern("^(0|[1-9][0-9]*)$")]),
      typeId: new FormControl(''),
      name: new FormControl("", [Validators.required, Validators.maxLength(60)]),
      fullName: new FormControl(""),
      firstLastname: new FormControl("", [Validators.required, Validators.maxLength(40)]),
      secondLastname: new FormControl("", [Validators.maxLength(40)]),
      pepControl: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      prpControl: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      mrpControl: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      comentarioPepPrpMrpControl: new FormControl('', [Validators.maxLength(200)]),
      familiarPepControl: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      comentarioFamiliarPepControl: new FormControl('', [Validators.maxLength(200)])
    });

    this._catalogos.loadCatalog("LISTA_RECHAZO_AUTOMATICO").then(
      resCatalog => {
        this.listaRechazo = resCatalog.body;
      },
      err => {
        console.log("Consultar cliente: Error consulta de Catalogo Rechazo de Listas");
        console.error(err);
      }
    );

    this.getCiudades();

    this._service.getByInstanceId(this.instanceId).then(
      res => {
        if (!!res.body) {
          this.solicitud = res.body;
        } else {
          console.warn("Consultar cliente: Consulta SOR - No Hay Resultados");
        }
      }, err => {
        console.error("Consultar cliente: Error consulta SOR");
        console.error(err);
      }
    );
  }

  buscarCliente() {
    this.isLoadingActive = true;
    this.estadoCliente = "";
    this.resetFormGroup();
    const body: any = this.consultaClienteMapping.fillRequestConsultaCliente(this.listQueryForm);
    this._consultClient.consult(body).then(
      res => {
        this.customerInformation = res.body;
        if (!!this.customerInformation.getCustomerDataRsType.party) {
          if (this.customerInformation.getCustomerDataRsType.headerResponse.status.statusDesc === RESPONSE_CONSULTA_CLIENTE.CLIENTE_NO_EXISTE) {
            this.estadoCliente = "NO EXISTE";
          } else {
            if (!!this.customerInformation.getCustomerDataRsType.party.partyStatus) {
              this.estadoCliente = !!this.customerInformation.getCustomerDataRsType.party.partyStatus.statusDesc ? this.customerInformation.getCustomerDataRsType.party.partyStatus.statusDesc.toUpperCase() : "";
            }
            this.listQueryForm = this.consultaClienteMapping.fillFormGruopConsultaCliente(this.customerInformation, this.listQueryForm);
            this.marcacionCore = (this.listQueryForm.get("pepControl").value === "S" || this.listQueryForm.get("mrpControl").value === "S") ? true : false;
            if (this.estadoCliente === "CERRADO" || this.estadoCliente === "RESTRINGID" || this.estadoCliente === "FALLECIDO" || this.estadoCliente === "PEND" || this.estadoCliente === "INACTIVO") {
              this.estadoCliente = "BLOQUEADO";
              const fullname = this.listQueryForm.get("fullName").value;
              this.dataModal = {
                imagen: REJECT_USER.imagen,
                principalText: REJECT_USER.principalText,
                secondaryText: fullname + " | C.C. " + this.listQueryForm.get("documentId").value,
                otherText: "Cliente en estado " +  this.customerInformation.getCustomerDataRsType.party.partyStatus.statusDesc.toUpperCase() + " Valide el estado del cliente para poder continuar",
                buttonPdf: REJECT_USER.buttonPdf,
                buttonText1: "Listo",
                button: REJECT_USER.button,
                buttonCloseProcess: REJECT_USER.buttonCloseProcess,
                class: REJECT_USER.class
              };
              this.modalIsShowed = true;
              this.listQueryForm.get('fullName').disable();
              this.finalizarTarea = this.poMapping.mappingConsultarClientePO(this.taskId, null, this.listQueryForm, FINISH_TASK_ENRUTAMIENTO.RECHAZO_CLIENTE_BLOQUEADO);
            } else {
              this.estadoCliente = "EXISTE";
              this.listQueryForm.get('fullName').disable();
            }
          }
        } else {
          this.estadoCliente = "NO EXISTE";
          this.listQueryForm.get('fullName').disable();
        }
        this.activePaddinBtn = true;
        this.isLoadingActive = false;
      },
      err => {
        this.isLoadingActive = false;
        console.log('Consultar listas: Error Consultar Cliente');
        console.error(err);
      }
    );
  }

  onSubmit(): void {
    this.isSticky = window.pageYOffset >= 50;
    this.isLoadingActive = true;

    if (this.estadoCliente !== "BLOQUEADO") {
      const listBody: any = this.consultaListasMapping.fillRequestConsultaListas(this.listQueryForm);
      this._listService.validateList(listBody).then(
        res => {
          console.log("Consultar cliente: Response integracion listas restrictivas");
          const resBody = res.body;
          const coincidencia = [];
          console.log(resBody);

          if (!!resBody.matches && !!resBody.matches.match) {
            resBody.matches.match.forEach(match => {
              if (!!match.matchDetail && match.matchDetail.length > 0) {
                match.matchDetail.forEach(matchDetail => {
                  const isEmpty = Object.values(matchDetail).every(x => (x === null));
                  if (!isEmpty) {
                    coincidencia.push(matchDetail);
                  }
                });
              }
            });
          }

          this.totalResultados = !!resBody && !!resBody.matches && !!resBody.matches.matchedRec ? resBody.matches.matchedRec : 0;
          this.resultados = !!resBody && !!coincidencia && coincidencia.length > 0 ? coincidencia : [];
          const datos: Map<string, any> = new Map<string, any>();
          datos.set(LLAVES_SOR.RESULTADOS_LISTAS_RESTRICTIVAS, this.resultados);
          datos.set(LLAVES_SOR.TOTAL_RESULTADOS_LISTAS_RESTRICTIVAS, this.totalResultados);
          this.body = this.sorMapping.mappingConsultarCliente(this.listQueryForm, datos, this.solicitud, this.customerInformation, this.estadoCliente, this.ciudades);

          this._service.update(this.body).then(
            res => {
              console.log("Consultar cliente: Response guardado SOR");
              console.log(res);
              this.solicitud = res.body;

              let marcacionPantalla = false;
              if (this.listQueryForm.get("pepControl").value === "S" ||
                this.listQueryForm.get("prpControl").value === "S" ||
                this.listQueryForm.get("mrpControl").value === "S" ||
                this.listQueryForm.get("familiarPepControl").value === "S") {
                marcacionPantalla = true;
              }

              let marcacionListas = false;
              let marcacionOtrasListas = false;
              if (this.resultados.length > 0) {
                for (let idx = 0; idx < this.resultados.length; idx++) {
                  if (/PEP/gm.test(this.resultados[idx].detail) ||
                    /MRP/gm.test(this.resultados[idx].detail) ||
                    /PRP/gm.test(this.resultados[idx].detail)) {
                    marcacionListas = true;
                  } else {
                    marcacionOtrasListas = true;
                  }
                }
              }

              let clienteRechazadoListas = false;
              this.listaRechazo.forEach(name => {
                this.resultados.forEach(list => {
                  if (list.detail.includes(name.valor) && list.matchPercent === 100 && list.matchedValue === this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion) {
                    clienteRechazadoListas = true;
                  }
                });
              });

              const estadoCliente = this.estadoCliente === "EXISTE" ? true : false;

              const bodyStartService = new IniciarServicio();
              bodyStartService.idService = ID_SERVICE_BPM.GS_ENRUTAMIENTO_VINCULACION;
              const parameters = {
                marcaCorePhoenix: this.marcacionCore,
                marcaListasRestrictivas: marcacionListas,
                marcaSafeWatchOtros: marcacionOtrasListas,
                marcaPantalla: marcacionPantalla,
                rechazoAutomatico: clienteRechazadoListas,
                estadoCliente: estadoCliente
              };
              bodyStartService.parameters = JSON.stringify(parameters);

              this._bpmService.startService(bodyStartService).then(
                result => {
                  const respuestaEnrutamiento = result.body.body.data.data.respuestaEnrutamiento;
                  this.finalizarTarea = this.poMapping.mappingConsultarClientePO(this.taskId, this.solicitud, this.listQueryForm, respuestaEnrutamiento);
                  this._bpmService.endTask(this.finalizarTarea).then(
                    res => {
                      console.log("Consultar cliente: Response finalizar actividad");
                      console.log(res);
                      this.app.global.id = "";
                      this.app.global.showId = false;

                      if (respuestaEnrutamiento.search(FINISH_TASK_ENRUTAMIENTO.RECHAZO_AUTOMATICO) !== -1) {
                        const fullname = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido;
                        this.dataModal = {
                          imagen: REJECT_USER.imagen,
                          principalText: REJECT_USER.principalText,
                          secondaryText: fullname + " | C.C. " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion,
                          otherText: REJECT_USER.otherText,
                          buttonPdf: REJECT_USER.buttonPdf,
                          buttonText1: REJECT_USER.buttonText1,
                          button: REJECT_USER.button,
                          buttonCloseProcess: REJECT_USER.buttonCloseProcess,
                          class: REJECT_USER.class
                        };
                        this.noFinalizarTarea = true;
                        this.isLoadingActive = false;
                        this.modalIsShowed = true;
                      } else if (respuestaEnrutamiento.search(FINISH_TASK_ENRUTAMIENTO.VINCULACION_ACTUALIZACION) !== -1) {
                        this._autoflow.nextPage(this.instanceId);
                      } else if (respuestaEnrutamiento.search(FINISH_TASK_ENRUTAMIENTO.CUMPLIMIENTO) !== -1) {
                        this.isLoadingActive = false;
                        this.modalIsShowed = true;

                        /* TODO Esta invocacion de servicio deberia ir mas adelante en el BPM
                            @author EDA01779
                        */
                        const datosEmail = {};
                        datosEmail[LLAVES_NOTIFICATION.NUMERO_SOLICITUD] = this.solicitud.numeroSolicitud;
                        const bodyEmailNotification = this.notificationMapping.mappingSendEmailNotification(CODIGO_NOTIFICACION.EMAIL_CUMPLIMIENTO,
                          REQUEST_SEND_EMAIL_NOTIFICATION.GENERIC_SUBJECT_INTER,
                          environment.emailAddressCumplimiento, datosEmail);

                        this._notificationService.sendEmailNotification(bodyEmailNotification).then(
                          result => {
                            console.log("Consultar cliente: Response sendEmailNotification");
                            console.log(result.body);
                          },
                          error => {
                            console.log("Consultar cliente: Error sendEmailNotification");
                            console.error(error);
                          });
                      }
                    },
                    err => {
                      console.log("Consultar cliente: Error en finalizar actividad");
                      console.error(err);
                    });
                },
                error => {
                  console.log("Consultar cliente: Error startService");
                  console.error(error);
                  this.isLoadingActive = false;
                });
            },
            err => {
              console.log("Consultar cliente: Error en guardado en sor");
              console.error(err);
              this.isLoadingActive = false;
            });
        },
        err => {
          console.log("Consultar cliente: Error en servicio consulta listas");
          console.error(err);
          this.isLoadingActive = false;
        });
    }
  }

  formValid(tipoBoton: string) {
    if (!!this.estadoCliente && tipoBoton === "botonConsulta2" && this.estadoCliente === "NO EXISTE") {
      if ((this.listQueryForm.get("pepControl").value === "S" ||
        this.listQueryForm.get("prpControl").value === "S" ||
        this.listQueryForm.get("mrpControl").value === "S") &&
        (this.listQueryForm.get("comentarioPepPrpMrpControl").value === "" ||
          this.listQueryForm.get("comentarioPepPrpMrpControl").value === null)) {
        return (
          this.listQueryForm.get("firstLastname").valid &&
          this.listQueryForm.get("secondLastname").valid &&
          this.listQueryForm.get("name").valid &&
          this.listQueryForm.get("pepControl").valid &&
          this.listQueryForm.get("mrpControl").valid &&
          this.listQueryForm.get("prpControl").valid &&
          this.listQueryForm.get("comentarioPepPrpMrpControl").valid
        );
      } else if (this.listQueryForm.get("familiarPepControl").value === "S" &&
        (this.listQueryForm.get("comentarioFamiliarPepControl").value === "" ||
          this.listQueryForm.get("comentarioFamiliarPepControl").value === null)) {
        return (
          this.listQueryForm.get("firstLastname").valid &&
          this.listQueryForm.get("secondLastname").valid &&
          this.listQueryForm.get("name").valid &&
          this.listQueryForm.get("familiarPepControl").valid &&
          this.listQueryForm.get("comentarioFamiliarPepControl").valid
        );
      } else {
        return (
          this.listQueryForm.get("firstLastname").valid &&
          this.listQueryForm.get("secondLastname").valid &&
          this.listQueryForm.get("name").valid &&
          this.listQueryForm.get("pepControl").valid &&
          this.listQueryForm.get("mrpControl").valid &&
          this.listQueryForm.get("prpControl").valid &&
          this.listQueryForm.get("familiarPepControl").valid
        );
      }
    } else if (!!this.estadoCliente && tipoBoton === "botonConsulta2" && this.estadoCliente === "EXISTE") {
      if ((this.listQueryForm.get("pepControl").value === "S" ||
        this.listQueryForm.get("prpControl").value === "S" ||
        this.listQueryForm.get("mrpControl").value === "S") &&
        (this.listQueryForm.get("comentarioPepPrpMrpControl").value === "" ||
          this.listQueryForm.get("comentarioPepPrpMrpControl").value === null)) {
        return (
          this.listQueryForm.get("pepControl").valid &&
          this.listQueryForm.get("mrpControl").valid &&
          this.listQueryForm.get("prpControl").valid &&
          this.listQueryForm.get("comentarioPepPrpMrpControl").valid
        );
      } else if (this.listQueryForm.get("familiarPepControl").value === "S" &&
        (this.listQueryForm.get("comentarioFamiliarPepControl").value === "" ||
          this.listQueryForm.get("comentarioFamiliarPepControl").value === null)) {
        return (
          this.listQueryForm.get("familiarPepControl").valid &&
          this.listQueryForm.get("comentarioFamiliarPepControl").valid
        );
      } else {
        return (
          this.listQueryForm.get("pepControl").valid &&
          this.listQueryForm.get("mrpControl").valid &&
          this.listQueryForm.get("prpControl").valid &&
          this.listQueryForm.get("familiarPepControl").valid
        );
      }
    } else if (tipoBoton === "botonConsulta1") {
      if (this.listQueryForm.get("documentId").value !== '') {
        return (
          this.listQueryForm.get("documentId").valid
        );
      } else {
        return (
          this.listQueryForm.get("documentId").valid
        );
      }
    }
  }

  getDocumentTYpe() {
    this.isLoadingActive = true;
    this._catalogos.loadCatalog("TIPO_IDENTIFICACION").then(
      response => {
        console.log(response);
        if (!!response) {
          const list = response.body;
          const filteredList = [];
          for (let x = 0; x < list.length; x++) {
            if (this.codigosDocumento.indexOf(list[x].llave) !== -1) {
              filteredList.push(list[x]);
            }
          }
          this.tipoDocCatalog = filteredList.map(catalog => {
            return {
              nombre: catalog.valor,
              valor: catalog.llave
            };
          });
          this.tipoDocCatalogCedula = this.tipoDocCatalog[0].valor;
          this.listQueryForm.get("typeId").setValue(this.tipoDocCatalogCedula + " - " + this.tipoDocCatalog[0].nombre);
        }
        this.isLoadingActive = false;
      },
      error => {
        console.error(error);
        this.isLoadingActive = false;
      }
    );
  }

  getCiudades() {
    this._catalogos.loadCatalog("CIUDAD").then(
      response => {
        const list = response.body;
        this.ciudades = list.map(catalog => {
          return {
            nombre: catalog.valor,
            valor: catalog.llave,
            nombreDpto: catalog.valorPadre,
            valorPadre: catalog.llavePadre
          };
        });
      },
      err => {
        console.log("Ha ocurrido un error");
        console.error(err);
      }
    );
  }

  volver() {
    sessionStorage.removeItem("taskId");
    sessionStorage.removeItem("instanceId");
    this.router.navigate(["portal/bandeja-tareas"]);
    this.app.global.scrollHide = false;
  }

  resetValidPepPrpMrp() {
    this.listQueryForm.get("comentarioPepPrpMrpControl").reset();
  }

  resetValidFamiliar() {
    this.listQueryForm.get("comentarioFamiliarPepControl").reset();
  }

  resetFormGroup() {
    this.listQueryForm.get("firstLastname").reset();
    this.listQueryForm.get("secondLastname").reset();
    this.listQueryForm.get("name").reset();
    this.listQueryForm.get("fullName").reset();
    this.listQueryForm.get("pepControl").reset();
    this.listQueryForm.get("mrpControl").reset();
    this.listQueryForm.get("prpControl").reset();
    this.listQueryForm.get("familiarPepControl").reset();
    this.listQueryForm.get("comentarioPepPrpMrpControl").reset();
    this.listQueryForm.get("comentarioFamiliarPepControl").reset();
    this.resetValidFamiliar();
    this.resetValidPepPrpMrp();
    this.togglePepControlFocus = false;
    this.toggleMrpControlFocus = false;
    this.togglePrpControlFocus = false;
    this.toggleFamiliarPepControlFocus = false;
  }
}
