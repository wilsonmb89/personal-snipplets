import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { Catalogo } from '../../../shared/models/catalogo/catalogo';
import { CatalogosServiceService } from '../../../shared/services/catalogos-service.service';


@Component({
  selector: 'app-catalogs-admin',
  templateUrl: './catalogs-admin.component.html',
  styleUrls: ['./catalogs-admin.component.scss']
})
export class CatalogsAdminComponent implements OnInit {

  catalogosForm: FormGroup;
  catalogoList: Catalogo[];
  public jsonDataValid = false;
  public isLoadingActive = false;
  public modalIsShowed = false;
  public dataModal: any;
  public dataLoading: string;

  constructor(
    private _catalogoService: CatalogosServiceService
  ) { }

  ngOnInit() {
    this.catalogosForm = new FormGroup({
      dataCatalogo: new FormControl("", [Validators.minLength(1), Validators.required, this.validateJsonData()])
    });
  }

  /**
   * Valida tanto el contenido del formulario como su integridad de un catalogo especifico
   */
  validateFormData() {
    return !this.catalogosForm.valid;
  }

  /**
   * Metodo para validar la estructura JSON de la data ingresada en el formulario
   */
  validateJsonData(): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
      let validData = false;
      if (!!control.value) {
        try {
          this.catalogoList = JSON.parse(control.value);
          validData = this.catalogoList.length > 0;
        } catch (e) {
          validData = false;
        }
      }
      return (validData) ? null : {value: false};
    };
  }

  /**
   * Método para limpiar los campos del formulario
   */
  limpiar() {
    this.catalogosForm.reset();
  }

  /**
   * Método para cargar la data en el catalogo establecido
   */
  async sendCatalogo() {
    this.isLoadingActive = true;
    try {
      const deleteData = await this.deleteDataCatalog();
      if (deleteData) {
        const insertCatalog = await this.insertDataCatalog();
        if (!!insertCatalog) {
          this.limpiar();
          this.openModalOK();
        } else {
          this.openModalNOK();
        }
        this.isLoadingActive = false;
      }
    } catch (error) {
      console.error("Error sendCatalogo");
      console.error(error);
      this.isLoadingActive = false;
      this.openModalNOK();
    }
  }

  /**
   * Metodo para eliminar todos los registros de un catalogo especifico
   * se hace un control de numero de registros para evitar un time out
   * del servidor
   */
  async deleteDataCatalog() {
    const tipoCatalogo = this.catalogoList[0].tipoCatalogo;
    this.dataLoading = "Limpiando " + tipoCatalogo + " ...";
    let responseJSON = null;
    do {
      responseJSON = await this._catalogoService.clearCatalogo(tipoCatalogo).catch(
        error => {
          console.error("Error eliminando el catalogo");
          console.error(error);
          this.isLoadingActive = false;
          this.openModalNOK();
        }
      );
      this.dataLoading = "Limpiando " + tipoCatalogo + ", " + responseJSON.body + " restantes...";
    } while (responseJSON.body !== 0);
    this.dataLoading = "";
    return true;
  }

  /**
   * Metodo que inserta valores de un catalogo en la base de datos
   */
  async insertDataCatalog () {
    let insertCatalog = null;
    const pivoteElementosCatalogo = 25;
    if (this.catalogoList.length <= pivoteElementosCatalogo) {
      this.dataLoading = "Insertando registros...";
      insertCatalog = await this._catalogoService.insertCatalogo(this.catalogoList).catch(
        error => {
          console.error("Error eliminando el catalogo");
          console.error(error);
        }
      );
    } else {
      let catalogoListTemp = [];
      for (let x = 0 ; x < this.catalogoList.length ; x++) {
        this.dataLoading = "Insertando registros... " + (x + 1 + " de " + this.catalogoList.length);
        const elementCatalogo = this.catalogoList[x];
        catalogoListTemp.push(elementCatalogo);
        if ((x + 1) % pivoteElementosCatalogo === 0 || (x + 1) === this.catalogoList.length) {
          insertCatalog = await this._catalogoService.insertCatalogo(catalogoListTemp).catch(
            error => {
              console.error("Error añadiendo elementos en el catalogo");
              console.error(error);
            }
          );
          if (!!insertCatalog) {
            catalogoListTemp = [];
          } else {
            break;
          }
        }
      }
    }
    this.dataLoading = "";
    return insertCatalog;
  }

  /**
   * Abre el modal de operacion NO exitosa
   */
  openModalNOK() {
    this.dataModal = {
      imagen: "/crear-producto/assets/images/no-apto.svg",
      principalText: "Ha ocurrido un error cargando el catalogo",
      otherText: "Por favor verifique que la data ingresada tenga la estructura adecuada según el manual.",
      buttonPdf: false,
      button: false,
      buttonCloseProcess: false,
      pazSalvo: true,
      buttonText1: "¡Listo!",
      class: true
    };
    this.modalIsShowed = true;
  }

  /**
   * Abre el modal de operacion exitosa
   */
  openModalOK() {
    this.dataModal = {
      imagen: "/crear-producto/assets/images/cliente-verde.svg",
      principalText: "Se ha cargado el catalogo satisfactoriamente",
      otherText: "Por favor, reinicie los pods de api-catalogos desde el Openshift para limpiar el caché del sistema.",
      button: false,
      buttonPdf: false,
      pazSalvo: true,
      buttonText1: "¡Listo!",
      class: false
    };
    this.modalIsShowed = true;
  }

  /**
   * Metodo que cierra el modal generico
   */
  closeModal() {
    this.dataModal = null;
    this.modalIsShowed = false;
  }
}
