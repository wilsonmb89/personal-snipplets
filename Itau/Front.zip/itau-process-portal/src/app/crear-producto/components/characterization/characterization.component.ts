import { Solicitud } from "./../../models/negocio/Solicitud";
import { SolicitudesServiceService } from "../../../shared/services/solicitudes-service.service";
import { ApiProductService } from "../../services/api-producto.service";
import { map } from "rxjs/operators";
import { Observable } from "rxjs";
import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { FormControl, Validators, FormGroup } from "@angular/forms";
import { startWith } from "rxjs/operators";
import { CatalogosServiceService } from "../../../shared/services/catalogos-service.service";
import { CreaProductoPhoenixMapping } from "../../functions/mapping/CreaProductoPhoenixMapping";
import { CaracterizarProductoSORMapping } from "../../functions/mapping/CaracterizarProductoSORMapping";
import { SOR_DATOS_ADICIONALES_PRODUCTOS } from "../../constants/LlavesSOR.constant";
import { nombreValorCatalogValidator } from "../../../shared/functions/util/validations/CustomValidators";
import { DatosCuenta } from "../../models/products/datosCuenta";
import { filtrarCatalogo } from "../../../shared/functions/util/Filter";
import { NotificationService } from '../../../shared/services/Notification.service';
import { NotificationMapping } from '../../../shared/functions/mapping/NotificationMapping';
import { IniciarServicio } from '../../../shared/models/bpm/iniciarServicio';
import { TransformationHelper } from '../../functions/util/Transformation';
import { BpmService } from "../../../shared/services/bpm.service";
import { CustomerDebitCardMapping } from "../../functions/mapping/CustomerDebitCardMapping";
import { LLAVES_NOTIFICATION, CODIGO_NOTIFICACION, REQUEST_CREA_PRODUCTO_PHOENIX, ID_SERVICE_BPM, TARJETAS_SELECCIONADAS } from '../../../shared/constants/codigosServicios.constant';
import { ConsultaProductosPhoenixMapping } from '../../functions/mapping/ConsultaProductosPhoenixMapping';

@Component({
  selector: "app-characterization",
  templateUrl: "./characterization.component.html",
  styleUrls: ["./characterization.component.scss"]
})
export class CharacterizationComponent implements OnInit {
  public cardSelected = [];
  public card;
  public objetivoSelected = [];
  public objetivo;
  @Input() productList: any;
  @Input() data: any;
  @Output() solicitudEmit = new EventEmitter<any>();
  @Output() values = new EventEmitter<any>();
  @Output() showLoadingCard = new EventEmitter<boolean>();
  @Output() servicefail = new EventEmitter<boolean>();
  @Output() modalErrorOpenCard = new EventEmitter<boolean>();
  @Output() validScreen = new EventEmitter<boolean>();
  public datosCuenta: DatosCuenta[] = [];
  public seleccionDefaultCuentaAP = true;
  public solicitud: Solicitud;
  public instanceId: string;
  public taskId: string;
  infoMessage: String;
  convenioCatalogo: any[];
  convenio_empty: any[];
  filteredOptionsConvenio: Observable<any[]>;
  filteredOptionsConvenioBasica: Observable<any[]>;
  public convenioForm: FormGroup;
  montoApertura = new FormControl("", [Validators.maxLength(50)]);
  public formAhorroProgramado: FormGroup;
  public formBasica: FormGroup;
  public _productSorMappging: CaracterizarProductoSORMapping;
  public _creaProductoMapping: CreaProductoPhoenixMapping;
  public _cosultaProductosMapping: ConsultaProductosPhoenixMapping;
  public tarjetaSeleccionada: string;
  public convenioSolicitud: string;
  public cuentas: any[];
  public cuentasDisponiblesAhorroProgramado: any[];
  objetivoAhorroProgramado: any[];
  public notificationMapping: NotificationMapping;
  public suggestedBoolean = false;
  public transformationHelper: TransformationHelper;
  public sorMapping: CustomerDebitCardMapping;
  public numeroTarjeta: string;


  constructor(
    private _bpmService: BpmService,
    private catalogoService: CatalogosServiceService,
    private _apiProductService: ApiProductService,
    private _solicitudesService: SolicitudesServiceService,
    private _notificationService: NotificationService
  ) {
    window.scroll(0, 0);
    this.sorMapping = new CustomerDebitCardMapping();
    this._productSorMappging = new CaracterizarProductoSORMapping();
    this._creaProductoMapping = new CreaProductoPhoenixMapping();
    this._cosultaProductosMapping = new ConsultaProductosPhoenixMapping();
    this.transformationHelper = new TransformationHelper();
    this.notificationMapping = new NotificationMapping();
  }

  ngOnInit() {
    console.log("Valor del monto");
    console.log(this.montoApertura.value);
    if (this.montoApertura.value === 0) {
      this.montoApertura.setValue('');
    }
    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");
    this.getConvenios();
    this.cuentas = [];
    this.cuentasDisponiblesAhorroProgramado = [];

    this.convenioForm = new FormGroup({
      tarjeta: new FormControl(""),
      convenio: new FormControl("", [Validators.maxLength(200)]),
    });
    this.filteredOptionsConvenio = this.convenioForm.get("convenio").valueChanges.pipe(
      startWith(""),
      map(value => this._filterCatalog(value))
    );

    this.formAhorroProgramado = new FormGroup({
      montoAhorroPeriodico: new FormControl("", [Validators.maxLength(50)]),
      diaDebito: new FormControl("", [Validators.pattern(/^(30|[12][0-9]|[1-9])$/)]),
      objetivoAhorroProgramado: new FormControl(""),
      cuentaOrigen: new FormControl("")
    });
    this.formAhorroProgramado.get("cuentaOrigen").setValue("NA");

    this.formBasica = new FormGroup({
      tarjeta: new FormControl("Itaú sucursales"),
      convenio: new FormControl("", [Validators.maxLength(200)]),
    });
    this.filteredOptionsConvenioBasica = this.formBasica.get("convenio").valueChanges.pipe(
      startWith(""),
      map(value => this._filterCatalog(value))
    );

    this._solicitudesService.getByInstanceId(this.instanceId).then(
      result => {
        if (!!result.body) {
          console.log("Caracterizacion: Respuesta consulta SOR");
          console.log(result);
          this.solicitud = result.body;
          this.convenioSolicitud = this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio + " - " + this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desConvenio;
          this.convenioForm.get("convenio").setValue(this.convenioSolicitud);
          this.formBasica.get("convenio").setValue(this.convenioSolicitud);
          this.solicitudEmit.emit(this.solicitud);

          this.getClientProductList();
        } else {
          console.warn("Caracterizacion: Consulta SOR - No Hay Resultados");
        }
      },
      err => {
        console.log("Caracterizacion: Error consulta SOR");
        console.log(err);
      }
    );
  }

  getClientProductList() {
    const body = this._cosultaProductosMapping.mappingConsultaProductos(this.solicitud);
    console.log(JSON.stringify(body));
    this._apiProductService.getProductList(body).then(
      res => {
        const body = res.body;
        console.log("RESPUESTA SERVICIO");
        console.log(body);
        console.log(this.productList);
        if ((res.status = 200)) {
          if (body.headerResponse.status.statusCode === 0) {
            if (body.headerResponse.status.serverStatusCode === "0") {
              if (!!body.acctList && !!body.acctList.acct && body.acctList.acct.length > 0) {
                for (let index = 0; index < body.acctList.acct.length; index++) {
                  const cuenta = {
                    numeroCuenta: body.acctList.acct[index].acctKey.acctIdent,
                    desSubProducto: filtrarCatalogo(body.acctList.acct[index].acctKey.acctSubType, this.productList, 'llave').length > 0 ? filtrarCatalogo(body.acctList.acct[index].acctKey.acctSubType, this.productList, 'llave')[0].valor : 'Tipo de cuenta no identificado',
                    subProducto: body.acctList.acct[index].acctKey.acctSubType,
                    codProducto: body.acctList.acct[index].acctKey.acctType,
                    estadoCuenta: body.acctList.acct[index].acctStatus.acctStatusCode
                  };
                  this.cuentas[index] = cuenta;
                }
                console.log(this.cuentas);
                this.updateAccountLists();
              } else {
                this.sendActiveDiv(false);
                this.cardSelected = [];
                this.objetivoSelected = [];
                this.sendServicefail(true);
                console.log("El usuario no tiene cuentas activas");
              }
            } else {
              this.sendActiveDiv(false);
              this.cardSelected = [];
              this.objetivoSelected = [];
              this.sendServicefail(true);
              console.log("Fallas en el serverStatusCode");
            }
          } else {
            this.sendActiveDiv(false);
            this.cardSelected = [];
            this.objetivoSelected = [];
            this.sendServicefail(true);
            console.log("Fallas en el statusCode");
          }
        } else {
          this.sendActiveDiv(false);
          this.cardSelected = [];
          this.objetivoSelected = [];
          this.sendServicefail(true);
          console.log("Fallas en el servicio");
        }
      },
      err => {
        this.sendActiveDiv(false);
        this.cardSelected = [];
        this.objetivoSelected = [];
        console.log(err);
      }
    );
  }

  updateAccountLists() {
    this.cuentasDisponiblesAhorroProgramado = this.cuentas.filter(option => {
      if (option['estadoCuenta'] === 'Activo' && (option['subProducto'] === '211' || option['subProducto'] === '218')) {
        return true;
      }
    });
  }

  sendValue(value) {
    this.tarjetaSeleccionada = value;
    if (-1 !== this.cardSelected.indexOf(value)) {
      const index = this.cardSelected.indexOf(value);
      this.cardSelected.splice(index, 1);
    } else {
      this.cardSelected[0] = value;
      if (this.cardSelected.length > 0) {
        this.card = true;
      } else {
        this.card = false;
      }
    }
    console.log(this.cardSelected);
  }

  sendObjetivo(value) {

    if (-1 !== this.objetivoSelected.indexOf(value)) {
      const index = this.objetivoSelected.indexOf(value);
      this.objetivoSelected.splice(index, 1);
    } else {
      this.objetivoSelected[0] = value;
      if (this.objetivoSelected.length > 0) {
        this.objetivo = true;
      } else {
        this.objetivo = false;
      }
    }
    this.objetivoAhorroProgramado = this.objetivoSelected;
    this.formAhorroProgramado.get("objetivoAhorroProgramado").setValue(value);
    console.log(this.formAhorroProgramado.get("objetivoAhorroProgramado").value);
  }

  private _filterCatalog(value: string) {
    return filtrarCatalogo(value, this.convenioCatalogo, 'valor|nombre');
  }

  getConvenios(): void {
    this.catalogoService.loadCatalog("CONVENIO_NOMINA").then(
      response => {
        console.log(response);
        const list = response.body;
        this.convenioCatalogo = list.map(catalog => {
          return {
            valor: catalog.valor,
            nombre: catalog.llave
          };
        });
        if (!!this.convenioCatalogo) {
          this.convenioForm.get("convenio").setValidators([
            Validators.maxLength(200),
            Validators.required,
            nombreValorCatalogValidator(this.convenioCatalogo)
          ]);
          this.formBasica.get("convenio").setValidators([
            Validators.maxLength(200),
            nombreValorCatalogValidator(this.convenioCatalogo)
          ]);
        }
      },
      err => {
        console.log(err);
        this.infoMessage = "Ha ocurrido un error";
      }
    );
  }

  async createAccount() {
    this.sendActiveScreen(true);
    this.sendActiveDiv(true);
    this.homologarTajetaSeleccionada();
    const crearProducto = this._creaProductoMapping.mappingCreaCuentaAhorros(this.solicitud, this.data, this.formAhorroProgramado);
    const producto = await this._apiProductService.createProduct(crearProducto).catch(error => {
      console.error("Caractertizar Producto: Error createProducto: addAccount");
      console.error(error);
      this.resetDisplayData();
    });

    if (producto && producto.body) {
      console.log("RESPUESTA SERVICIO");
      console.log(producto.body);
      if (producto.body.headerResponse.status.statusCode === 0) {
        if (producto.body.headerResponse.status.serverStatusCode === "0") {
          if (producto.body.acctKey.acctSubType === REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_TRADICIONAL
                || producto.body.acctKey.acctSubType === REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_NOMINA
                || producto.body.acctKey.acctSubType === REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_BASICA) {

            const bodyStartService = new IniciarServicio();
            bodyStartService.idService = ID_SERVICE_BPM.GS_ASOCIACION_OPENCARD;
            const parameters = {
              ciudad: this.solicitud.datosSolicitud.radicador.desCiudadOficina,
              tipoTarjeta: this.transformationHelper.homologationCards(this.cardSelected[0])
            };
            bodyStartService.parameters = JSON.stringify(parameters);
            const openCardRule = await this._bpmService.startService(bodyStartService).catch(error => {
              console.error("Caractertizar Producto: Error startService Regla - GS ASOCIACION OPENCARD");
              console.log(error);
              this.resetDisplayData();
            });

            if (!!openCardRule) {
              const bodyCustomerCard = this.sorMapping.mappingCustomerDebitCard(this.solicitud, openCardRule.body.body.data.data, producto.body);
              const addNumberCard = await this._apiProductService.addNumberCard(bodyCustomerCard).catch(error => {
                console.log(error);
              });

              if (!!addNumberCard && !!addNumberCard.body && addNumberCard.body.headerResponse.status.serverStatusCode === "0" && addNumberCard.body.headerResponse.status.severity === "Info") {
                this.numeroTarjeta = addNumberCard.body.cardKey.cardNum;
              } else {
                this.resetDisplayData();
                this.modalErrorOpenCard.emit(true);
                console.error("Caractertizar Producto: Customer Debit Card");
                console.error(addNumberCard);
              }
            }
          }

          if (!!this.datosCuenta && this.datosCuenta.length > 0) {
            const dataCuenta = new DatosCuenta();
            dataCuenta.codeAccount = producto.body.acctKey.acctType;
            dataCuenta.accountType = this.data.desProducto;
            dataCuenta.accounSubtType = this.data.desSubProducto;
            dataCuenta.accountCodeSubType = producto.body.acctKey.acctSubType;
            dataCuenta.accountNumber = producto.body.acctKey.acctIdent;
            dataCuenta.nombreTarjeta = this.tarjetaSeleccionada;
            dataCuenta.numeroTarjeta = !!this.numeroTarjeta ? this.numeroTarjeta : "";
            this.datosCuenta.unshift(dataCuenta);
          } else {
            this.datosCuenta = new Array<DatosCuenta>();
            this.datosCuenta[0] = new DatosCuenta();
            this.datosCuenta[0].codeAccount = producto.body.acctKey.acctType;
            this.datosCuenta[0].accountType = this.data.desProducto;
            this.datosCuenta[0].accounSubtType = this.data.desSubProducto;
            this.datosCuenta[0].accountCodeSubType = producto.body.acctKey.acctSubType;
            this.datosCuenta[0].accountNumber = producto.body.acctKey.acctIdent;
            this.datosCuenta[0].nombreTarjeta = this.tarjetaSeleccionada;
            this.datosCuenta[0].numeroTarjeta = !!this.numeroTarjeta ? this.numeroTarjeta : "";
          }

          const datosAdicionales: Map<string, string> = new Map<string, any>();
          datosAdicionales.set(SOR_DATOS_ADICIONALES_PRODUCTOS.CONVENIO, this.convenioForm.get("convenio").value);
          datosAdicionales.set(SOR_DATOS_ADICIONALES_PRODUCTOS.CONVENIO_BASICA, this.formBasica.get("convenio").value);
          datosAdicionales.set(SOR_DATOS_ADICIONALES_PRODUCTOS.MONTO_APERTURA, this.montoApertura.value);
          datosAdicionales.set(SOR_DATOS_ADICIONALES_PRODUCTOS.NUMERO_TARJETA, !!this.numeroTarjeta ? this.numeroTarjeta : "");
          const bodySor: any = this._productSorMappging.mappingCaracterizarProducto(this.solicitud, this.data, producto.body, datosAdicionales, this.formAhorroProgramado, this.tarjetaSeleccionada);
          this._solicitudesService.update(bodySor).then(
            respons => {
              console.log("Caractertizar Producto: Response guardado SOR");
              console.log(respons);
              this.solicitud = respons.body;
              this.sendValues();
              this.sendActiveDiv(false);
              this.solicitudEmit.emit(this.solicitud);

              this.getClientProductList();
              this.montoApertura.setValue("");
              this.formAhorroProgramado.get("objetivoAhorroProgramado").setValue("");
              this.formAhorroProgramado.get("cuentaOrigen").setValue("NA");
              this.formAhorroProgramado.get("montoAhorroPeriodico").setValue("");
              this.formAhorroProgramado.get("diaDebito").setValue("");
              this.tarjetaSeleccionada = "";

              this.cardSelected = [];
              this.objetivoSelected = [];

              const longitudProductos = this.solicitud.datosSolicitud.personaNatural[0].producto.length - 1;

              if (this.solicitud.datosSolicitud.personaNatural[0].producto[longitudProductos].codSubProducto === REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_TRADICIONAL ||
                this.solicitud.datosSolicitud.personaNatural[0].producto[longitudProductos].codSubProducto === REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_NOMINA) {

                let nombreCompleto = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre;
                nombreCompleto = nombreCompleto + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido;
                nombreCompleto = !!this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido ? nombreCompleto + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido : nombreCompleto + "";

                const datosSMS = {};
                datosSMS[LLAVES_NOTIFICATION.NOMBRE_CLIENTE] = nombreCompleto;
                datosSMS[LLAVES_NOTIFICATION.SUB_PRODUCTO] = this.solicitud.datosSolicitud.personaNatural[0].producto[longitudProductos].desSubProducto;
                datosSMS[LLAVES_NOTIFICATION.NUMERO_CUENTA] = this.solicitud.datosSolicitud.personaNatural[0].producto[longitudProductos].numeroCuenta;

                const bodySendSMS = this.notificationMapping.mappingSendMessageNotification(CODIGO_NOTIFICACION.SMS_CREACION_CUENTA_AHORRO,
                  this.solicitud.datosSolicitud.personaNatural[0].ubicacion.numeroCelular,
                  datosSMS);

                this._notificationService.sendMessageNotification(bodySendSMS).then(
                  result => {
                    console.error("Caracterizar Producto: Response sendMessageNotification");
                    console.error(result.body);
                  },
                  error => {
                    console.error("Caracterizar Producto: Error sendMessageNotification");
                    console.error(error);
                  });
              }
              this.resetDisplayData();
            },
            error => {
              this.resetDisplayData();
              this.sendServicefail(true);
              console.error("Caractertizar Producto: Error guardado SOR");
              console.error(error);
            }
          );

        } else {
          this.resetDisplayData();
          this.sendServicefail(true);
          console.error("Fallas en el serverStatusCode");
        }
      } else {
        this.resetDisplayData();
        this.sendServicefail(true);
        console.error("Fallas en el statusCode");
      }
    } else {
      this.resetDisplayData();
      this.sendServicefail(true);
      console.error("Fallas en el servicio");
    }
  }

  sendValues() {
    this.values.emit(this.datosCuenta);
  }

  sendActiveDiv(value) {
    this.showLoadingCard.emit(value);
  }

  sendServicefail(value) {
    this.servicefail.emit(value);
  }

  sendActiveScreen(value) {
    this.validScreen.emit(value);
  }

  formValidCuentaAhorros() {
    if (this.formAhorroProgramado.get("cuentaOrigen").value !== "NA") {
      if (
        !!this.formAhorroProgramado.get("cuentaOrigen").value &&
        this.formAhorroProgramado.get("montoAhorroPeriodico").value !== "0" &&
        !!this.formAhorroProgramado.get("montoAhorroPeriodico").value &&
        !!this.formAhorroProgramado.get("diaDebito").value &&
        this.formAhorroProgramado.get("diaDebito").value > 0 &&
        this.formAhorroProgramado.get("diaDebito").value <= 30 &&
        !!this.objetivoSelected.length &&
        this.objetivoSelected.length > 0
      ) {
        return (
          this.formAhorroProgramado.get("cuentaOrigen").valid &&
          this.formAhorroProgramado.get("montoAhorroPeriodico").valid &&
          this.formAhorroProgramado.get("diaDebito").valid &&
          this.formAhorroProgramado.get("objetivoAhorroProgramado").valid
        );
      }
    } else {
      return true;
    }
  }

  formValidTradicional() {
    if (!!this.cardSelected.length) {
      return true;
    }
  }

  formValidNomina() {
    if (!!this.cardSelected.length && !!this.convenioForm.get("convenio").value && this.convenioForm.valid && this.cardSelected.length) {
      this.convenioForm.get("convenio").setValidators([
        Validators.maxLength(200),
        Validators.required,
        nombreValorCatalogValidator(this.convenioCatalogo)
      ]);
      return true;
    }
  }

  formValidItauRentable() {
    if (!!this.montoApertura.value) {
      return true;
    }
  }

  formValidBasica() {
    return !!this.formBasica.get("convenio").value && this.formBasica.valid;
  }

  limpiarfomrularioAP() {
    if (!!this.formAhorroProgramado && !!this.formAhorroProgramado.get("cuentaOrigen").value &&
      this.formAhorroProgramado.get("cuentaOrigen").value === "NA") {
      this.objetivoSelected = [];
      this.formAhorroProgramado.get("objetivoAhorroProgramado").setValue("");
      this.formAhorroProgramado.get("montoAhorroPeriodico").setValue("");
      this.formAhorroProgramado.get("diaDebito").setValue("");
    }
  }


  resetDisplayData() {
    this.sendActiveDiv(false);
    this.cardSelected = [];
    this.objetivoSelected = [];
    this.numeroTarjeta = "";
    this.sendActiveScreen(false);
  }

  homologarTajetaSeleccionada() {
    if (this.data.codSubProducto === REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_BASICA) {
      this.tarjetaSeleccionada = TARJETAS_SELECCIONADAS.DEBIT_STANDARD;
    }
  }
}
