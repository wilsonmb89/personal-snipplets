import { Component, OnInit } from '@angular/core';
import { NOTIFICAR_CONCEPTO } from '../../../shared/constants/modals.constant';
import { SolicitudesServiceService } from '../../../shared/services/solicitudes-service.service';
import { Solicitud } from '../../models/negocio/Solicitud';
import { FinalizarTarea } from '../../../shared/models/request/FinalizarTarea';
import { POMapping } from '../../functions/mapping/POMapping';
import { AppComponent } from '../../../app.component';

@Component({
  selector: 'app-commercial-concept-notification',
  templateUrl: './commercial-concept-notification.component.html',
  styleUrls: ['./commercial-concept-notification.component.scss']
})
export class CommercialConceptNotificationComponent implements OnInit {
  public modalIsShowed = false;
  public dataModal: any;
  public solicitud: Solicitud;
  public instanceId: string;
  public taskId: string;
  public finalizarTarea: FinalizarTarea;
  public poMapping: POMapping;
  constructor(
    private _solicitudesService: SolicitudesServiceService,
    private app: AppComponent
  ) {
    this.finalizarTarea = new FinalizarTarea();
    this.app.global.nombre = sessionStorage.getItem("fullname");
    this.app.global.id = sessionStorage.getItem("instanceId");
    this.app.global.showHeader = true;
    this.app.global.showId = true;
    this.poMapping = new POMapping();
  }

  ngOnInit() {

    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");

    this._solicitudesService.getByInstanceId(this.instanceId).then(
      result => {
        if (!!result.body) {
          console.log("Notificar Concepto: Respuesta consulta SOR");
          console.log(result);
          this.solicitud = result.body;
          this.finalizarTarea = this.poMapping.mappingGenericPO(this.taskId);
          const fullname = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido;
          this.dataModal = {
            imagen: NOTIFICAR_CONCEPTO.imagen,
            secondaryText: fullname + " | C.C. " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion,
            otherText: NOTIFICAR_CONCEPTO.otherText,
            buttonText1: NOTIFICAR_CONCEPTO.buttonText1,
            genericEndTaskButton: NOTIFICAR_CONCEPTO.genericEndTaskButton,
            buttonClose: NOTIFICAR_CONCEPTO.buttonClose,
            buttonPdf: NOTIFICAR_CONCEPTO.buttonPdf,
            button: NOTIFICAR_CONCEPTO.button,
            buttonCloseProcess: NOTIFICAR_CONCEPTO.buttonCloseProcess,
            class: NOTIFICAR_CONCEPTO.class
          };
          this.modalIsShowed = true;
        } else {
          console.warn("Notificar Concepto: Consulta SOR - No hay Resultados");
        }
      },
      err => {
        console.log("Notificar Concepto: Error consulta SOR");
        console.log(err);
      });
  }
}
