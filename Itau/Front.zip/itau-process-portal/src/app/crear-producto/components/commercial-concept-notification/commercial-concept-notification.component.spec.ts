import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommercialConceptNotificationComponent } from './commercial-concept-notification.component';

describe('ConceptNotificationComponent', () => {
  let component: CommercialConceptNotificationComponent;
  let fixture: ComponentFixture<CommercialConceptNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommercialConceptNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommercialConceptNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
