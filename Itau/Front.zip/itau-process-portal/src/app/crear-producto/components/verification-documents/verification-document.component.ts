import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, HostListener } from '@angular/core';
import { Solicitud } from "../../models/negocio/Solicitud";
import { SolicitudesServiceService } from "../../../shared/services/solicitudes-service.service";
import { AppComponent } from '../../../app.component';
import { VerificarDocumentosSORMapping } from '../../functions/mapping/VerificarDocumentosSORMapping';
import { FinalizarTarea } from '../../../shared/models/request/FinalizarTarea';
import { POMapping } from '../../functions/mapping/POMapping';
import { BpmService } from '../../../shared/services/bpm.service';
import { Router } from "@angular/router";
import { EventService } from '../../../shared/services/eventos.service';
import { EventMessage } from '../../../shared/models/eventos/message-eventos';
import { EVENT_MESSAGE_CONSTANTS, LEVEL, KEYS_INFORMACION_ADICIONAL_EVENTOS } from '../../../shared/constants/mensaje-eventos-constant';

@Component({
  selector: 'app-verification-document',
  templateUrl: './verification-document.component.html',
  styleUrls: ['./verification-document.component.scss']
})
export class VerificationDocumentsComponent implements OnInit {
  public solicitud: Solicitud;
  private OPERATION_EVENT_NAME = "verificarOperacion";
  public supportIncome: boolean;
  public sorMapping: VerificarDocumentosSORMapping;
  public poMapping: POMapping;
  public finalizarTarea: FinalizarTarea;
  public taskId: string;
  public docApproved = true;
  public isLoadingActive = false;
  instanceId: string;
  isSticky = false;
  documentosCasuales = [
    { value: '0', viewValue: 'Documento ilegible' },
    { value: '1', viewValue: 'Documento no corresponde' },
    { value: '2', viewValue: 'Documento faltante' },
    { value: '3', viewValue: 'Información inconsistente' }
  ];
  public documentsForm: FormGroup;
  toggleIncomeSupportFocus = false;
  toggleSupportProccesFocus = false;
  toggleDocumentIdentificationFocus = false;
  toggleFormVentasFocus = false;
  toggleFormCardSignature = false;

  constructor(
    private router: Router,
    private app: AppComponent,
    private _bpmService: BpmService,
    private _solicitudesService: SolicitudesServiceService,
    private _eventosService: EventService
  ) {
    window.scroll(0, 0);
    this.solicitud = new Solicitud();
    this.poMapping = new POMapping();
    this.sorMapping = new VerificarDocumentosSORMapping();
    this.app.global.nombre = sessionStorage.getItem("fullname");
    this.app.global.id = sessionStorage.getItem("instanceId");
    this.app.global.scrollHide = true;
    this.app.global.showHeader = true;
    this.app.global.showId = true;
  }

  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    this.isSticky = window.pageYOffset >= 10;
  }

  ngOnInit() {
    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");

    this._solicitudesService.getByInstanceId(this.instanceId).then(
      result => {
        if (!!result.body) {
          console.log("Formulario Vinculacion: Respuesta consulta SOR");
          console.log(result.body);
          this.solicitud = result.body;
          this.supportIncome = this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.soporteIngresos;
        } else {
          console.warn("Formulario Vinculacion: Consulta SOR - No Hay Resultados");
        }
      },
      err => {
        console.log("Formulario Vinculacion: Error consulta SOR");
        console.error(err);
      });
    this.documentsForm = new FormGroup({
      toogleIncome: new FormControl('', [Validators.required]),
      doumentCasualIncome: new FormControl('', [Validators.required]),
      toogleSale: new FormControl('', [Validators.required]),
      doumentCasualSale: new FormControl('', [Validators.required]),
      toogleDoc: new FormControl('', [Validators.required]),
      doumentCasualId: new FormControl('', [Validators.required]),
      toogleProc: new FormControl('', [Validators.required]),
      doumentCasualSopId: new FormControl('', [Validators.required]),
      toogleCardSignature: new FormControl('', [Validators.required]),
      doumentCasualCardSignature: new FormControl('', [Validators.required]),
      comments: new FormControl('', [Validators.maxLength(1000)]),
    });
  }

  onSubmit(): void {
    this.isLoadingActive = true;
    const body: any = this.sorMapping.mappingVerificarDocumentos(this.documentsForm, this.solicitud);
    this._solicitudesService.update(body).then(
      res => {
        console.log("Verificar Documentos: Response guardado SOR");
        console.log(res);
        this.finalizarTarea = this.poMapping.mappingVerificarDocumentos(this.taskId, this.docApproved);
        this._bpmService.endTask(this.finalizarTarea).then(
          res => {
            const radicador = {};
            radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.NOMBRE] = this.solicitud.datosSolicitud.radicador.nombreRadicador;
            radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.CODIGO_OFICINA] = this.solicitud.datosSolicitud.radicador.codOficina;

            const vendedor = {};
            vendedor[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_IDENTIFICACION] = this.solicitud.datosSolicitud.vendedor.numeroIdentificacion;

            const informacionBasica = {};
            informacionBasica[KEYS_INFORMACION_ADICIONAL_EVENTOS.TIPO_IDENTIFICACION] = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion;
            informacionBasica[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_IDENTIFICACION] = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion;
            informacionBasica[KEYS_INFORMACION_ADICIONAL_EVENTOS.NOMBRE] = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre;
            informacionBasica[KEYS_INFORMACION_ADICIONAL_EVENTOS.PRIMER_APELLIDO] = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido;
            informacionBasica[KEYS_INFORMACION_ADICIONAL_EVENTOS.SEGUNDO_APELLIDO] = !!this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido ? this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido : "";

            const actividadEconomina = {};
            actividadEconomina[KEYS_INFORMACION_ADICIONAL_EVENTOS.CODIGO_CONVENIO] = !!this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio ? this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio : "0";
            actividadEconomina[KEYS_INFORMACION_ADICIONAL_EVENTOS.DESCRIPCION_CONVENIO] = !!this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desConvenio ? this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desConvenio : "";

            const informacionFinanciera = {};
            informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.INGRESO_PRINCIPAL_CORE] = this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoPrincipalCore;
            informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.OTROS_INGRESOS] = !!this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.otrosIngresos ? this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.otrosIngresos : "";
            informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.DESCRIPCION_OTROS_INGRESOS] = !!this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.desConceptoOtrosIngresos ? this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.desConceptoOtrosIngresos : "";
            informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.TOTAL_INGRESOS] = this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.totalIngresos;
            informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.EGRESOS_MENSUALES] = !!this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.egresosMensuales ? this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.egresosMensuales : "";
            informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.TOTAL_ACTIVOS] = !!this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.totalActivos ? this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.totalActivos : "";
            informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.TOTAL_PATRIMONIO] = !!this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.patrimonio ? this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.patrimonio : "";
            if (!!this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoEstimado) {
              informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.INGRESO_TERCERAS_FUENTES] = this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoEstimado;
              informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.TIPO_INGRESO_TERCERAS_FUENTES] = "Estimado";
            } else if (!!this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoValidado) {
              informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.INGRESO_TERCERAS_FUENTES] = this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoValidado;
              informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.TIPO_INGRESO_TERCERAS_FUENTES] = "Validado";
            } else {
              informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.INGRESO_TERCERAS_FUENTES] = "";
              informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.TIPO_INGRESO_TERCERAS_FUENTES] = "";
            }

            const marcacionesCliente = {};
            marcacionesCliente[KEYS_INFORMACION_ADICIONAL_EVENTOS.PEP] = !!this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.pep ? this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.pep : "N";
            marcacionesCliente[KEYS_INFORMACION_ADICIONAL_EVENTOS.MRP] = !!this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.mrp ? this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.mrp : "N";
            marcacionesCliente[KEYS_INFORMACION_ADICIONAL_EVENTOS.PRP] = !!this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.prp ? this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.prp : "N";

            const informacionProducto = {};
            let conCodigoProducto = "";
            let conDescripcionProdcuto = "";
            let conNumeroCuenta = "";
            for (let idx = 0; idx < this.solicitud.datosSolicitud.personaNatural[0].producto.length; idx++) {
              if (idx !== (this.solicitud.datosSolicitud.personaNatural[0].producto.length - 1)) {
                conCodigoProducto = conCodigoProducto + this.solicitud.datosSolicitud.personaNatural[0].producto[idx].codProducto + "-";
                conDescripcionProdcuto = conDescripcionProdcuto + this.solicitud.datosSolicitud.personaNatural[0].producto[idx].desSubProducto + "-";
                conNumeroCuenta = conNumeroCuenta + this.solicitud.datosSolicitud.personaNatural[0].producto[idx].numeroCuenta + "-";
              } else {
                conCodigoProducto = conCodigoProducto + this.solicitud.datosSolicitud.personaNatural[0].producto[idx].codProducto;
                conDescripcionProdcuto = conDescripcionProdcuto + this.solicitud.datosSolicitud.personaNatural[0].producto[idx].desSubProducto;
                conNumeroCuenta = conNumeroCuenta + this.solicitud.datosSolicitud.personaNatural[0].producto[idx].numeroCuenta;
              }
            }
            informacionProducto[KEYS_INFORMACION_ADICIONAL_EVENTOS.CODIGO_PRODUCTO] = conCodigoProducto;
            informacionProducto[KEYS_INFORMACION_ADICIONAL_EVENTOS.DESCRIPCION_PRODUCTO] = conDescripcionProdcuto;
            informacionProducto[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_CUENTA] = conNumeroCuenta;

            const informacionActividad = {};
            informacionActividad[KEYS_INFORMACION_ADICIONAL_EVENTOS.FECHA_INICIO_ACTIVIDAD] = sessionStorage.getItem("startDate");
            informacionActividad[KEYS_INFORMACION_ADICIONAL_EVENTOS.FECHA_FIN_ACTIVIDAD] = this.docApproved ? new Date() : "";

            const informacionDocumentos = {};
            informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.USUARIO_SUB_GERENTE_OPERATIVO] = sessionStorage.getItem("loginRed");
            informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.DOCUMENTOS_RECHAZADOS] = "";
            informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.CAUSALES_RECHAZO] = "";
            if (this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.soporteIngresos === "N") {
              informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.DOCUMENTOS_RECHAZADOS] += "|Soporte de ingresos|";
              informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.CAUSALES_RECHAZO] += "|" + this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.desCausalIngresos + "|";
            }
            if (this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.formularioVenta === "N") {
              informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.DOCUMENTOS_RECHAZADOS] += "|Formulario de venta firmado (FT1294)|";
              informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.CAUSALES_RECHAZO] += "|" + this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.desCausalVenta + "|";
            }
            if (this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.documentoId === "N") {
              informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.DOCUMENTOS_RECHAZADOS] += "|Documento de identificación|";
              informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.CAUSALES_RECHAZO] += "|" + this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.desCausalId + "|";
            }
            if (this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.soporteProcesoId === "N") {
              informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.DOCUMENTOS_RECHAZADOS] += "|Soporte de Proceso de identificación (FT1416)|";
              informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.CAUSALES_RECHAZO] += "|" + this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.desCausalProId + "|";
            }
            if (this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.tarjetaFirmas === "N") {
              informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.DOCUMENTOS_RECHAZADOS] += "|Tarjeta de firmas|";
              informacionDocumentos[KEYS_INFORMACION_ADICIONAL_EVENTOS.CAUSALES_RECHAZO] += "|" + this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.desCausalTarjFirma + "|";
            }

            const messageBody = {};
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_SOLICITUD] = this.solicitud.numeroSolicitud;
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.FECHA_SOLICITUD] = this.solicitud.datosSolicitud.fechaRadicacion;
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.RADICADOR] = radicador;
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.VENDEDOR] = vendedor;
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.INFORMACION_BASICA] = informacionBasica;
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.ACTIVIDAD_ECONOMICA] = actividadEconomina;
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.INFORMACION_FINANCIERA] = informacionFinanciera;
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.MARCACIONES_CLIENTE] = marcacionesCliente;
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.INFORMACION_PRODUCTO] = informacionProducto;
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.INFORMACION_ACTIVIDAD] = informacionActividad;
            messageBody[KEYS_INFORMACION_ADICIONAL_EVENTOS.INFORMACION_DOCUMENTOS] = informacionDocumentos;

            const messageEvent = new EventMessage();
            messageEvent.api = EVENT_MESSAGE_CONSTANTS.API;
            messageEvent.level = LEVEL.TRACKINGPOINT;
            messageEvent.operation = this.OPERATION_EVENT_NAME;
            messageEvent.messageBody = messageBody;

            this._eventosService.sendEvent(messageEvent).then(
              res => {
                console.log("Verificar Operacion: Response enviar evento");
                console.log("RESPUESTA");
                console.log(res);
              },
              error => {
                console.log("Verificar Operacion: Error enviar evento");
                console.log(error);
              }
            );

            this.app.global.id = "";
            this.app.global.showId = false;
            this.router.navigate(["portal/bandeja-tareas"]);
            this.isLoadingActive = false;
          }, err => {
            this.isLoadingActive = false;
            console.log("Verificacion Documentos: Error en finalizar actividad");
            console.error(err);
          });
      }, err => {
        this.isLoadingActive = false;
        console.log("Seleccionar Producto: Error Post-Guardado SOR");
        console.error(err);
      }
    );
  }

  hideComment() {
    if (this.documentsForm.get('toogleIncome').value === 'N' || this.documentsForm.get('toogleSale').value === 'N' ||
      this.documentsForm.get('toogleDoc').value === 'N' || this.documentsForm.get('toogleProc').value === 'N' ||
      this.documentsForm.get('toogleCardSignature').value === 'N') {
      this.docApproved = false;
      return true;
    }
  }

  formValid() {
    let isValidSuppIncome = true;
    let causalIngresos = true;
    let causalVenta = true;
    let causalDocId = true;
    let causalSopId = true;
    let causalCardSign = true;

    if (this.supportIncome) {
      isValidSuppIncome = this.documentsForm.get('toogleIncome').valid;
    }

    if (this.documentsForm.get('toogleIncome').value === 'N') {
      causalIngresos = this.documentsForm.get('doumentCasualIncome').valid;
    }

    if (this.documentsForm.get('toogleSale').value === 'N') {
      causalVenta = this.documentsForm.get('doumentCasualSale').valid;
    }

    if (this.documentsForm.get('toogleDoc').value === 'N') {
      causalDocId = this.documentsForm.get('doumentCasualId').valid;
    }

    if (this.documentsForm.get('toogleProc').value === 'N') {
      causalSopId = this.documentsForm.get('doumentCasualSopId').valid;
    }

    if (this.documentsForm.get('toogleCardSignature').value === 'N') {
      causalCardSign = this.documentsForm.get('doumentCasualCardSignature').valid;
    }

    return (
      isValidSuppIncome &&
      causalIngresos &&
      causalVenta &&
      causalDocId &&
      causalSopId &&
      causalCardSign &&
      this.documentsForm.get("toogleSale").valid &&
      this.documentsForm.get("toogleDoc").valid &&
      this.documentsForm.get("toogleProc").valid &&
      this.documentsForm.get("toogleCardSignature").valid
    );
  }
}
