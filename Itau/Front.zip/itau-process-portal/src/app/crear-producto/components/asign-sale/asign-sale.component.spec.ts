import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AsignSaleComponent } from './asign-sale.component';

describe('AsignSaleComponent', () => {
  let component: AsignSaleComponent;
  let fixture: ComponentFixture<AsignSaleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AsignSaleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AsignSaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
