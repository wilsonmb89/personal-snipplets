import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { Component, OnInit, HostListener } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppComponent } from '../../../app.component';
import { Solicitud } from '../../models/negocio/Solicitud';
import { POMapping } from '../../functions/mapping/POMapping';
import { AsignarVentaSORMapping } from '../../functions/mapping/AsignarVentaSORMapping';
import { EstructuraComercialMapping } from '../../functions/mapping/EstructuraComercialMapping';
import { FinalizarTarea } from '../../../shared/models/request/FinalizarTarea';
import { filtrarCatalogo } from '../../../shared/functions/Filter';
import { oficinaCatalogValidator } from '../../../shared/functions/CustomValidators';
import { BpmService } from '../../../shared/services/bpm.service';
import { AutoflowService } from '../../../shared/services/autoflow.service';
import { CatalogosServiceService } from '../../../shared/services/catalogos-service.service';
import { SolicitudesServiceService } from '../../../shared/services/solicitudes-service.service';
import { EstructuraComercialService } from '../../services/estructuraComercial.service';
import { RESPONSE_GET_ORG_STRUCTURE } from '../../../shared/constants/codigosServicios.constant';

@Component({
  selector: 'app-asign-sale',
  templateUrl: './asign-sale.component.html',
  styleUrls: ['./asign-sale.component.scss']
})
export class AsignSaleComponent implements OnInit {
  public solicitud: Solicitud;
  public poMapping: POMapping;
  public asignarVentasorMappging: AsignarVentaSORMapping;
  public estructuraComercialMapping: EstructuraComercialMapping;
  public finalizarTarea: FinalizarTarea;
  public instanceId: string;
  public taskId: string;
  public isLoadingActive = false;
  public productSelected = [];
  public product: boolean;
  public filteredOptionsOffice: Observable<any[]>;
  public selectProdcut: FormGroup;
  public oficinas: any[];
  public isSticky = false;
  public loginRedSubGerenteOficina: string;

  constructor(
    private app: AppComponent,
    private _bpmService: BpmService,
    private _autoflow: AutoflowService,
    private _catalogoService: CatalogosServiceService,
    private _solicitudesService: SolicitudesServiceService,
    private _estructuraComercialService: EstructuraComercialService
  ) {
    this.app.global.nombre = sessionStorage.getItem("fullname");
    this.app.global.id = sessionStorage.getItem("instanceId");
    this.app.global.showHeader = true;
    this.app.global.scrollHide = true;
    this.app.global.showId = true;
    this.poMapping = new POMapping();
    this.asignarVentasorMappging = new AsignarVentaSORMapping();
    this.estructuraComercialMapping = new EstructuraComercialMapping();
    this.getOficinas();
    window.scroll(0, 0);
  }

  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    this.isSticky = window.pageYOffset >= 10;
  }

  ngOnInit() {
    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");
    this.isLoadingActive = true;

    this.selectProdcut = new FormGroup({
      documentIdSeller: new FormControl('', [Validators.required, Validators.maxLength(10), Validators.pattern("^(0|[1-9][0-9]*)$")]),
      name: new FormControl('', [Validators.required, Validators.maxLength(80)]),
      office: new FormControl('', [Validators.maxLength(150)])
    });

    this._solicitudesService.getByInstanceId(this.instanceId).then(
    result => {
      if (!!result.body) {
        this.solicitud = result.body;
        this.mappingConsulta(this.selectProdcut, this.solicitud);
        this.isLoadingActive = false;
      } else {
        this._estructuraComercialService.getOrgStructure(this.estructuraComercialMapping.mappingGetOrgStructure(sessionStorage.getItem("user"), "")).then(
          res => {
            if (!!res) {
              res.body.employees.employee.forEach(employee => {
                if (employee.level === 0 && employee.userName === sessionStorage.getItem("user")) {
                  this.mappingEstructuraComercial(this.selectProdcut, employee);
                  const bodySor: any = this.asignarVentasorMappging.mappingAsignarVenta(this.selectProdcut, this.instanceId, this.solicitud, false);
                  this._solicitudesService.createOrUpdate(bodySor).then(
                    res => { this.solicitud = res.body; this.isLoadingActive = false; },
                    err => {
                      this.isLoadingActive = false;
                      console.error("Seleccionar Producto: Error Pre-Guardado SOR");
                      console.error(err);
                    }
                  );
                }
                if (employee.occupation === RESPONSE_GET_ORG_STRUCTURE.OCCUPATION_SUBGERENTE_OPERATIVO || employee.occupation === RESPONSE_GET_ORG_STRUCTURE.OCCUPATION_SUBGERENTE_OPERATIVO_JUNIOR) {
                  this.loginRedSubGerenteOficina = employee.userName;
                }
              });
            } else {
              this.isLoadingActive = false;
              console.error("Seleccionar Producto: Error estructura comercial");
              console.error(res);
            }
          }, err => {
            this.isLoadingActive = false;
            console.error("Seleccionar Producto: Error estructura comercial");
            console.error(err);
          }
        );
      }
    }, err => {
      this.isLoadingActive = false;
      console.log("Seleccionar Producto: Error consulta SOR");
      console.error(err);
    });

    this.filteredOptionsOffice = this.selectProdcut.get("office").valueChanges.pipe(
      startWith(""), map(value => this._filterCatalog(value))
    );
  }

  /**
  *  Funcion que filtra el catalogo de acuerdo a su value
  *  @author Juan Umbarila - EJU03419
  *  @since 06/02/2019
  *  @param value
  *  @returns filtrarCatalogo
  */
  private _filterCatalog(value: string) {
    return filtrarCatalogo(value, this.oficinas, 'llave|valor');
  }

  /**
  *  Funcion que carga el catalogo de oficinas
  *  @author Juan Umbarila - EJU03419
  *  @since 06/02/2019
  *  @returns valor, llave
  */
 async getOficinas() {
  await this._catalogoService.loadCatalogOffice("OFICINA").then(
      response => {
        this.oficinas = response.body.map(catalog => {
          return { valor: catalog.valor, llave: catalog.llave, valorPadre: catalog.valorPadre };
        });
        if (!!this.oficinas) {
          this.selectProdcut.get("office").setValidators([
            Validators.maxLength(150), Validators.required, oficinaCatalogValidator(this.oficinas)
          ]);
        }
      }, err => {
        console.log("Seleccionar Producto: Error Catalogo Oficinas");
        console.error(err);
      }
    );
  }

  /**
  *  Guarda en SOR la informacion del Radicador y Vendedor,
  *  valida la seleccion de productos y finaliza la actividad
  *  @author Juan Umbarila - EJU03419
  *  @since 06/02/2019
  */
  selectProducts() {
    this.isLoadingActive = true;
    console.log("Crear producto");
    console.log(this.productSelected);
    console.log(this.product);

    if (this.productSelected.length === 1 && this.productSelected[0] === "otrosProductos") {
      this.product = false;
    } else { this.product = true; }

    const bodySor: any = this.asignarVentasorMappging.mappingAsignarVenta(this.selectProdcut, this.instanceId, this.solicitud, true);
    this._solicitudesService.createOrUpdate(bodySor).then(
      res => {
        this.finalizarTarea = this.poMapping.mappingAsignarVentaPO(this.taskId, this.instanceId, this.product, this.loginRedSubGerenteOficina);
        this._bpmService.endTask(this.finalizarTarea).then(
          res => {
            this.app.global.id = "";
            this.app.global.showId = false;
            this._autoflow.nextPage(this.instanceId);
          }, err => {
            this.isLoadingActive = false;
            console.log("Seleccionar Producto: Error en finalizar actividad");
            console.error(err);
          });
      }, err => {
        this.isLoadingActive = false;
        console.log("Seleccionar Producto: Error Post-Guardado SOR");
        console.error(err);
      }
    );
  }

  /**
  *  Funcion que valida el value de un producto
  *  @author Juan Umbarila - EJU03419
  *  @since 06/02/2019
  *  @param value
  */
  sendValue(value) {
    if (-1 !== this.productSelected.indexOf(value)) {
      const index = this.productSelected.indexOf(value);
      this.productSelected.splice(index, 1);
    } else { this.productSelected.push(value); }
  }

  /**
  *  Funcion que valida los campos del formulario
  *  @author Juan Umbarila - EJU03419
  *  @since 07/02/2019
  *  @returns FormGroup Valid
  */
  formValid() {
    return (
      this.selectProdcut.get("documentIdSeller").valid &&
      this.selectProdcut.get("name").valid &&
      this.selectProdcut.get("office").valid &&
      this.productSelected.length > 0
    );
  }

  /**
  *  Funcion que Mapea los campos en pantalla de
  *  Consulta SOR
  *  @author Juan Umbarila - EJU03419
  *  @since 08/02/2019
  *  @param selectProduct
  *  @param solicitud
  */
  mappingConsulta(selectProduct: FormGroup, solicitud: Solicitud) {
    if (!!solicitud.datosSolicitud && !!solicitud.datosSolicitud.radicador) {
      selectProduct.get('documentIdSeller').setValue(!!solicitud.datosSolicitud.radicador.numeroIdentificacion ? solicitud.datosSolicitud.radicador.numeroIdentificacion : "");
      selectProduct.get('name').setValue(!!solicitud.datosSolicitud.radicador.nombreRadicador ? solicitud.datosSolicitud.radicador.nombreRadicador : "");
      selectProduct.get('office').setValue(
        !!solicitud.datosSolicitud.radicador.codOficina && !!solicitud.datosSolicitud.radicador.desOficina && !! solicitud.datosSolicitud.radicador.desCiudadOficina ?
        solicitud.datosSolicitud.radicador.codOficina + "-" + solicitud.datosSolicitud.radicador.desOficina  + "-" + solicitud.datosSolicitud.radicador.desCiudadOficina : ""
      );
    }
  }

  /**
  *  Funcion que Mapea los campos en pantalla de
  *  Estructura Comercial
  *  @author Juan Umbarila - EJU03419
  *  @since 08/02/2019
  *  @param selectProduct
  *  @param employee
  */
 mappingEstructuraComercial(selectProduct: FormGroup, employee: any) {
    selectProduct.get('documentIdSeller').setValue(!!employee.identSerialNum ? employee.identSerialNum : "");
    selectProduct.get('name').setValue(!!employee.fullName ? employee.fullName : "");

    if (employee.branchName.length === 1) {
      employee.branchName = "00" + employee.branchName;
    } else if (employee.branchName.length === 2) {
      employee.branchName = "0" + employee.branchName;
    }

    if (!!this.oficinas && this.oficinas.length > 0) {
      this.oficinas.forEach(oficina => {
        if (oficina.llave === employee.branchName) {
          selectProduct.get('office').setValue(oficina.llave + " - " + oficina.valor + " - " + oficina.valorPadre);
        }
      });
    }
  }

}
