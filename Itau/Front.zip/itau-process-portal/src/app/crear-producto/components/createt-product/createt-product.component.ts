import { AppComponent } from "../../../app.component";
import { POMapping } from "../../functions/mapping/POMapping";
import { BpmService } from "../../../shared/services/bpm.service";
import { Component, OnInit, HostListener } from "@angular/core";
import { CreatePdfService } from "../../../shared/services/create-pdf.service";
import { Solicitud } from "../../models/negocio/Solicitud";
import { Router } from "@angular/router";
import { REQUEST_CREA_PRODUCTO_PHOENIX, TARJETAS_SELECCIONADAS, PARAMS_NOTIFICACION_CREAR_PROD, CODIGO_NOTIFICACION, REQUEST_SEND_EMAIL_NOTIFICATION, ID_SERVICE_BPM } from "../../../shared/constants/codigosServicios.constant";
import { FinalizarTarea } from "../../../shared/models/request/FinalizarTarea";
import { DataWrapper } from "../../../shared/models/formatos/DataWrapper";
import { DataCerProducto } from "../../models/formatos/certificadoProductos/DataCerProducto";
import { Transformation } from "../../../shared/functions/util/Trasnformation";
import { ProductoClienteCer } from "../../models/formatos/certificadoProductos/ProductoClienteCer";
import { CatalogosServiceService } from '../../../shared/services/catalogos-service.service';
import { REJECT_AGREEMENT, ERROR_OPENCARD } from "../../../shared/constants/modals.constant";
import { IniciarServicio } from '../../../shared/models/bpm/iniciarServicio';
import { NotificationMapping } from '../../../shared/functions/mapping/NotificationMapping';
import { NotificationService } from '../../../shared/services/Notification.service';
import { ItauCurrencyMoneyPipe } from '../../../shared/pipes/itau-currency-money.pipe';
import { DatosCuenta } from '../../models/products/datosCuenta';
import { filtrarCatalogo} from '../../../shared/functions/util/Filter';
import { EventMessage } from '../../../shared/models/eventos/message-eventos';
import { EVENT_MESSAGE_CONSTANTS, LEVEL } from '../../../shared/constants/mensaje-eventos-constant';
import { EventService } from '../../../shared/services/eventos.service';
import { NOMBRES_ARCHIVOS } from '../../../shared/constants/codigosServicios.constant';

@Component({
  selector: "app-createt-product",
  templateUrl: "./createt-product.component.html",
  styleUrls: ["./createt-product.component.scss"]
})
export class CreatetProductComponent implements OnInit {
  private OPERATION_EVENT_NAME = "CaracterizarProducto";
  public notificationMapping: NotificationMapping;
  public solicitud: Solicitud;
  public productSelect;
  public convenioNomina;
  public itauRentable;
  public data: any;
  public cardSelected = [];
  public card;
  public isLoadingActive = false;
  public active = false;
  public activeButton = false;
  public showCard;
  public instanceId: string;
  public taskId: string;
  public finalizarTarea: FinalizarTarea;
  public product;
  public enableClose = false;
  public dataProducts: any;
  public poMapping: POMapping;
  public datosFlujoCP: any;
  public tipoCuenta: string;
  public productscertificateSelect = [];
  public boolenModal = false;
  public messageChip;
  public boolenAcordion = true;
  public serviceFailed;
  public productNameSelected;
  public productList;
  public isSticky = false;
  public modalIsShowed = false;
  public dataModal: any;
  public suggestedBoolean = false;
  public suggestedProducts = [];
  public activeTradicional = false;
  public activeNomina = false;
  public activeRentable = false;
  public activeProgramado = false;
  public itauCurrencyMoney: ItauCurrencyMoneyPipe;
  public productosOferta: any;

  constructor(
    private catalogoService: CatalogosServiceService,
    private _pdfService: CreatePdfService,
    private _bpmService: BpmService,
    private app: AppComponent,
    private router: Router,
    private transformation: Transformation,
    private _notificationService: NotificationService,
    private _eventosService: EventService
  ) {
    this.notificationMapping = new NotificationMapping();
    this.app.global.nombre = sessionStorage.getItem("fullname");
    this.app.global.id = sessionStorage.getItem("instanceId");
    this.app.global.showHeader = true;
    this.app.global.scrollHide = true;
    this.app.global.showId = true;
    this.poMapping = new POMapping();
    this.itauCurrencyMoney = new ItauCurrencyMoneyPipe();
  }

  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    this.isSticky = window.pageYOffset >= 20;
  }
  ngOnInit() {
    /* Se consume servicio de catálogos de productos */
    this.catalogoService.loadCatalog("PRODUCTO").then(
      response => {
        console.log("Información Productos");
        console.log(response);
        this.productList = response.body;
    });
    this.dataProducts = [];
    console.log(this.dataProducts.length);
    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");
    this.data = {
      convenioNomina: false,
      itauRentable: false,
      productSelected: false,
      afc: false,
      ahorroProgramado: false
    };
    this.datosFlujoCP = JSON.parse(sessionStorage.getItem("datosFlujo"));
    if (!!this.datosFlujoCP && this.datosFlujoCP.seleccionProductos === true) {
      this.enableClose = true;
    }
  }

  resetVariablesChip() {
    this.messageChip = false;
  }

  productSelected(value: string) {
    console.log(value);
    if (!this.active) {
      this.tipoCuenta = this.activeProduct(value);
      if (this.productNameSelected === value) {
        this.desactiveProduct();
        this.tipoCuenta = "";
      } else {
        this.serviceFailed = false;
        this.showCard = false;
        this.activeProduct(value);
        this.productNameSelected = value;
      }
    }
    console.log(this.data);
    return this.data;
  }

  desactiveProduct() {
    // tslint:disable-next-line:forin
    for (const prop in this.data) {
      if (this.data[prop]) {
        this.data[prop] = false;
      }
    }
    this.productNameSelected = "";
  }

  /* Metodo para activar los productos */
  activeProduct(tipoProducto) {
    const infoProduct = this.infoProductSelected(tipoProducto);
    this.data = {
      convenioNomina: tipoProducto === "nómina" ? true : false,
      itauRentable: tipoProducto === "rentable" ? true : false,
      tradicional: tipoProducto === "tradicional" ? true : false,
      afc: tipoProducto === "AFC" ? true : false,
      ahorroProgramado: tipoProducto === "ahorro" ? true : false,
      basica: tipoProducto === "básica" ? true : false,
      codProducto: infoProduct[0],
      desProducto: infoProduct[1],
      codSubProducto: infoProduct[2],
      desSubProducto: infoProduct[3]
    };
    return infoProduct[1] + ' - ' + infoProduct[3];
  }

  /* Metodo para enviar informacion de los productos */
  infoProductSelected(tipoProducto) {
    let infoProduct = [];
    if ((tipoProducto === 'nómina')
        && this.data.convenioNomina === false
        && this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio === "0") {

      this.modalIsShowed = true;
      this.dataModal = {
        imagen: REJECT_AGREEMENT.imagen,
        principalText: REJECT_AGREEMENT.principalText,
        buttonAgreement: REJECT_AGREEMENT.buttonAgreement,
        buttonText1: REJECT_AGREEMENT.buttonText1,
        class: REJECT_AGREEMENT.class
      };
    }
    const productFoundSelected = filtrarCatalogo(tipoProducto, this.productList, 'valor');
    return infoProduct = [
      productFoundSelected[0].llavePadre,
      productFoundSelected[0].valorPadre,
      productFoundSelected[0].llave,
      productFoundSelected[0].valor,
    ];
  }

  sendValue(value) {
    if (-1 !== this.cardSelected.indexOf(value)) {
      const index = this.cardSelected.indexOf(value);
      this.cardSelected.splice(index, 1);
    } else {
      this.cardSelected[0] = value;
      if (this.cardSelected.length > 0) {
        this.card = true;
      } else {
        this.card = false;
      }
    }
    console.log(this.productSelected);
  }

  finalizar() {
    this.isLoadingActive = true;
    this.finalizarTarea = this.poMapping.mappingGenericPO(this.taskId);
    this._bpmService.endTask(this.finalizarTarea).then(
      res => {
        console.log("Caracterizar Producto: Response Finalizar tarea");
        console.log(res);
        this.app.global.id = "";
        this.app.global.showId = false;
        this.isLoadingActive = false;
      },
      err => {
        console.log("Caracterizar Producto: Response Error Finalizar tarea");
        console.log(err);
        this.isLoadingActive = false;
      }
    );
  }

  goToInbox() {
    this.router.navigate(["portal/bandeja-tareas"]);
  }

  finalizarVenta() {
    if (this.enableClose) {
      this.active = true;
      this.messageChip = true;
      this.generatePDF().then(async res => {
        await this.finalizar();
      });
      this.sendMailNotification();
      this.sendEvent();
      this.activeButton = true;
    } else {
      this.activeButton = true;
    }
  }

  async sendEvent() {
    const messageEvent = new EventMessage();
    messageEvent.api = EVENT_MESSAGE_CONSTANTS.API;
    messageEvent.level = LEVEL.BO;
    messageEvent.operation = this.OPERATION_EVENT_NAME;
    messageEvent.messageBody = this.solicitud;
    this._eventosService.sendEvent(messageEvent).then(
      res => {
        console.log("Caracterizar Producto: Response enviar evento");
        console.log(res);
      },
      error => {
        console.log("Caracterizar Producto: Error enviar evento");
        console.error(error);
      }
    );
  }

  async generatePDF() {
    this.isLoadingActive = true;
    const dataWrapper = new DataWrapper(
      "co.itau.apiformatos.adapter.pdfAdapter.impl.DataAdapterVinculacionImpl",
      JSON.stringify(this.solicitud)
    );
    this._pdfService.createPDF(dataWrapper).then(
      res => {
        console.log("Caracterizar Producto: Response Generar PDF");
        console.log(res);
        const file = this.transformation.base64ToBlob(res.body, 'application/pdf');
        console.log(file);
        const fileURL = URL.createObjectURL(file);
        window.open(fileURL);
        // this.transformation.createAndDownloadBlobFile(file, NOMBRES_ARCHIVOS.VINCULACION);
        this.isLoadingActive = false;
      },
      err => {
        console.log("Caracterizar Producto: Error Response Generar PDF");
        console.log(err);
        this.isLoadingActive = false;
      }
    );
  }

  showAccountInfo(dataProducts) {
    console.log("INFORMACIÓN DE LA CUENTA");
    console.log(dataProducts);
    this.dataProducts = dataProducts;
    if (!!dataProducts) {
      const bodyStartService = new IniciarServicio();
      bodyStartService.idService = ID_SERVICE_BPM.GS_PRODUCTO_SUGERIDO;

      let tieneConvenio = false;
      if (!!this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio && this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio !== "0") {
        tieneConvenio = true;
      }

      const parameters = {
        codSubproducto : this.data.codSubProducto,
        convenioNomina : tieneConvenio
      };
      bodyStartService.parameters = JSON.stringify(parameters);
      this._bpmService.startService(bodyStartService).then(
        result => {
           const str = result.body.body.data.data.productoSugerido;
           const suggestedProducts = str.split("-");
          if (suggestedProducts.length > 0) {
            this.suggestedBoolean = true;
            this.suggestedProducts = [];
            for (let i = 0; i < suggestedProducts.length; i++) {
              if (filtrarCatalogo(suggestedProducts[i], this.productList, 'llave').length > 0) {
                this.suggestedProducts.push(filtrarCatalogo(suggestedProducts[i], this.productList, 'llave')[0].valor);
              }
            }
          }
        },
        error => {
          console.log("Caracterizar Producto: Error startService");
          console.log(error);
        });
    }
    this.data = {
      convenioNomina: false,
      itauRentable: false,
      tradicional: false,
      afc: false,
      ahorroProgramado: false
    };
    this.showCard = false;
    this.tipoCuenta = "";
  }

  showLoadingCard(value, domToScroll) {
    if (!!domToScroll) {
      domToScroll.scrollIntoView({ block: "start", behavior: "smooth" });
    }
    console.log("VALOR DEL CARGAR CARTA");
    console.log(value);
    this.showCard = value;
  }

  solicitudEmit(solicitud) {
    this.solicitud = solicitud;
    this.loadSorProducts();
    this.getProductosOfertaCliente();
  }

  modalErrorOpenCard(modalErrorOpenCard) {
    this.modalIsShowed = modalErrorOpenCard;
    this.dataModal = {
      imagen: ERROR_OPENCARD.imagen,
      principalText: ERROR_OPENCARD.principalText,
      buttonAgreement: ERROR_OPENCARD.buttonAgreement,
      buttonText1: ERROR_OPENCARD.buttonText1,
      class: ERROR_OPENCARD.class
    };
  }

  servicefail(value) {
    this.serviceFailed = value;
    console.log("SERVICIO FALLA VARIABLE");
    console.log(this.serviceFailed);
  }

  validScreen(value) {
    this.isLoadingActive = value;
  }

  acordionProducts() {
    if (this.boolenAcordion) {
      this.boolenAcordion = false;
    } else {
      this.boolenAcordion = true;
    }
  }

  openModal() {
    this.boolenModal = true;
  }

  closeModal() {
    this.boolenModal = false;
  }

  sendValue2(accountSubtype, accountNumber) {
    if (
      -1 !==
      this.productscertificateSelect.indexOf(
        accountSubtype + "_" + accountNumber
      )
    ) {
      const index = this.productscertificateSelect.indexOf(
        accountSubtype + "_" + accountNumber
      );
      this.productscertificateSelect.splice(index, 1);
    } else {
      this.productscertificateSelect.push(accountSubtype + "_" + accountNumber);
    }
  }

  metodoMappingCertProd(productscertificateSelect): DataCerProducto {
    const dataCerProducto = new DataCerProducto();
    const fullname =
      this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre +
      " " +
      this.solicitud.datosSolicitud.personaNatural[0].datosBasicos
        .primerApellido +
      " " +
      this.solicitud.datosSolicitud.personaNatural[0].datosBasicos
        .segundoApellido;
    dataCerProducto.aQuienInterese = "A quién le interese";
    dataCerProducto.numeroIdentificacion = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion;
    dataCerProducto.personaReferencia = fullname;
    dataCerProducto.tipoIdentificacion = this.transformation.changeTipoIdentificacion(
      this.solicitud.datosSolicitud.personaNatural[0].datosBasicos
        .codTipoIdentificacion
    );
    dataCerProducto.prodsClienteList = new Array<ProductoClienteCer>();

    const productscertificateSelectArray = [];
    productscertificateSelectArray.push(productscertificateSelect);

    for (let idx = 0; idx < productscertificateSelectArray.length; idx++) {
      const producto = productscertificateSelectArray[idx].split("_")[0];
      const numeroCuenta = productscertificateSelectArray[idx].split("_")[1];
      const date = this.transformation.GenerateFormatDateEsp();
      dataCerProducto.prodsClienteList.push(
        new ProductoClienteCer(producto, numeroCuenta, date)
      );
    }
    return dataCerProducto;
  }

  generarPDFCertProd() {
    this.isLoadingActive = true;
    for (let idx = 0; idx < this.productscertificateSelect.length; idx++) {
      const body = this.metodoMappingCertProd(
        this.productscertificateSelect[idx]
      );
      const dataWrapper = new DataWrapper(
        "co.itau.apiformatos.adapter.pdfAdapter.impl.DataAdapterCertificacionProductoImpl",
        JSON.stringify(body)
      );
      this._pdfService.createPDF(dataWrapper).then(
        res => {
          console.log(
            "Caracterizar Producto: Response Generar Certificado Producto"
          );
          const file = this.transformation.base64ToBlob(res.body, 'application/pdf');
          console.log(file);
          const fileURL = URL.createObjectURL(file);
          window.open(fileURL);
          this.isLoadingActive = false;
        },
        err => {
          console.log(
            "Caracterizar Producto: Error Response Generar Certificado Producto"
          );
          console.log(err);
          this.isLoadingActive = false;
        }
      );
    }
  }

  /**
   * Metodo para cargar los productos previamente creados y almacenados en sor
   */
  loadSorProducts() {
    if (!!this.solicitud.datosSolicitud
          && !!this.solicitud.datosSolicitud.personaNatural
          && !!this.solicitud.datosSolicitud.personaNatural[0]
          && !!this.solicitud.datosSolicitud.personaNatural[0].producto
          && this.solicitud.datosSolicitud.personaNatural[0].producto.length > 0) {
      for (let x = 0 ; x < this.solicitud.datosSolicitud.personaNatural[0].producto.length ; x++) {
        const producto = this.solicitud.datosSolicitud.personaNatural[0].producto[x];
        const prodAlmacenado = this.dataProducts.find(function (obj) { return (obj.accountNumber.trim() === producto.numeroCuenta.trim() && obj.accountCodeSubType === producto.codSubProducto); });
        if (!(!!prodAlmacenado)) {
          if (!!this.dataProducts === false || (!!this.dataProducts && this.dataProducts.length === 0)) {
            this.dataProducts = [];
          }
          const product = new DatosCuenta();
          product.codeAccount = producto.codProducto;
          product.accountType = producto.desProducto;
          product.accounSubtType = producto.desSubProducto;
          product.accountCodeSubType = producto.codSubProducto;
          product.accountNumber = producto.numeroCuenta;
          product.nombreTarjeta = !!producto.datosAdicionales && !!producto.datosAdicionales.tarjetaSeleccionada ? producto.datosAdicionales.tarjetaSeleccionada : "";
          product.numeroTarjeta = !!producto.datosAdicionales && !!producto.datosAdicionales.numeroTarjeta ? producto.datosAdicionales.numeroTarjeta : "";
          this.dataProducts.unshift(product);
        }
      }
    }
  }

   /**
    * Metodo para cerrar el modal de convenio de nomina
    * @param value
    */
  closeModalAgreement(value: boolean ) {
    this.modalIsShowed = value;
  }
  /**
   * Metodo para enviar notificacion via email de cada uno de los productos creados
   */
  sendMailNotification() {
    try {
      if (!!this.dataProducts
            && this.dataProducts.length > 0
            && !!this.solicitud.datosSolicitud.personaNatural[0].ubicacion
            && !!this.solicitud.datosSolicitud.personaNatural[0].ubicacion.correoElectronico) {
        for (let x = 0 ; x < this.dataProducts.length ; x++) {
          const element = this.dataProducts[x];
          let codigoNotificacion = "";
          const datosEmail = {};
          datosEmail[PARAMS_NOTIFICACION_CREAR_PROD.PRIMER_NOMBRE_CLIENTE] = this.transformation.captitalizeText(this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre);
          datosEmail[PARAMS_NOTIFICACION_CREAR_PROD.NUMERO_CUENTA] = this.transformation.getLastFourNumbersAccount(element.accountNumber);
          const detailProduct = this.findDetailProduct(this.solicitud.datosSolicitud.personaNatural[0].producto, element.accountCodeSubType.trim(), element.accountNumber.trim());
          if (!!detailProduct) {
            codigoNotificacion = this.getEmailTemplateCode(detailProduct.codSubProducto, (detailProduct.codSubProducto === REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_TRADICIONAL ? detailProduct.datosAdicionales.tarjetaSeleccionada  : ""));
            if (!!codigoNotificacion) {
              if (detailProduct.codSubProducto === REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_AHORRO_PROGRAMADO && !!detailProduct.datosAdicionales) {
                datosEmail[PARAMS_NOTIFICACION_CREAR_PROD.MONTO_AHORRO] = !!detailProduct.datosAdicionales.montoAhorroPeriodico ? this.itauCurrencyMoney.transform(detailProduct.datosAdicionales.montoAhorroPeriodico) : "";
                datosEmail[PARAMS_NOTIFICACION_CREAR_PROD.DIA_DEBITO] = !!detailProduct.datosAdicionales.diaDebito ? detailProduct.datosAdicionales.diaDebito : "";
                datosEmail[PARAMS_NOTIFICACION_CREAR_PROD.OBJETIVO_AHORRO] = !!detailProduct.datosAdicionales.objetivoAhorroProgramado ? this.transformation.captitalizeText(detailProduct.datosAdicionales.objetivoAhorroProgramado) : "";
              }
              let additionalSubject =  (REQUEST_SEND_EMAIL_NOTIFICATION.SUBJECT_CREATE_PRODUCTO.replace('###NOMBRE_PROD###', (detailProduct.desProducto + " - " + detailProduct.desSubProducto)));
              additionalSubject = additionalSubject.replace("###NUM_PROD###", this.transformation.getLastFourNumbersAccount(element.accountNumber));
              const emailSubject = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre + additionalSubject;
              const bodyEmailNotification =
                  this.notificationMapping.mappingSendEmailNotification(codigoNotificacion,
                                                                        emailSubject,
                                                                        this.solicitud.datosSolicitud.personaNatural[0].ubicacion.correoElectronico, datosEmail);
              this.callNotificationService(bodyEmailNotification);
            } else {
              console.error("NO SE ENCONTRO CODIGO DE PLANTILLA PARA EL PRODUCTO");
            }
          }
        }
      }
    } catch (e) {
      console.error("Error intentando notificar vía email: ");
      console.error(e);
    }
  }

  /**
   * Metodo para obtener el codigo de la plantilla del correo de creacion del producto
   * @param accountCodeSubType sub codigo del producto
   * @param cardSelected si se selecciona entre banca personal o standard para ahorros tradicional
   */
  getEmailTemplateCode(accountCodeSubType, cardSelected) {
    let templateCode = "";
    switch (accountCodeSubType) {
      case REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_TRADICIONAL:
        if (cardSelected === TARJETAS_SELECCIONADAS.DEBIT_STANDARD) {
          templateCode = CODIGO_NOTIFICACION.EMAIL_SUCURSALES;
        } else if (cardSelected === TARJETAS_SELECCIONADAS.DEBIT_PERSONAL_BANK) {
          templateCode = CODIGO_NOTIFICACION.EMAIL_PERSONAL_BANK;
        }
      break;
      case REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_NOMINA:
        templateCode = CODIGO_NOTIFICACION.EMAIL_NOMINA;
      break;
      case REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_ITAU_RENTABLE:
        templateCode = CODIGO_NOTIFICACION.EMAIL_RENTABLE;
      break;
      case REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_AHORRO_PROGRAMADO:
        templateCode = CODIGO_NOTIFICACION.EMAIL_AHORRO_PROGRAMADO;
      break;
    }
    return templateCode;
  }

  /**
   * Metodo para invocar el servicio que envia el email
   * @param bodyEmailNotification
   */
  callNotificationService(bodyEmailNotification) {
    this._notificationService.sendEmailNotification(bodyEmailNotification).then(
      result => {
        console.log("Consultar cliente: Response sendEmailNotification");
        console.log(result.body);
      },
      error => {
        console.error("Consultar cliente: Error sendEmailNotification");
        console.error(error);
      }
    );
  }

  /**
   * Metodo para encontrar el objeto que contiene la informacion del producto entre el catalogo de productos obtenidos en sor
   * @param productsList
   * @param codSubproducto
   * @param numCuenta
   */
  findDetailProduct(productsList, codSubproducto, numCuenta) {
    let result = null;
    if (!!productsList && productsList.length > 0) {
      result = productsList.find(
        function (obj) {
          return (obj.codSubProducto === codSubproducto && obj.numeroCuenta === numCuenta);
        }
      );
    }
    return result;
  }

  /**
   * Metodo que obtiene los codigos de los productos ofrecidos para el cliente
   */
  getProductosOfertaCliente() {
    const bodyStartService = new IniciarServicio();
    const ingresoDeclarado = (!!this.solicitud
                                && !!this.solicitud.datosSolicitud
                                && !!this.solicitud.datosSolicitud.personaNatural
                                && !!this.solicitud.datosSolicitud.personaNatural[0]
                                && !!this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera
                                && !!this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoPrincipalCore) ? this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoPrincipalCore : 0;
    bodyStartService.idService = ID_SERVICE_BPM.GS_OFERTA_PRODUCTOS;
    const parameters = {
      'ingresoDeclarado' : ingresoDeclarado
    };
    bodyStartService.parameters = JSON.stringify(parameters);
    this._bpmService.startService(bodyStartService).then(
      resOk => {
        if (!!resOk
            && !!resOk.body
            && !!resOk.body.body
            && !!resOk.body.body.data
            && !!resOk.body.body.data.data
            && !!resOk.body.body.data.data.ofertaProducto
            && !!resOk.body.body.data.data.ofertaProducto.items
            && resOk.body.body.data.data.ofertaProducto.items.length > 0) {
          this.productosOferta = resOk.body.body.data.data.ofertaProducto.items;
        }
      },
      error => {
        console.error("Crear Producto: Error startService Regla - GS OFERTA PRODUCTOS");
        console.log(error);
      }
    );
  }
}
