import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatetProductComponent } from './createt-product.component';

describe('CreatetProductComponent', () => {
  let component: CreatetProductComponent;
  let fixture: ComponentFixture<CreatetProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatetProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatetProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
