import { Component, OnInit } from '@angular/core';
import { REJECT_USER } from '../../../shared/constants/modals.constant';
import { SolicitudesServiceService } from '../../../shared/services/solicitudes-service.service';
import { Solicitud } from '../../models/negocio/Solicitud';
import { FinalizarTarea } from '../../../shared/models/request/FinalizarTarea';
import { POMapping } from '../../functions/mapping/POMapping';
import { AppComponent } from '../../../app.component';

@Component({
  selector: 'app-reject-page',
  templateUrl: './reject-page.component.html',
  styleUrls: ['./reject-page.component.scss']
})
export class RejectPageComponent implements OnInit {
  public modalIsShowed = false;
  public dataModal: any;
  public solicitud: Solicitud;
  public instanceId: string;
  public taskId: string;
  public finalizarTarea: FinalizarTarea;
  public poMapping: POMapping;
  public noFinalizarTarea = false;

  constructor(
    private _solicitudesService: SolicitudesServiceService,
    private app: AppComponent
  ) {
    this.finalizarTarea = new FinalizarTarea();
    this.app.global.nombre = sessionStorage.getItem("fullname");
    this.app.global.id = sessionStorage.getItem("instanceId");
    this.app.global.showHeader = true;
    this.app.global.showId = true;
    this.poMapping = new POMapping();
  }

  ngOnInit() {

    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");

    this._solicitudesService.getByInstanceId(this.instanceId).then(
      result => {
        if (!!result.body) {
          console.log("Notificar Rechazo Cliente: Respuesta consulta SOR");
          console.log(result);
          this.solicitud = result.body;
          this.finalizarTarea = this.poMapping.mappingGenericPO(this.taskId);
          const fullname = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido;
          this.dataModal = {
            imagen: REJECT_USER.imagen,
            principalText: REJECT_USER.principalText,
            secondaryText: fullname + " | C.C. " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion,
            otherText: REJECT_USER.otherText,
            buttonPdf: REJECT_USER.buttonPdf,
            buttonText1: REJECT_USER.buttonText1,
            button: REJECT_USER.button,
            buttonCloseProcess: REJECT_USER.buttonCloseProcess,
            class: REJECT_USER.class
          };
          this.modalIsShowed = true;
        } else {
          console.warn("Notificar Rechazo Cliente: Consulta SOR - No Hay Resultados");
        }
      },
      err => {
        console.log("Notificar Rechazo Cliente: Error consulta SOR");
        console.log(err);
      });
  }
}
