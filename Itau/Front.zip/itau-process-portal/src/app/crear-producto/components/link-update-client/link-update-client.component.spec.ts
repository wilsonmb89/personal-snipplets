import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkUpdateClientComponent } from './link-update-client.component';

describe('LinkUpdateClientComponent', () => {
  let component: LinkUpdateClientComponent;
  let fixture: ComponentFixture<LinkUpdateClientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkUpdateClientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkUpdateClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
