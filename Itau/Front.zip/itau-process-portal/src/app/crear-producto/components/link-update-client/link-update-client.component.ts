
import { AddressValidator } from '../../../shared/functions/util/validations/AddressValidator';
import { GENERATE_PDF, SUPPORT } from '../../../shared/constants/modals.constant';
import { FinalizarTarea } from "../../../shared/models/request/FinalizarTarea";
import { Component, OnInit, AfterViewInit, AfterContentChecked, HostListener } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { Observable } from "rxjs/Rx";
import { map, startWith } from "rxjs/operators";
import { SolicitudesServiceService } from "../../../shared/services/solicitudes-service.service";
import { CatalogosServiceService } from "../../../shared/services/catalogos-service.service";
import { CatalogosNameValuePair } from "../../models/catalogos";
import { CustomerService } from '../../services/customer.service';
import { Solicitud } from "../../models/negocio/Solicitud";
import { FormularioViculacionSORMapping } from "../../functions/mapping/FormularioVinculacionSORMapping";
import { CustomerServiceMapping } from '../../functions/mapping/CustomerServiceMapping';
import { POMapping } from '../../functions/mapping/POMapping';
import { ValidateSection } from '../../../shared/functions/util/validations/ValidateSection';
import { AppComponent } from '../../../app.component';
import { ExperianService } from '../../services/experian.service';
import { ExperianMappingV2 } from '../../functions/mapping/ExperianMappingV2';
import { nombreValorCatalogValidator, ciudadCatalogValidator, valorNombreCatalogValidator, exactLengthValidator } from '../../../shared/functions/util/validations/CustomValidators';
import { filtrarCatalogo } from '../../../shared/functions/util/Filter';
import { TransformationHelper } from '../../functions/util/Transformation';
import { IniciarServicio } from '../../../shared/models/bpm/iniciarServicio';
import { ID_SERVICE_BPM } from '../../../shared/constants/codigosServicios.constant';
import { BpmService } from "../../../shared/services/bpm.service";
import { EventMessage } from '../../../shared/models/eventos/message-eventos';
import { EVENT_MESSAGE_CONSTANTS, LEVEL } from '../../../shared/constants/mensaje-eventos-constant';
import { EventService } from '../../../shared/services/eventos.service';


@Component({
  selector: "app-link-update-client",
  templateUrl: "./link-update-client.component.html",
  styleUrls: ["./link-update-client.component.scss"]
})
export class LinkUpdateClientComponent implements OnInit, AfterViewInit, AfterContentChecked {

  public solicitudJSON: any[];
  public solicitud: Solicitud;
  public formLinkForm: FormGroup;
  public transformationHelper: TransformationHelper;
  public user: any = {
    nameEmp: ""
  };
  private OPERATION_EVENT_NAME = "vinculacionActualizacion";
  private _sectionValidatior = new ValidateSection();
  public sectionErrors = [];
  public controlTiposProducto = [];
  public addressValidator = new AddressValidator();
  isLinear = false;
  instanceId: string;
  public actualDate = new Date().toISOString();
  public finalizarTarea: FinalizarTarea;
  public taskId: string;
  public modalIsShowed = false;
  public errorMessage = false;
  public errorInter = false;
  public errorMessagePhoenix = false;
  public errorMessageFinal = false;
  public errorMessageTxt = "";
  public globalTimer = 0;
  public globalTimerAux = 0;
  public sectionTargetController = "";
  public visibilidadCIIU: boolean;
  public isLoadingActive = false;
  public isLockedScreen = false;
  public validAddress = false;
  public validAddressEmp = false;
  public codigoErrorOperacionPhoenix = "";
  public poMapping: POMapping;
  public sorMappging: FormularioViculacionSORMapping;
  public customerServiceMapping: CustomerServiceMapping;
  public experianMapping: ExperianMappingV2;
  public errorMessageTxtPhoe: string;
  public formUpdate = false;
  public supportIncome = false;

  requiredMonedaExtr = false;
  requiredPais = false;
  requiredSectionEmpresa = false;
  isIndependetCapital = false;

  dayFocus = false;
  monthFocus = false;
  yearFocus = false;

  toggleSexoFocus = false;
  toggleEesPaisControlFocus = false;
  toggleSirPaisControlFocus = false;
  toggleopeExtControlFocus = false;
  toggleTitularMonExtranjFocus = false;
  isSticky = false;

  options_full: string[] = [""];
  options_empty: string[] = [""];
  filteredOptionsDate: Observable<any[]>;
  filteredOptionsCountry: Observable<any[]>;
  filteredOptionsCoinCountry: Observable<any[]>;
  filteredOptionsCatalog: Observable<any[]>;
  filteredOptionsLocate: Observable<any[]>;
  filteredOptionsBirth: Observable<any[]>;
  filteredOptionsNomina: Observable<any[]>;

  ciudades: any[];
  ciudades_empty: any[];
  infoMessage: String;
  paises: any[];
  paises_empty: any[];
  lstCiiu: any[];
  lstCiiu_empty: any[];
  lstNomina: any[];
  lstNomina_empty: any[];
  lstTipoOperacion: any[];
  bodyPdf: any = {};
  dataModal: any;

  public flat: any = 'flat';


  constructor(
    private app: AppComponent,
    private _bpmService: BpmService,
    private _experianService: ExperianService,
    private _customerService: CustomerService,
    private catalogoService: CatalogosServiceService,
    private _solicitudesService: SolicitudesServiceService,
    private _eventosService: EventService
  ) {

    this.solicitud = new Solicitud();
    window.scroll(0, 0);

    this.ciudades_empty = [];
    this.paises_empty = [];
    this.lstCiiu_empty = [];
    this.lstTipoOperacion = [];
    this.lstNomina_empty = [];

    this.getCiudades();
    this.getPaises();
    this.getParametros("CIIU");
    this.getTipoOperacion("CONCEPTO_OTROS_INGRESOS");
    this.getNomina();

    this.app.global.nombre = sessionStorage.getItem("fullname");
    this.app.global.id = sessionStorage.getItem("instanceId");
    this.app.global.scrollHide = true;
    this.app.global.showHeader = true;
    this.app.global.showId = true;

    this.sorMappging = new FormularioViculacionSORMapping();
    this.poMapping = new POMapping();
    this.customerServiceMapping = new CustomerServiceMapping();
    this.experianMapping = new ExperianMappingV2();
    this.transformationHelper = new TransformationHelper();
  }

  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    this.isSticky = window.pageYOffset >= 10;
  }

  ngOnInit() {

    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");

    this.formLinkForm = new FormGroup({
      countryCoinCity: new FormControl('', [Validators.maxLength(20)]),
      dateDay: new FormControl('', [Validators.required, Validators.max(31), Validators.min(1), Validators.pattern(/^\d+$/)]),
      dateMonth: new FormControl('', [Validators.required, Validators.max(12), Validators.min(1), Validators.pattern(/^\d+$/)]),
      dateYear: new FormControl('', [Validators.required, Validators.min(0), Validators.pattern(/^\d+$/)]),
      entity: new FormControl('', [Validators.maxLength(26)]),
      email: new FormControl('', [Validators.required, Validators.maxLength(40), Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
      phone: new FormControl('', [Validators.required, Validators.maxLength(10), Validators.minLength(10)]),
      date: new FormControl([Validators.maxLength(20)]),
      address: new FormControl('', [Validators.required, Validators.maxLength(80), this.addressValidator.addressComparison()]),
      search: new FormControl('', [Validators.maxLength(20)]),
      country: new FormControl('', [Validators.maxLength(100)]),
      ciiu_control: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      sexoControl: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      nameEmp: new FormControl('', [Validators.maxLength(100), Validators.pattern(/^[a-zA-Z0-9\s]+$/)]),
      addEmp: new FormControl('', [Validators.maxLength(80), this.addressValidator.addressComparison()]),
      locate: new FormControl('', [Validators.maxLength(100)]),
      phoneEmp: new FormControl('', [Validators.minLength(7)]),
      nomina: new FormControl('', [Validators.maxLength(200)]),
      main: new FormControl('', [Validators.maxLength(20), Validators.min(100000)]),
      others: new FormControl('', [Validators.maxLength(20)]),
      output: new FormControl('', [Validators.maxLength(20), Validators.min(100000)]),
      total: new FormControl('', [Validators.maxLength(20), Validators.min(100000)]),
      pasive: new FormControl('', [Validators.maxLength(20)]),
      operation: new FormControl('', [Validators.required, Validators.maxLength(20)]),
      numero: new FormControl('', [Validators.maxLength(20)]),
      countryCoin: new FormControl('', [Validators.maxLength(100)]),
      coin: new FormControl('', [Validators.maxLength(25)]),
      amount: new FormControl('', [Validators.maxLength(25)]),
      place: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      birthplace: new FormControl('', [Validators.maxLength(100), Validators.required]),
      resPaisControl: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      dirPaisControl: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      opeExtControl: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      tipoOpeControl: new FormControl('', [Validators.maxLength(200)]),
      typeOcup: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      conceptoing: new FormControl('', [Validators.maxLength(200)]),
      patrimonio: new FormControl('', [Validators.maxLength(200)]),
      tipoOperacionesInter: new FormControl('', [Validators.maxLength(20)]),
      tipoOperacionesOtro: new FormControl('', [Validators.maxLength(20)]),
      tipoOperacionesServ: new FormControl('', [Validators.maxLength(20)]),
      tipoOperacionesCred: new FormControl('', [Validators.maxLength(20)]),
      tipoOperacionesInve: new FormControl('', [Validators.maxLength(20)]),
      tipoOperacionesExpo: new FormControl('', [Validators.maxLength(20)]),
      codDepto: new FormControl("", [Validators.maxLength(20)]),
      numpro: new FormControl("", [Validators.maxLength(25)]),
      otherConcept: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      typpro: new FormControl('', [Validators.maxLength(200)]),
      titularMonExtranj: new FormControl('', [Validators.required, Validators.maxLength(200)]),
      estimatedIncome: new FormControl('', [Validators.maxLength(20)]),
      validatedIncome: new FormControl('', [Validators.maxLength(20)]),
      cityCoin: new FormControl('', [Validators.maxLength(100)]),
      suppIncome: new FormControl()
    });
    this._solicitudesService.getByInstanceId(this.instanceId).then(
      async result => {
        if (!!result.body) {
          console.log("Formulario Vinculacion: Respuesta consulta SOR");
          console.log(result.body);
          this.solicitud = result.body;
          if (!!this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.fechaNacimiento) {
            this.formUpdate = true;
            this.formLinkForm.get("dateDay").disable();
            this.formLinkForm.get("dateMonth").disable();
            this.formLinkForm.get("dateYear").disable();
            this.formLinkForm.get("sexoControl").disable();
            if (!!this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codOcupacion) {
              this.setCIIU(this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codOcupacion);
            }
          }
          await this.getCustIncomeEstimated(0);
          this.catalogoService.loadCatalog("PAIS").then(
            response => {
              const list = response.body;
              const countrys = list.map(catalog => {
                return { nombre: catalog.valor, valor: catalog.llave };
              });
                this.catalogoService.loadCatalog("CIIU").then(
                  response => {
                    const list = response.body;
                    const listCiiu = list.map(catalog => {
                      return { nombre: catalog.valor, valor: catalog.llave, nombreSector: catalog.valorPadre, valorSector: catalog.llavePadre };
                    });
                    // tslint:disable-next-line: no-unused-expression
                    this.sorMappging.mappingSolicitudFormularioVinculacionAutollenado(this.formLinkForm, this.solicitud, this.requiredMonedaExtr, countrys, listCiiu)[0];
                    // @ts-ignore: Unreachable code error
                    this.requiredMonedaExtr = this.sorMappging.mappingSolicitudFormularioVinculacionAutollenado(this.formLinkForm, this.solicitud, this.requiredMonedaExtr)[1];
                    this.disabledEmpresaSection();
                  }, err => { this.infoMessage = "Ha ocurrido un error"; }
                );
            }, err => { this.infoMessage = "Ha ocurrido un error"; }
          );
        } else {
          console.warn("Formulario Vinculacion: Consulta SOR - No Hay Resultados");
        }
      },
      err => {
        console.log("Formulario Vinculacion: Error consulta SOR");
        console.error(err);
      });

    this.filteredOptionsDate = this.formLinkForm.get("place").valueChanges.pipe(
      startWith(""),
      map(value => this._filter(value))
    );
    this.filteredOptionsCountry = this.formLinkForm.get("country").valueChanges.pipe(
      startWith(""),
      map(value => this._filterCountry(value))
    );
    this.filteredOptionsCoinCountry = this.formLinkForm.get("countryCoin").valueChanges.pipe(
      startWith(""),
      map(value => this._filterCountry(value))
    );
    this.filteredOptionsCatalog = this.formLinkForm.get("ciiu_control").valueChanges.pipe(
      startWith(""),
      map(value => this._filterCatalog(value))
    );
    this.filteredOptionsLocate = this.formLinkForm.get("locate").valueChanges.pipe(
      startWith(""),
      map(value => this._filter(value))
    );
    this.filteredOptionsBirth = this.formLinkForm.get("birthplace").valueChanges.pipe(
      startWith(""),
      map(value => this._filter(value))
    );
    this.filteredOptionsNomina = this.formLinkForm.get("nomina").valueChanges.pipe(
      startWith(""),
      map(value => this._filterNomina(value))
    );

  }

  removeHidePlaceHolder() {
    const element = document.getElementById("container-adress");
    element.classList.remove("mat-form-field-hide-placeholder");
  }

  ngAfterViewInit(): void {
    this.removeHidePlaceHolder();
  }

  ngAfterContentChecked() {
    this.removeHidePlaceHolder();
  }

  private _filter(value: string): CatalogosNameValuePair[] {
    return filtrarCatalogo(value, this.ciudades, 'nombre');
  }

  private _filterCountry(value: string): any[] {
    return filtrarCatalogo(value, this.paises, 'nombre');
  }

  private _filterCatalog(value: string) {
    return filtrarCatalogo(value, this.lstCiiu, 'valor|nombre');
  }

  private _filterNomina(value: string) {
    return filtrarCatalogo(value, this.lstNomina, 'valor|nombre');
  }

  getErrorMessage() {
    return this.formLinkForm.get("email").hasError("required")
      ? "You must enter a value"
      : this.formLinkForm.get("email").hasError("email")
        ? "Not a valid email"
        : "";
  }

  validateTitMonExt(value: any) {

    this.formLinkForm.get('typpro').markAsUntouched();
    this.formLinkForm.get('numpro').markAsUntouched();
    this.formLinkForm.get('entity').markAsUntouched();
    this.formLinkForm.get('coin').markAsUntouched();
    this.formLinkForm.get('amount').markAsUntouched();
    this.formLinkForm.get('countryCoin').markAsUntouched();
    this.formLinkForm.get('cityCoin').markAsUntouched();

    this.formLinkForm.get('typpro').setValue('');
    this.formLinkForm.get('numpro').setValue('');
    this.formLinkForm.get('entity').setValue('');
    this.formLinkForm.get('coin').setValue('');
    this.formLinkForm.get('amount').setValue('');
    this.formLinkForm.get('countryCoin').setValue('');
    this.formLinkForm.get('cityCoin').setValue('');

    if (value === 'S') {
      this.requiredMonedaExtr = true;
    } else {
      this.requiredMonedaExtr = false;
    }
  }

  resetCountrySN(value: any) {
    if (value === 'S') {
      this.requiredPais = true;
    } else {
      this.requiredPais = false;
    }

    this.formLinkForm.get('country').setValue('');
    this.formLinkForm.get('country').markAsUntouched();
  }

  formValid() {
    let isValidMonedaExtr = true;
    let isValidPais = true;
    let isValidTipoOper = true;
    let isValidOtherTipoOper = true;
    let isValidOtherConcept = true;
    let isValidInfoBasic = true;
    let isValidSupportIncome = true;

    if (this.requiredMonedaExtr) {
      isValidMonedaExtr = this.formLinkForm.get('cityCoin').valid && this.formLinkForm.get('countryCoin').valid;
    }

    if (this.formLinkForm.get('dirPaisControl').value === 'S') {
      isValidPais = this.formLinkForm.get('country').valid;
    }

    if (this.formLinkForm.get('opeExtControl').value === 'S') {
      isValidTipoOper = this.getTiposProductoSelected();
    }

    if (this.formLinkForm.get('tipoOperacionesOtro').value === true) {
      isValidOtherTipoOper = this.formLinkForm.get("operation").valid;
    }

    if (this.formLinkForm.get('conceptoing').value === "Otros - 17") {
      isValidOtherConcept = this.formLinkForm.get("otherConcept").valid;
    }

    if (!this.formUpdate) {
      isValidInfoBasic = this.formLinkForm.get("birthplace").valid &&
        this.formLinkForm.get("dateDay").valid &&
        this.formLinkForm.get("dateMonth").valid &&
        this.formLinkForm.get("dateYear").valid &&
        this.formLinkForm.get('sexoControl').valid;
    }

    if (this.supportIncome) {
      isValidSupportIncome = this.formLinkForm.get("suppIncome").valid;
    }

    return (
      // Informacion Basica
      isValidInfoBasic &&

      // Contacto
      this.formLinkForm.get('address').valid &&
      this.formLinkForm.get("place").valid &&
      this.formLinkForm.get("email").valid &&
      this.formLinkForm.get("phone").valid &&
      this.formLinkForm.get("dirPaisControl").valid &&
      isValidPais &&

      // Ocupacion
      this.validateTipoOcupacion() &&

      // Informacion Financiera
      this.formLinkForm.get("main").valid &&
      this.formLinkForm.get("output").valid &&
      this.formLinkForm.get("total").valid &&
      this.formLinkForm.get("pasive").valid &&
      this.formLinkForm.get('conceptoing').valid &&
      isValidOtherConcept &&

      // Operaciones Moneda Extranjera
      this.formLinkForm.get("opeExtControl").valid &&
      isValidTipoOper &&
      isValidOtherTipoOper &&

      // Productos Moneda Extranjera
      this.formLinkForm.get('titularMonExtranj').valid &&
      this.formLinkForm.get('typpro').valid &&
      this.formLinkForm.get('numpro').valid &&
      this.formLinkForm.get("entity").valid &&
      this.formLinkForm.get("amount").valid &&
      isValidMonedaExtr &&

      // Validacion de Soporte de Ingresos
      isValidSupportIncome

    );
  }

  validateTipoOcupacion(): boolean {
    let result = true;
    const codTipoOcupacion = this.formLinkForm.get('typeOcup').value;
    if (["39", "40", "41"].indexOf(codTipoOcupacion) !== -1) { // Codigos sin empresa
      result = this.formLinkForm.get("ciiu_control").valid;
    } else if (["36", "37"]) { // Codigos con empresa
      result = this.formLinkForm.get("ciiu_control").valid &&
        this.formLinkForm.get("nameEmp").valid &&
        this.formLinkForm.get("addEmp").valid &&
        this.formLinkForm.get("locate").valid &&
        this.formLinkForm.get("phoneEmp").valid &&
        this.formLinkForm.get("nomina").valid;
    }
    return result;
  }

  getCiudades(): void {
    this.catalogoService.loadCatalog("CIUDAD").then(
      response => {
        const list = response.body;
        this.ciudades = list.map(catalog => {
          return {
            nombre: catalog.valor,
            valor: catalog.llave,
            nombreDpto: catalog.valorPadre,
            valorPadre: catalog.llavePadre
          };
        });
        if (!!this.ciudades) {
          this.formLinkForm.get("birthplace").setValidators([Validators.maxLength(80), Validators.required, ciudadCatalogValidator(this.ciudades)]);
          this.formLinkForm.get("place").setValidators([Validators.maxLength(80), Validators.required, ciudadCatalogValidator(this.ciudades)]);
          this.formLinkForm.get("locate").setValidators([Validators.maxLength(100), Validators.required, ciudadCatalogValidator(this.ciudades)]);
        }
      },
      err => {
        this.infoMessage = "Ha ocurrido un error";
      }
    );
  }

  getPaises(): void {
    this.catalogoService.loadCatalog("PAIS").then(
      response => {
        const list = response.body;
        this.paises = list.map(catalog => {
          return {
            nombre: catalog.valor,
            valor: catalog.llave
          };
        });
        if (!!this.paises) {
          this.formLinkForm.get("country").setValidators([Validators.maxLength(100), nombreValorCatalogValidator(this.paises)]);
          this.formLinkForm.get("countryCoin").setValidators([Validators.maxLength(100), nombreValorCatalogValidator(this.paises)]);
        }
      },
      err => {
        this.infoMessage = "Ha ocurrido un error";
      }
    );
  }

  getParametros(value: string): void {
    this.catalogoService.loadCatalog(value).then(
      response => {
        const list = response.body;
        this.lstCiiu = list.map(catalog => {
          return {
            nombre: catalog.valor,
            valor: catalog.llave,
            nombreSector: catalog.valorPadre,
            valorSector: catalog.llavePadre
          };
        });
        if (!!this.lstCiiu) {
          this.formLinkForm.get("ciiu_control").setValidators([Validators.maxLength(200), valorNombreCatalogValidator(this.lstCiiu)]);
        }
      },
      err => {
        this.infoMessage = "Ha ocurrido un error";
      }
    );
  }

  getTipoOperacion(value: string): void {
    this.catalogoService.loadCatalog(value).then(
      response => {
        const list = response.body;
        this.lstTipoOperacion = list.map(catalog => {
          return {
            nombre: catalog.valor,
            valor: catalog.llave
          };
        });
      },
      err => {
        this.infoMessage = "Ha ocurrido un error";
      }
    );
  }

  getNomina(): void {
    this.catalogoService.loadCatalog("CONVENIO_NOMINA").then(
      response => {
        const list = response.body;
        this.lstNomina = list.map(catalog => {
          return {
            nombre: catalog.valor,
            valor: catalog.llave
          };
        });
        if (this.lstNomina) {
          this.formLinkForm.get("nomina").setValidators([Validators.maxLength(200), nombreValorCatalogValidator(this.lstNomina)]);
        }
      },
      err => {
        this.infoMessage = "Ha ocurrido un error";
      }
    );
  }

  vincular(bodyPhoenixService, intentos) {
    this.isLoadingActive = true;
    this._customerService.addCustomer(bodyPhoenixService).then(
      respons => {
        console.log("Formulario Vinculacion: Response addCustomer");
        console.log(respons);
        const bodyTemp = respons.body;
        this.errorMessage = false;
        this.errorMessageFinal = false;
        this.isLockedScreen = false;
        const rimPhoenix = bodyTemp.partyKey.partyId;
        const bodySor: any = this.sorMappging.mappingSolicitudFormularioVinculacion(this.formLinkForm, this.solicitud, rimPhoenix, this.supportIncome);
        this._solicitudesService.update(bodySor).then(
          respons => {
            console.log("Formulario Vinculacion: Response guardado SOR");
            console.log(respons);
            respons = respons.body;
            this.finalizarTarea = this.poMapping.mappingGenericPO(this.taskId);
            const fullname = this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido + " " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido;
            if (!this.formUpdate) {
              this.dataModal = {
                imagen: GENERATE_PDF.imagen,
                principalText: fullname + " | C.C. " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion,
                secondaryText: GENERATE_PDF.secondaryText,
                buttonText1: GENERATE_PDF.buttonText1,
                buttonText2: GENERATE_PDF.buttonText2,
                buttonPdf: GENERATE_PDF.buttonPdf,
                button: GENERATE_PDF.button,
                class: GENERATE_PDF.class
              };
            } else {
              this.dataModal = {
                imagen: GENERATE_PDF.imagen,
                principalText: fullname + " | C.C. " + this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion,
                secondaryText: "Se ha actualizado exitosamente",
                buttonText1: GENERATE_PDF.buttonText1,
                buttonText2: GENERATE_PDF.buttonText2,
                buttonPdf: GENERATE_PDF.buttonPdf,
                button: GENERATE_PDF.button,
                class: GENERATE_PDF.class
              };
            }

            const datosFlujoVP = JSON.parse(sessionStorage.getItem("datosFlujo"));
            const pasaCaracterizacion = !!datosFlujoVP && datosFlujoVP.imprimirPDF ? true : false;

            if (!pasaCaracterizacion) {
              const messageEvent = new EventMessage();
              messageEvent.api = EVENT_MESSAGE_CONSTANTS.API;
              messageEvent.level = LEVEL.BO;
              messageEvent.operation = this.OPERATION_EVENT_NAME;
              messageEvent.messageBody = this.solicitud;
              this._eventosService.sendEvent(messageEvent).then(
                res => {
                  console.log("Vincular Actualizar cliente: Response enviar evento");
                  console.log(res);
                },
                error => {
                  console.log("Vincular Actualizar cliente: Error enviar evento");
                  console.error(error);
                }
              );
            }

            this.bodyPdf = <any>respons;
            this.resetErrorChip();
            this.modalIsShowed = true;
            this.isLoadingActive = false;
          },
          err => {
            this.isLoadingActive = false;
            console.log("Formulario Vinculacion: Error guardado en SOR");
            console.error(err);
          }
        );
      },
      err => {
        console.log("Formulario Vinculacion: Error en Creacion Cliente Phoenix");
        console.error(err);
        this.reintentos(bodyPhoenixService, intentos);
        this.isLoadingActive = false;
      });
  }

  reintentos(body, intentos) {
    intentos += 1;
    this.errorMessage = true;
    if (intentos < 3) {
      const segundos = Number(intentos) * Number(15);
      this.globalTimer = segundos;
      this.isLockedScreen = true;
      this.errorMessageTxt = "Ha ocurrido un problema. Reintentando en ";
      setTimeout(() => {
        this.vincular(body, intentos);
      }, segundos * 1000);
      const intervalError = setInterval(() => {
        this.globalTimer = this.globalTimer - 1;
        if (this.globalTimer < 2) {
          clearInterval(intervalError);
        }
      }, 1000);
    } else {
      this.errorMessageTxt = "No se pudo crear el cliente. Falla del servicio";
      this.errorMessage = false;
      this.errorMessageFinal = true;
      this.isLockedScreen = false;
      this.dataModal = {
        imagen: SUPPORT.imagen,
        principalText: SUPPORT.principalText,
        buttonText1: SUPPORT.buttonText1,
        support: SUPPORT.support,
        class: SUPPORT.class
      };
      this.modalIsShowed = true;
    }
  }

  onSubmit() {
    this.resetErrorChip();
    this.formLinkForm.get('date').setValue(this.formLinkForm.get('dateDay').value + this.formLinkForm.get('dateMonth').value + this.formLinkForm.get('dateYear').value);
    this.vincular(this.customerServiceMapping.addCustomerMapping(this.formLinkForm, this.solicitud), 0);
  }

  getPatrimonioValue() {
    const totalIngresos = (!!Number(this.formLinkForm.get("total").value)) ? Number(this.formLinkForm.get("total").value) : 0;
    const totalEgresos = (!!Number(this.formLinkForm.get("pasive").value)) ? Number(this.formLinkForm.get("pasive").value) : 0;
    const total = totalIngresos - totalEgresos;
    this.formLinkForm.get("patrimonio").setValue(total);
  }

  scrollTo(targetElement) {
    if (!!targetElement && targetElement.id !== this.sectionTargetController) {
      targetElement.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }

  setSectionTargetController(targetController) {
    this.sectionTargetController = targetController;
  }

  validateSection(domSection) {
    if (!!domSection && this._sectionValidatior.validateSection(domSection)) {
      if (this.sectionErrors.indexOf(domSection.id) === -1) {
        this.sectionErrors.push(domSection.id);
      }
    } else {
      if (this.sectionErrors.indexOf(domSection.id) !== -1) {
        this.sectionErrors.splice(this.sectionErrors.indexOf(domSection.id), 1);
      }
    }
  }

  restarCatalogoOthers() {
    if (this.formLinkForm.controls.others.value === null) {
      this.formLinkForm.controls.conceptoing.setValue(null);
    }

    if (this.formLinkForm.get('others').value > 0) {
      this.formLinkForm.get('conceptoing').setValidators([Validators.maxLength(200), Validators.required]);
      this.formLinkForm.get('conceptoing').updateValueAndValidity();
      this.formLinkForm.get('conceptoing').markAsUntouched();
    } else {
      this.formLinkForm.get('conceptoing').setValidators([Validators.maxLength(200)]);
      this.formLinkForm.get('conceptoing').updateValueAndValidity();
      this.formLinkForm.get('conceptoing').markAsUntouched();
    }
  }

  getTiposProductoSelected() {
    this.controlTiposProducto["tipoOperacionesInter"] = this.formLinkForm.get("tipoOperacionesInter").value;
    this.controlTiposProducto["tipoOperacionesExpo"] = this.formLinkForm.get("tipoOperacionesExpo").value;
    this.controlTiposProducto["tipoOperacionesInve"] = this.formLinkForm.get("tipoOperacionesInve").value;
    this.controlTiposProducto["tipoOperacionesCred"] = this.formLinkForm.get("tipoOperacionesCred").value;
    this.controlTiposProducto["tipoOperacionesServ"] = this.formLinkForm.get("tipoOperacionesServ").value;
    this.controlTiposProducto["tipoOperacionesOtro"] = this.formLinkForm.get("tipoOperacionesOtro").value;
    return (this.controlTiposProducto["tipoOperacionesInter"] ||
      this.controlTiposProducto["tipoOperacionesExpo"] ||
      this.controlTiposProducto["tipoOperacionesInve"] ||
      this.controlTiposProducto["tipoOperacionesCred"] ||
      this.controlTiposProducto["tipoOperacionesServ"] ||
      this.controlTiposProducto["tipoOperacionesOtro"]);
  }

  setCIIU(valor: string) {

    const visibilityLogic = this.transformationHelper.setCIIU(valor, this.formLinkForm, this.visibilidadCIIU, this.isIndependetCapital, this.requiredSectionEmpresa);

    this.visibilidadCIIU = visibilityLogic[0];
    this.requiredSectionEmpresa = visibilityLogic[1];
    this.isIndependetCapital = visibilityLogic[2];
    this.setConvenio(valor);
  }

  setConvenio(valor: string): void {

    if (valor !== "36") {
      this.formLinkForm.get("nomina").setValue("<Ninguno> - 0");
    } else {
      this.formLinkForm.get("nomina").setValue("");
    }
  }

  getCustIncomeEstimated(intentos) {
    const callGetCustIncomeEstimated = this._experianService.getCustomerIncomeEstimated(this.experianMapping.mappingToGetCustomerIncomeEstimated(this.solicitud));
    if (!!callGetCustIncomeEstimated) {
      callGetCustIncomeEstimated.then(
        response => {
          console.log("Formulario Vinculacion: getCustIncomeEstimated Response: ");
          console.log(response.body);
          if (!!response) {
            const responseJson = response.body;
            if (!!responseJson && responseJson.headerResponse.status.serverStatusCode === "00") {
              const custIncomeAmt = (!!responseJson.cust.income && !!!!responseJson.cust.income.amt) ? responseJson.cust.income.amt : null;
              const custIncomeType = (!!responseJson.cust.income && !!!!responseJson.cust.income.incomeType) ? responseJson.cust.income.incomeType : null;
              if (!!custIncomeAmt && parseInt(custIncomeAmt) > 0 && !!custIncomeType) {
                if (custIncomeType === "Estimado") {
                  this.resetErrorChip();
                  this.formLinkForm.get("estimatedIncome").setValue(Number(custIncomeAmt));
                  this.formLinkForm.get("main").setValue(Number(custIncomeAmt));
                } else if (custIncomeType === "Validado") {
                  this.resetErrorChip();
                  this.formLinkForm.get("validatedIncome").setValue(Number(custIncomeAmt));
                  this.formLinkForm.get("main").setValue(Number(custIncomeAmt));
                }
              } else {
                this.mostrarErrorChip("No se pudo consultar el ingreso principal del cliente. Falla de datos en el servicio", null, true, false, true, false);
              }
            } else {
              this.reintentarGetCustIncomeEstimated(intentos);
            }
          }
        },
        error => {
          console.log("Formulario Vinculacion: getCustIncomeEstimated Error: ");
          const errorMessage = <any>error;
          console.error(errorMessage);
          this.reintentarGetCustIncomeEstimated(intentos);
        }
      );
    } else {
      this.mostrarErrorChip("No se pudo consultar el ingreso principal del cliente. Falla de datos/servicio", null, true, false, true, false);
    }
  }

  reintentarGetCustIncomeEstimated(intentos) {
    intentos += 1;
    if (intentos < 3) {
      const segundos = Number(intentos) * Number(15);
      this.mostrarErrorChip("Ha ocurrido un problema consultando el ingreso principal del cliente. Reintentando en ", segundos, true, false, false, false);
      setTimeout(() => {
        this.getCustIncomeEstimated(intentos);
      }, segundos * 1000);
      const intervalError = setInterval(() => {
        this.globalTimer = this.globalTimer - 1;
        if (this.globalTimer < 2) {
          clearInterval(intervalError);
        }
      }, 1000);
    } else {
      this.mostrarErrorChip("No se pudo consultar el ingreso principal del cliente. Falla del servicio", null, true, false, true, false);
    }
  }

  mostrarErrorChip(errorMsg, globalTimer, errorMessage, errorMessageFinal, isTemporalMsg, isLockedScreen) {
    this.globalTimer = globalTimer;
    this.errorMessageTxt = errorMsg;
    this.errorMessage = errorMessage;
    this.errorMessageFinal = errorMessageFinal;
    this.isLockedScreen = isLockedScreen;
    if (isTemporalMsg) {
      setTimeout(() => {
        this.resetErrorChip();
      }, 4000);
    }
  }

  resetErrorChip() {
    this.errorMessageTxt = "";
    this.errorMessage = false;
    this.errorMessageFinal = false;
    this.isLockedScreen = false;
  }

  validarDireccion() {
    this.validAddress = this.formLinkForm.get('address').invalid && this.formLinkForm.get('address').value !== '' && this.formLinkForm.get('address').value !== undefined;
  }

  validarDireccionEmp() {
    this.validAddressEmp = this.formLinkForm.get('addEmp').invalid && this.formLinkForm.get('addEmp').value !== '' && this.formLinkForm.get('addEmp').value !== undefined;
  }

  closeSupport(value: boolean) {
    this.modalIsShowed = value;
  }

  resetTypeOperation() {

    this.formLinkForm.get('tipoOperacionesInter').setValue(false);
    this.formLinkForm.get('tipoOperacionesExpo').setValue(false);
    this.formLinkForm.get('tipoOperacionesInve').setValue(false);
    this.formLinkForm.get('tipoOperacionesCred').setValue(false);
    this.formLinkForm.get('tipoOperacionesServ').setValue(false);
    this.formLinkForm.get('tipoOperacionesOtro').setValue(false);
    this.formLinkForm.get('operation').setValue('');

  }

  resetValue(form: any) {
    this.formLinkForm.get(form).setValue('');
  }


  disabledEmpresaSection() {

    if ((this.formLinkForm.get('ciiu_control').value === '090 - Rentistas De Capital Solo Para Personas Naturales. - 0 - Persona Natural'
      && this.formLinkForm.get('typeOcup').value === '37')
      || this.formLinkForm.get("ciiu_control").value === "082 - Personas Naturales Subsidiadas Por Terceros - 0 - Persona Natural"
      || this.formLinkForm.get("ciiu_control").value === "082 - Personas Naturales Subsidiadas Por Terceros - 0 - Persona Natural"
    ) {

      this.isIndependetCapital = true;
      this.formLinkForm.get('locate').clearValidators();
      this.formLinkForm.get('nameEmp').clearValidators();
      this.formLinkForm.get('addEmp').clearValidators();
      this.formLinkForm.get('phoneEmp').clearValidators();


      this.formLinkForm.get('locate').updateValueAndValidity();
      this.formLinkForm.get('nameEmp').updateValueAndValidity();
      this.formLinkForm.get('addEmp').updateValueAndValidity();
      this.formLinkForm.get('phoneEmp').updateValueAndValidity();


    } else if (this.requiredSectionEmpresa) {

      this.isIndependetCapital = false;
      this.formLinkForm.get('locate').setValidators([Validators.required, ciudadCatalogValidator(this.ciudades)]);
      this.formLinkForm.get('nameEmp').setValidators([Validators.required, Validators.maxLength(100)]);
      this.formLinkForm.get('addEmp').setValidators([Validators.required, Validators.maxLength(80), this.addressValidator.addressComparison()]);
      this.formLinkForm.get('phoneEmp').setValidators([Validators.required, Validators.minLength(7), exactLengthValidator()]);

      this.formLinkForm.get('locate').updateValueAndValidity();
      this.formLinkForm.get('nameEmp').updateValueAndValidity();
      this.formLinkForm.get('addEmp').updateValueAndValidity();
      this.formLinkForm.get('phoneEmp').updateValueAndValidity();
    }
  }

  scrollFocusElement(element) {
    element.scrollIntoView({ block: "center" });
  }

  resetProdMonedaExtranjera() {
    this.formLinkForm.get("typpro").setValue("");
    this.formLinkForm.get("numpro").setValue("");
    this.formLinkForm.get("entity").setValue("");
    this.formLinkForm.get("coin").setValue("");
    this.formLinkForm.get("amount").setValue(0);
    this.formLinkForm.get("countryCoin").setValue("");
    this.formLinkForm.get("cityCoin").setValue("");
  }

  resetOperMonedaExtranjera() {
    this.formLinkForm.get("tipoOperacionesInter").setValue("");
    this.formLinkForm.get("tipoOperacionesExpo").setValue("");
    this.formLinkForm.get("tipoOperacionesInve").setValue("");
    this.formLinkForm.get("tipoOperacionesCred").setValue("");
    this.formLinkForm.get("tipoOperacionesServ").setValue("");
    this.formLinkForm.get("tipoOperacionesOtro").setValue("");
    this.formLinkForm.get("operation").setValue("");
  }

  validacionIngresos() {
    const bodyStartService = new IniciarServicio();
    bodyStartService.idService = ID_SERVICE_BPM.GS_VALIDACION_INGRESOS;
    const parameters = {
      ingresoDeclarado: parseFloat(this.formLinkForm.get('main').value),
      ingresoInferido: !!this.formLinkForm.get('estimatedIncome').value ? parseFloat(this.formLinkForm.get('estimatedIncome').value) : (!!this.formLinkForm.get('validatedIncome').value ? parseFloat(this.formLinkForm.get('validatedIncome').value) : 0),
      ocupacion: this.formLinkForm.get('typeOcup').value
    };
    bodyStartService.parameters = JSON.stringify(parameters);
    this._bpmService.startService(bodyStartService).then(
      res => {
        this.supportIncome = res.body.body.data.data.respuestaSoporteIngresos;
      },
      err => {
        console.log("Consultar cliente: Error startService - Validacion Ingresos");
        console.error(err);
      }
    );
  }
}
