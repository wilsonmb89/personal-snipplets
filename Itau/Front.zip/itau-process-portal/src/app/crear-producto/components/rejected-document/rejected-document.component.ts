import { Component, OnInit, HostListener } from '@angular/core';
import { Solicitud } from "../../models/negocio/Solicitud";
import { Router } from "@angular/router";
import { SolicitudesServiceService } from "../../../shared/services/solicitudes-service.service";
import { AppComponent } from '../../../app.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DocumentosRechazadosSORMapping } from '../../functions/mapping/DocumentosRechazadosSORMapping';
import { FinalizarTarea } from '../../../shared/models/request/FinalizarTarea';
import { POMapping } from '../../functions/mapping/POMapping';
import { BpmService } from '../../../shared/services/bpm.service';


@Component({
  selector: 'app-rejected-document',
  templateUrl: './rejected-document.component.html',
  styleUrls: ['./rejected-document.component.scss']
})
export class RejectedDocumentsComponent implements OnInit {
  public solicitud: Solicitud;
  public contRechazos: number;
  public sorMapping: DocumentosRechazadosSORMapping;
  public rejectDocument: FormGroup;
  public finalizarTarea: FinalizarTarea;
  public poMapping: POMapping;
  public isLoadingActive = false;
  public taskId: string;
  instanceId: string;
  isSticky = false;

  constructor(
    private router: Router,
    private app: AppComponent,
    private _bpmService: BpmService,
    private _solicitudesService: SolicitudesServiceService
  ) {
    window.scroll(0, 0);
    this.solicitud = new Solicitud();
    this.poMapping = new POMapping();
    this.sorMapping = new DocumentosRechazadosSORMapping();
    this.app.global.nombre = sessionStorage.getItem("fullname");
    this.app.global.id = sessionStorage.getItem("instanceId");
    this.app.global.scrollHide = true;
    this.app.global.showHeader = true;
    this.app.global.showId = true;
  }

  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    this.isSticky = window.pageYOffset >= 10;
  }

  ngOnInit() {
    this.isLoadingActive = true;
    this.instanceId = sessionStorage.getItem("instanceId");
    this.taskId = sessionStorage.getItem("taskId");

    this.rejectDocument = new FormGroup({
      comentarioRechazado: new FormControl('', [Validators.required , Validators.maxLength(1000)])
    });

    this._solicitudesService.getByInstanceId(this.instanceId).then(
      result => {
        if (!!result.body) {
          console.log("Formulario Vinculacion: Respuesta consulta SOR");
          this.solicitud = result.body;
          this.contDocRechazados(this.solicitud);
          const comentario = !!this.solicitud.datosSolicitud.personaNatural[0].documentos && !!this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos && !!this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.comentarios  ? this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.comentarios  : "";
          this.rejectDocument.get("comentarioRechazado").setValue(comentario);
          this.isLoadingActive = false;
        } else {
          console.warn("Formulario Vinculacion: Consulta SOR - No Hay Resultados");
        }
      },
      err => {
        console.log("Formulario Vinculacion: Error consulta SOR");
        console.error(err);
      });
  }

  contDocRechazados(solicitud: Solicitud): Number {
    this.contRechazos = 0;
    if (solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.soporteIngresos === "N") {
      this.contRechazos += 1;
    }
    if (solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.formularioVenta === "N") {
      this.contRechazos += 1;
    }
    if (solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.documentoId === "N") {
      this.contRechazos += 1;
    }
    if (solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.soporteProcesoId === "N") {
      this.contRechazos += 1;
    }
    if (solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.tarjetaFirmas === "N") {
      this.contRechazos += 1;
    }

    return this.contRechazos;
  }

  posponerTarea() {
    this.router.navigate(["portal/bandeja-tareas"]);
    this.app.global.scrollHide = false;
  }

  formValid() {
    return (
      this.rejectDocument.get("comentarioRechazado").valid
    );
  }

  onSubmit(): void {
    this.isLoadingActive = true;
    const body: any = this.sorMapping.mappingDocumentosRechazados(this.rejectDocument, this.solicitud);
    this._solicitudesService.update(body).then(
      res => {
        console.log("Verificar Documentos: Response guardado SOR");
        console.log(res);
        this.finalizarTarea = this.poMapping.mappingGenericPoCp(this.taskId);
        this._bpmService.endTask(this.finalizarTarea).then(
          res => {
            this.app.global.id = "";
            this.app.global.showId = false;
            this.router.navigate(["portal/bandeja-tareas"]);
            this.isLoadingActive = false;
          }, err => {
            this.isLoadingActive = false;
            console.log("Verificacion Documentos: Error en finalizar actividad");
            console.error(err);
          });
      }, err => {
        this.isLoadingActive = false;
        console.log("Seleccionar Producto: Error Post-Guardado SOR");
        console.error(err);
      }
    );
  }

}
