import { CompleteYesNoPipe } from './complete-yes-no.pipe';

describe('CompleteYesNoPipe', () => {
  it('create an instance', () => {
    const pipe = new CompleteYesNoPipe();
    expect(pipe).toBeTruthy();
  });
});
