import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'completeYesNo'
})
export class CompleteYesNoPipe implements PipeTransform {

  transform(value: any): any {
    if (value === "S") {
      return "Si";
    } else {
      return "No";
    }
  }

}
