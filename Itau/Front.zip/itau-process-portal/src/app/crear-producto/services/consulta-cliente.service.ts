import { Injectable } from '@angular/core';
import { HttpClientService } from '../../shared/services/HttpClient.service';
import { PATH_SERVICIOS_LEGADOS } from '../../shared/constants/servicePath.constant';

@Injectable()
export class ConsultaClienteService {

  constructor(public _httpClientService: HttpClientService) {}

  consult(body: any) {
    return this._httpClientService.invokePostRequest(PATH_SERVICIOS_LEGADOS.CUSTOMER_INFORMATION_GET_CUSTOMER_ORQ, body);
  }

}
