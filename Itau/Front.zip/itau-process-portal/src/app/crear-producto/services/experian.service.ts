import { Injectable } from '@angular/core';
import { HttpClientService } from '../../shared/services/HttpClient.service';
import { PATH_SERVICIOS_LEGADOS } from '../../shared/constants/servicePath.constant';

@Injectable()
export class ExperianService {

  constructor(
    public _httpClientService: HttpClientService
  ) {
  }

  getCustomerIncomeEstimated(body) {
    if (!!body) {
      const repos = this._httpClientService.invokePostRequest(PATH_SERVICIOS_LEGADOS.EXPERIAN, body);
      return repos;
    } else {
      return null;
    }
  }
}
