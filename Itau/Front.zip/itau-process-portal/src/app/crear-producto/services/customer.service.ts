import { Injectable } from '@angular/core';
import { HttpClientService } from '../../shared/services/HttpClient.service';
import { PATH_SERVICIOS_LEGADOS } from '../../shared/constants/servicePath.constant';

@Injectable()
export class CustomerService {

  constructor(
    public _httpClientService: HttpClientService
  ) {
  }

  addCustomer(body) {
    const repos = this._httpClientService.invokePostRequest(PATH_SERVICIOS_LEGADOS.CUSTOMER_ADD_CUSTOMER, body);
    return repos;
  }
}
