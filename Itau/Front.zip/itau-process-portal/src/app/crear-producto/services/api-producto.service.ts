import { Injectable } from '@angular/core';
import { HttpClientService } from '../../shared/services/HttpClient.service';
import { PATH_SERVICIOS_LEGADOS } from '../../shared/constants/servicePath.constant';

@Injectable()
export class ApiProductService {

  constructor(
    public _httpClientService: HttpClientService
  ) { }

  createProduct(body) {
    return this._httpClientService.invokePostRequest(PATH_SERVICIOS_LEGADOS.PRODUCT_ADD_ACCOUNT, body);
  }

  getProductList(body) {
    return this._httpClientService.invokePostRequest(PATH_SERVICIOS_LEGADOS.PRODUCT_GET_ACCOUNT_LIST, body);
  }

  addNumberCard(body: any) {
    return this._httpClientService.invokePostRequest(PATH_SERVICIOS_LEGADOS.CUSTOMER_DEBIT_CARD, body);
  }


}
