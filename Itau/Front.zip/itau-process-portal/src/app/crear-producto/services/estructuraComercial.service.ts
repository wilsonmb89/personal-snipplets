import { Injectable } from '@angular/core';
import { HttpClientService } from '../../shared/services/HttpClient.service';
import { PATH_SERVICIOS_LEGADOS } from '../../shared/constants/servicePath.constant';

/**
 *  Servicio que realiza la invocacion a las operaciones del servicio orgStructureByUser
 *  @author Diego Aguirre - EDA01779
 *  @since 04/01/2019
 */
@Injectable()
export class EstructuraComercialService {

    constructor(
        public _httpClientService: HttpClientService
    ) {
    }

    /**
    *  Servicio que realiza la invocacion por POST de la operacion getOrgStructure
    *  @author Diego Aguirre - EDA01779
    *  @since 04/01/2019
    */
    getOrgStructure(body) {
        if (!!body) {
            const repos = this._httpClientService.invokePostRequest(PATH_SERVICIOS_LEGADOS.OBTENER_ESTRUCTURA_COMERCIAL, body);
            return repos;
        } else {
            return null;
        }
    }
}
