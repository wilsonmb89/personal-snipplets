import { Injectable } from '@angular/core';
import { HttpClientService } from '../../shared/services/HttpClient.service';
import { PATH_SERVICIOS_LEGADOS } from '../../shared/constants/servicePath.constant';


@Injectable()
export class ConsultaListasService {

  constructor(
    public _httpClientService: HttpClientService
  ) {
  }

  validateList(listBody: any) {
    console.log("LISTBODY SERVICIO");
    console.log(listBody);
    return this._httpClientService.invokePostRequest(PATH_SERVICIOS_LEGADOS.RESTRICTIVE_LIST_GET_LIST, listBody);
  }

}
