// Navigation services
import { AuthGuardService as AuthGuard } from '../shared/services/auth-guard.service';

// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../material/material.module';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { NgxMaskModule } from 'ngx-mask';
import { GenericModalModule } from './components/generic-modal/generic-modal.module';

// Services
import { ConsultaListasService } from './services/consulta-listas.service';
import { EstructuraComercialService } from "./services/estructuraComercial.service";
import { CreatePdfService } from '../shared/services/create-pdf.service';
import { AutoflowService } from '../shared/services/autoflow.service';
import { SolicitudesServiceService } from '../shared/services/solicitudes-service.service';
import { EventService } from '../shared/services/eventos.service';
import { CustomerService } from './services/customer.service';
import { ExperianService } from './services/experian.service';
import { ApiProductService } from './services/api-producto.service';
import { NotificationService } from '../shared/services/Notification.service';
import { BpmService } from '../shared/services/bpm.service';
import { ConsultaClienteService } from './services/consulta-cliente.service';

// Pipes
import { CompleteYesNoPipe } from './pipes/complete-yes-no.pipe';
import { AddressNormalizePipe } from '../shared/pipes/addrees-normalize.pipe';
import { CapitalizeTextPipe } from '../shared/pipes/capitalize-text.pipe';
import { ItauCurrencyMoneyPipe } from '../shared/pipes/itau-currency-money.pipe';

// Directives
import { OnlyLettersDirective } from '../shared/directives/OnlyLettersDirective';
import { OnlyNumbersDirective } from '../shared/directives/OnlyNumbersDirective';
import { AddressNormalizeDirective } from '../shared/directives/AddressNormalizeDirective';
import { CapitalizeTextDirective } from '../shared/directives/CapitalizeTextDirective';
import { AddressValidator } from '../shared/functions/util/validations/AddressValidator';
import { CapitalizeOnlyFirstLetterDirective } from '../shared/directives/CapitalizeOnlyFirstLetter';

// Components
import { AsignSaleComponent } from './components/asign-sale/asign-sale.component';
import { ConsultClientComponent } from './components/consult-client/consult-client.component';
import { EmitCommercialConceptComponent } from './components/emit-commercial-concept/emit-commercial-concept.component';
import { CommercialConceptNotificationComponent } from './components/commercial-concept-notification/commercial-concept-notification.component';
import { RestrictiveListComponent } from './components/restrictive-list/restrictive-list.component';
import { LinkUpdateClientComponent } from './components/link-update-client/link-update-client.component';
import { RejectPageComponent } from './components/reject-page/reject-page.component';
import { CreatetProductComponent } from './components/createt-product/createt-product.component';
import { RejectedDocumentsComponent } from './components/rejected-document/rejected-document.component';
import { CharacterizationComponent } from './components/characterization/characterization.component';
import { VerificationDocumentsComponent } from './components/verification-documents/verification-document.component';
import { CatalogsAdminComponent } from './components/catalogs-admin/catalogs-admin.component';

const routes: Routes = [
  { path: '', redirectTo: 'asignar-venta', pathMatch: 'full' },
  { path: 'asignar-venta', component: AsignSaleComponent, canActivate: [AuthGuard]  },
  { path: 'consultar-cliente', component: ConsultClientComponent, canActivate: [AuthGuard]  },
  { path: 'listas-restrictivas', component: RestrictiveListComponent, canActivate: [AuthGuard]  },
  { path: 'vincular-actualizar-cliente', component: LinkUpdateClientComponent, canActivate: [AuthGuard]  },
  { path: 'crear-productos', component: CreatetProductComponent, canActivate: [AuthGuard]  },
  { path: 'notificar-cliente', component: RejectPageComponent, canActivate: [AuthGuard]  },
  { path: 'emitir-concepto-comercial', component: EmitCommercialConceptComponent, canActivate: [AuthGuard]  },
  { path: 'notificar-concepto-comercial', component: CommercialConceptNotificationComponent, canActivate: [AuthGuard]  },
  { path: 'verificar-documentos', component: VerificationDocumentsComponent, canActivate:  [AuthGuard] },
  { path: 'documentos-rechazados', component: RejectedDocumentsComponent, canActivate: [AuthGuard] },
  { path: 'administrar-catalogos', component: CatalogsAdminComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [
    AsignSaleComponent,
    ConsultClientComponent,
    EmitCommercialConceptComponent,
    CommercialConceptNotificationComponent,
    RestrictiveListComponent,
    LinkUpdateClientComponent,
    CreatetProductComponent,
    VerificationDocumentsComponent,
    RejectPageComponent,
    CharacterizationComponent,
    RejectedDocumentsComponent,
    CompleteYesNoPipe,
    AddressNormalizePipe,
    CapitalizeTextPipe,
    ItauCurrencyMoneyPipe,
    OnlyLettersDirective,
    OnlyNumbersDirective,
    AddressNormalizeDirective,
    CapitalizeTextDirective,
    AddressValidator,
    CapitalizeOnlyFirstLetterDirective,
    CatalogsAdminComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    SharedModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    CurrencyMaskModule,
    NgxMaskModule.forRoot(),
    GenericModalModule
  ],
  providers: [
    ConsultaListasService,
    ConsultaClienteService,
    EstructuraComercialService,
    CreatePdfService,
    AutoflowService,
    SolicitudesServiceService,
    EventService,
    CustomerService,
    ExperianService,
    ApiProductService,
    NotificationService,
    BpmService
  ]
})
export class CrearProductoModule { }
