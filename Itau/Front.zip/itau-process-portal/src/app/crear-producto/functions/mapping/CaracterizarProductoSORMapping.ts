import { FormGroup } from "@angular/forms";
import { SOR_DATOS_ADICIONALES_PRODUCTOS } from "../../constants/LlavesSOR.constant";
import { Solicitud } from "../../models/negocio/Solicitud";
import { Transformation } from "../../../shared/functions/util/Trasnformation";
import { Producto } from '../../models/negocio/Producto';
import { REQUEST_CREA_PRODUCTO_PHOENIX, TARJETAS_SELECCIONADAS } from '../../../shared/constants/codigosServicios.constant';


export class CaracterizarProductoSORMapping {

    public solicitud: Solicitud;
    public transformation: Transformation;

    constructor() {
        this.transformation = new Transformation();
    }

    mappingCaracterizarProducto(solicitudActividad: Solicitud, data: any, responseService: any, datosAdicionales: Map<string, string>, formAhorroProgramado: FormGroup, tarjetaSeleccionada: String): Solicitud {

        // Mapeo informacion solicitud anterior
        this.solicitud = solicitudActividad;

        if ((!(!!this.solicitud.datosSolicitud.personaNatural[0].producto)) || (!!this.solicitud.datosSolicitud.personaNatural[0].producto && this.solicitud.datosSolicitud.personaNatural[0].producto.length === 0)) {
            this.solicitud.datosSolicitud.personaNatural[0].producto = new Array<Producto>();
        }

        const longProductos = this.solicitud.datosSolicitud.personaNatural[0].producto.length;
        this.solicitud.datosSolicitud.personaNatural[0].producto[longProductos] = new Producto();

        // Datos basicos del producto
        this.solicitud.datosSolicitud.personaNatural[0].producto[longProductos].codProducto = !!data.codProducto ? data.codProducto : "";
        this.solicitud.datosSolicitud.personaNatural[0].producto[longProductos].desProducto = !!data.desProducto ? data.desProducto : "";
        this.solicitud.datosSolicitud.personaNatural[0].producto[longProductos].codSubProducto = !!data.codSubProducto ? data.codSubProducto : "";
        this.solicitud.datosSolicitud.personaNatural[0].producto[longProductos].desSubProducto = !!data.desSubProducto ? data.desSubProducto : "";
        this.solicitud.datosSolicitud.personaNatural[0].producto[longProductos].numeroCuenta = responseService.acctKey.acctIdent.trim();

        // Datos mod Solicitud
        this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio = !!datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.CONVENIO) ? this.transformation.splitText(datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.CONVENIO))[0] : this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio;
        this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desConvenio = !!datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.CONVENIO) ? this.transformation.splitText(datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.CONVENIO))[1] : this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio;

        try {
            if (!(!!this.solicitud.datosSolicitud.personaNatural[0].producto[longProductos].datosAdicionales)) {
                this.solicitud.datosSolicitud.personaNatural[0].producto[longProductos].datosAdicionales = {};
            }
            const dataJsonAdicional: any = {};

            // Datos Adicionales Tradicional, Nomina Tarjeta y Básica
            if (!!tarjetaSeleccionada) {
                dataJsonAdicional.tarjetaSeleccionada = tarjetaSeleccionada;
            }
            // Datos Adicionales num tarjeta
            if (!!datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.NUMERO_TARJETA)
                    && datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.NUMERO_TARJETA) !== "") {
                dataJsonAdicional.numeroTarjeta = datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.NUMERO_TARJETA);
            }
            // Datos Adicionales Itaú Rentable
            if (!!datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.MONTO_APERTURA)) {
                dataJsonAdicional.montoApertura = datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.MONTO_APERTURA);
            }
            // Datos Adicionales Nomina
            if (!!datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.CONVENIO) &&
                    responseService.acctKey.acctSubType === REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_NOMINA) {

                dataJsonAdicional.convenioNomina = datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.CONVENIO);
            }
            // Datos Adicionales Básica
            if (!!datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.CONVENIO_BASICA) &&
                    responseService.acctKey.acctSubType === REQUEST_CREA_PRODUCTO_PHOENIX.COD_CUENTA_AHORROS_BASICA) {

                dataJsonAdicional.convenioNominaBasica = datosAdicionales.get(SOR_DATOS_ADICIONALES_PRODUCTOS.CONVENIO_BASICA);
            }
            // Datos Adicionales Ahorro Programado
            if (!!formAhorroProgramado) {
                if (!!formAhorroProgramado.get("objetivoAhorroProgramado").value &&
                        !!formAhorroProgramado.get("cuentaOrigen").value &&
                        formAhorroProgramado.get("cuentaOrigen").value !== "NA" &&
                        !!formAhorroProgramado.get("montoAhorroPeriodico").value &&
                        !!formAhorroProgramado.get("diaDebito").value) {

                    dataJsonAdicional.objetivoAhorroProgramado = formAhorroProgramado.get("objetivoAhorroProgramado").value;
                    dataJsonAdicional.cuentaOrigen = formAhorroProgramado.get("cuentaOrigen").value;
                    dataJsonAdicional.montoAhorroPeriodico = formAhorroProgramado.get("montoAhorroPeriodico").value;
                    dataJsonAdicional.diaDebito = formAhorroProgramado.get("diaDebito").value;
                }
            }

            this.solicitud.datosSolicitud.personaNatural[0].producto[longProductos].datosAdicionales = dataJsonAdicional;

        } catch (e) {
            console.error("Error CaracterizarProductoSORMapping");
            console.error(e);
            this.solicitud.datosSolicitud.personaNatural[0].producto[longProductos].datosAdicionales = {};
        }

        return this.solicitud;
    }
}
