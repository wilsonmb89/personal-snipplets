import { FormGroup } from "@angular/forms";
import { Solicitud } from "../../models/negocio/Solicitud";


export class SolicitudListaRestrictivaSORMapping {

    public solicitud: Solicitud;

    constructor() { }

    mappingSolicitudListasRestrictivas(body: FormGroup, solicitudActividad: Solicitud): Solicitud {

        // Mapeo Informacion Solicitud Anterior
        this.solicitud = solicitudActividad;

        // Causal Cumplimiento
        this.solicitud.datosSolicitud.causalCumplimiento = !!body.get("causalCumplimientoControl").value ? body.get("causalCumplimientoControl").value.charAt(0).toUpperCase() + body.get("causalCumplimientoControl").value.slice(1) : "";

        return this.solicitud;
    }

}
