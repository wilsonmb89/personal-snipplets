import { AddCustomerDebitCardRelRqType } from '../../models/services/CustomerDebitCardRel/AddCustomerDebitCardRelRqType';
import { HeaderRequest } from '../../models/services/CustomerDebitCardRel/HeaderRequest';
import { MessageHeader } from '../../models/services/CustomerDebitCardRel/MessageHeader';
import { MessageInfo } from '../../models/services/CustomerDebitCardRel/MessageInfo';
import { PartyCardRelRec } from '../../models/services/CustomerDebitCardRel/PartyCardRelRec';
import { ProductCard } from '../../models/services/CustomerDebitCardRel/ProductCard';
import { AcctKey } from '../../models/services/CustomerDebitCardRel/AcctKey';
import { REQUEST_CUSTOMER_DEBIT_CARD } from '../../../shared/constants/codigosServicios.constant';
import { Solicitud } from '../../models/negocio/Solicitud';

export class CustomerDebitCardMapping {
    public addCustomerDebitCardRelRqType: AddCustomerDebitCardRelRqType;

    constructor() {
        this.addCustomerDebitCardRelRqType = new AddCustomerDebitCardRelRqType();
    }

    mappingCustomerDebitCard(solicitud: Solicitud, respuestaEnrutamiento: any, serviceProduct: any): AddCustomerDebitCardRelRqType {

        // HeaderRequest
        this.addCustomerDebitCardRelRqType.headerRequest = new HeaderRequest();
        this.addCustomerDebitCardRelRqType.headerRequest.messageHeader = new MessageHeader();
        this.addCustomerDebitCardRelRqType.headerRequest.messageHeader.messageInfo = new MessageInfo();
        this.addCustomerDebitCardRelRqType.headerRequest.messageHeader.messageInfo.systemId = "";
        this.addCustomerDebitCardRelRqType.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_CUSTOMER_DEBIT_CARD.ORIGINATOR_NAME;
        this.addCustomerDebitCardRelRqType.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_CUSTOMER_DEBIT_CARD.ORIGINATOR_TYPE;
        this.addCustomerDebitCardRelRqType.headerRequest.messageHeader.messageInfo.terminalId = "";

        // PartyCardRelRec
        this.addCustomerDebitCardRelRqType.partyCardRelRec = new PartyCardRelRec();
        this.addCustomerDebitCardRelRqType.partyCardRelRec.issuedIdentType = solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion;
        this.addCustomerDebitCardRelRqType.partyCardRelRec.issuedIdentValue = solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion;
        this.addCustomerDebitCardRelRqType.partyCardRelRec.cardCategory = REQUEST_CUSTOMER_DEBIT_CARD.CARD_CATEGORY;
        this.addCustomerDebitCardRelRqType.partyCardRelRec.productCard = new ProductCard();
        this.addCustomerDebitCardRelRqType.partyCardRelRec.productCard.bin = respuestaEnrutamiento.bin;
        this.addCustomerDebitCardRelRqType.partyCardRelRec.productCard.segmentation = respuestaEnrutamiento.producto;
        this.addCustomerDebitCardRelRqType.partyCardRelRec.productCard.affinityGroup = respuestaEnrutamiento.grupoAfinidad;

        // AcctKey
        this.addCustomerDebitCardRelRqType.acctKey = new AcctKey();
        this.addCustomerDebitCardRelRqType.acctKey.acctId = !!serviceProduct.acctKey.acctIdent ? serviceProduct.acctKey.acctIdent.trim().replace(/[-]/g, "") : "";
        this.addCustomerDebitCardRelRqType.acctKey.acctType = !!serviceProduct.acctKey.acctType ? serviceProduct.acctKey.acctType : "";
        this.addCustomerDebitCardRelRqType.acctKey.curCode = !!serviceProduct.acctKey.curCode ? serviceProduct.acctKey.curCode : "COP";
        this.addCustomerDebitCardRelRqType.acctKey.branchIdent = !!serviceProduct.acctKey.branchIdent ? serviceProduct.acctKey.branchIdent : "";

        return this.addCustomerDebitCardRelRqType;
    }
}
