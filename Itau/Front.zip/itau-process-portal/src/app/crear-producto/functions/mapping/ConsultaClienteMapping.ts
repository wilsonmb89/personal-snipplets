import { FormGroup } from '@angular/forms';
import { RequestWrapperConsultaCliente } from '../../models/services/ConsultarCliente/RequestWrapperConsultaCliente';
import { GetCustomerDataRqType } from '../../models/services/ConsultarCliente/GetCustomerDataRqType';
import { GetCustomerAdditionalDataRqType } from '../../models/services/ConsultarCliente/GetCustomerAdditionalDataRqType';
import { HeaderRequest } from '../../models/services/ConsultarCliente/HeaderRequest';
import { MessageHeader } from '../../models/services/ConsultarCliente/MessageHeader';
import { MessageInfo } from '../../models/services/ConsultarCliente/MessageInfo';
import { IssuedIdent } from '../../models/services/ConsultarCliente/IssuedIdent';
import { REQUEST_CONSULTA_CLIENTE } from '../../../shared/constants/codigosServicios.constant';
import { CapitalizeTextPipe } from '../../../shared/pipes/capitalize-text.pipe';
import { Transformation } from '../../../shared/functions/util/Trasnformation';
import { Validation } from '../util/validation';

export class ConsultaClienteMapping {
    public consultaCliente: RequestWrapperConsultaCliente;
    public _titlecasePipe: CapitalizeTextPipe;
    public transformation: Transformation;
    public validation: Validation;

    constructor() {
        this.validation = new Validation();
        this._titlecasePipe = new CapitalizeTextPipe();
        this.transformation = new Transformation();
        this.consultaCliente = new RequestWrapperConsultaCliente();
    }

    fillRequestConsultaCliente(body: FormGroup): RequestWrapperConsultaCliente {
        const typeId = !!body.get("typeId").value ? this.transformation.splitText(body.get("typeId").value)[0] : "";
        const documentId = !!body.get("documentId").value ? body.get("documentId").value : "";
        this.consultaCliente.getCustomerAdditionalDataRqType = new GetCustomerAdditionalDataRqType();
        this.consultaCliente.getCustomerAdditionalDataRqType.headerRequest = new HeaderRequest();
        this.consultaCliente.getCustomerAdditionalDataRqType.headerRequest.messageHeader = new MessageHeader();
        this.consultaCliente.getCustomerAdditionalDataRqType.headerRequest.messageHeader.messageInfo = new MessageInfo();
        this.consultaCliente.getCustomerAdditionalDataRqType.headerRequest.messageHeader.messageInfo.systemId = REQUEST_CONSULTA_CLIENTE.SYSTEM_ID;
        this.consultaCliente.getCustomerAdditionalDataRqType.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_CONSULTA_CLIENTE.ORIGINATOR_NAME;
        this.consultaCliente.getCustomerAdditionalDataRqType.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_CONSULTA_CLIENTE.ORIGINATOR_TYPE;
        this.consultaCliente.getCustomerAdditionalDataRqType.headerRequest.messageHeader.messageInfo.terminalId = "";
        this.consultaCliente.getCustomerAdditionalDataRqType.issuedIdent = new IssuedIdent();
        this.consultaCliente.getCustomerAdditionalDataRqType.issuedIdent.issuedIdentType = typeId;
        this.consultaCliente.getCustomerAdditionalDataRqType.issuedIdent.issuedIdentValue = documentId;

        this.consultaCliente.getCustomerDataRqType = new GetCustomerDataRqType();
        this.consultaCliente.getCustomerDataRqType.headerRequest = new HeaderRequest();
        this.consultaCliente.getCustomerDataRqType.headerRequest.messageHeader = new MessageHeader();
        this.consultaCliente.getCustomerDataRqType.headerRequest.messageHeader.messageInfo = new MessageInfo();
        this.consultaCliente.getCustomerDataRqType.headerRequest.messageHeader.messageInfo.systemId = REQUEST_CONSULTA_CLIENTE.SYSTEM_ID;
        this.consultaCliente.getCustomerDataRqType.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_CONSULTA_CLIENTE.ORIGINATOR_NAME;
        this.consultaCliente.getCustomerDataRqType.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_CONSULTA_CLIENTE.ORIGINATOR_TYPE;
        this.consultaCliente.getCustomerDataRqType.headerRequest.messageHeader.messageInfo.terminalId = "";
        this.consultaCliente.getCustomerDataRqType.issuedIdent = new IssuedIdent();
        this.consultaCliente.getCustomerDataRqType.issuedIdent.issuedIdentType = typeId;
        this.consultaCliente.getCustomerDataRqType.issuedIdent.issuedIdentValue = documentId;

        return this.consultaCliente;
    }

    fillFormGruopConsultaCliente(response: any, form: FormGroup): FormGroup {

        // NOMBRE
        let nombre = "";
        if (!!response.getCustomerDataRsType.party.personPartyInfo.personData) {
            if (!!response.getCustomerDataRsType.party.personPartyInfo.personData.personName) {
                if (!!response.getCustomerDataRsType.party.personPartyInfo.personData.personName.givenName) {
                    nombre = response.getCustomerDataRsType.party.personPartyInfo.personData.personName.givenName;
                    if (!!response.getCustomerDataRsType.party.personPartyInfo.personData.personName.paternalName) {
                        nombre += " " + response.getCustomerDataRsType.party.personPartyInfo.personData.personName.paternalName;
                    }
                    if (!!response.getCustomerDataRsType.party.personPartyInfo.personData.personName.maternalName) {
                        nombre += " " + response.getCustomerDataRsType.party.personPartyInfo.personData.personName.maternalName;
                    }
                    nombre = this._titlecasePipe.transform(nombre);
                    form.get("fullName").setValue(nombre);
                }
            }
        }

        // PEP Y MRP
        const datosAdicionales = response.getCustomerAdditionalDataRsType.partyAdditionalInfoList.partyAdditionalInfo;
        datosAdicionales.forEach(info => {
            switch (info.additionalInfoName) {
                case "Es Usted PEP?":
                    form.get("pepControl").setValue(!!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "");
                    break;
                case "Manejo recursos contratación estatal":
                    form.get("mrpControl").setValue(!!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "");
                    break;
            }
        });

        return form;
    }
}
