import { GetAccountListRq } from '../../models/services/productoPhoenix/GetAccountListRq';
import { HeaderRequestType } from '../../models/services/productoPhoenix/HeaderRequestType';
import { MessageHeaderType } from '../../models/services/productoPhoenix/MessageHeaderType';
import { MessageInfoType } from '../../models/services/productoPhoenix/MessageInfoType';
import { UserType } from '../../models/services/productoPhoenix/UserType';
import { IssuedIdentType } from '../../models/services/productoPhoenix/IssuedIdentType';
import { Solicitud } from '../../models/negocio/Solicitud';
import { REQUEST_CONSULTA_PRODUCTOS_PHOENIX } from '../../../shared/constants/codigosServicios.constant';
import { RequestWrapperGetAccountList } from '../../models/services/productoPhoenix/RequestWrapperGetAccountList';

export class ConsultaProductosPhoenixMapping {

    public requestConsultaProductos: RequestWrapperGetAccountList;
    public informacionConsultaProducto: any;

    constructor() {
        this.requestConsultaProductos = new RequestWrapperGetAccountList();
        this.requestConsultaProductos.getAccountListRq = new GetAccountListRq();
        this.requestConsultaProductos.getAccountListRq.headerRequest = new HeaderRequestType();
        this.requestConsultaProductos.getAccountListRq.headerRequest.messageHeader = new MessageHeaderType();
        this.requestConsultaProductos.getAccountListRq.headerRequest.messageHeader.messageInfo = new MessageInfoType();
        this.requestConsultaProductos.getAccountListRq.headerRequest.user = new UserType();
        this.requestConsultaProductos.getAccountListRq.acctListSel = new IssuedIdentType();
    }

    mappingConsultaProductos(solicitud: Solicitud): RequestWrapperGetAccountList {
        this.requestConsultaProductos.getAccountListRq.headerRequest.messageHeader.messageInfo.bankId = "";
        this.requestConsultaProductos.getAccountListRq.headerRequest.messageHeader.messageInfo.bankIdType = "";
        this.requestConsultaProductos.getAccountListRq.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_CONSULTA_PRODUCTOS_PHOENIX.BPM_AUTHOR;
        this.requestConsultaProductos.getAccountListRq.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_CONSULTA_PRODUCTOS_PHOENIX.ORIGINATOR_TYPE;
        this.requestConsultaProductos.getAccountListRq.headerRequest.messageHeader.messageInfo.systemId = REQUEST_CONSULTA_PRODUCTOS_PHOENIX.BPM_AUTHOR;
        this.requestConsultaProductos.getAccountListRq.headerRequest.messageHeader.messageInfo.terminalId = REQUEST_CONSULTA_PRODUCTOS_PHOENIX.TERMINAL_ID;
        this.requestConsultaProductos.getAccountListRq.headerRequest.messageHeader.messageInfo.terminalType = REQUEST_CONSULTA_PRODUCTOS_PHOENIX.BPM_AUTHOR;
        this.requestConsultaProductos.getAccountListRq.headerRequest.messageHeader.messageInfo.trnType = "";
        this.requestConsultaProductos.getAccountListRq.headerRequest.user.userName = REQUEST_CONSULTA_PRODUCTOS_PHOENIX.USER_NAME;
        this.requestConsultaProductos.getAccountListRq.acctListSel.issuedIdentType = solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion;
        this.requestConsultaProductos.getAccountListRq.acctListSel.issuedIdentValue = solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion;

        this.informacionConsultaProducto = {};
        this.requestConsultaProductos.infoAdicionalEventos = this.informacionConsultaProducto;
        return this.requestConsultaProductos;
    }

}
