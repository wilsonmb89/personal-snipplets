import { FormGroup } from "@angular/forms";
import { Solicitud } from '../../models/negocio/Solicitud';
import { Transformation } from '../../../shared/functions/util/Trasnformation';
import { Documentos } from '../../models/negocio/Documentos';
import { EstadoDocumentos } from '../../models/negocio/EstadoDocumentos';
import { Verificador } from '../../models/negocio/Verificador';
import { CapitalizeTextPipe } from '../../../shared/pipes/capitalize-text.pipe';

export class VerificarDocumentosSORMapping {
    public solicitud: Solicitud;
    public transformation: Transformation;
    public _titlecasePipe: CapitalizeTextPipe;

    constructor () {
        this.transformation = new Transformation();
        this._titlecasePipe = new CapitalizeTextPipe();
    }

    mappingVerificarDocumentos(body: FormGroup, solicitudActividad: Solicitud): Solicitud {
        // Mapeo informacion solicitud anterior
        this.solicitud = solicitudActividad;

        if (!(!!this.solicitud.datosSolicitud.personaNatural[0].documentos)) {
            this.solicitud.datosSolicitud.personaNatural[0].documentos = new Documentos();
            if (!(!!this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos)) {
                this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos = new EstadoDocumentos();
            }
        }

        // Estados Documentos
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.soporteIngresos = !!body.get("toogleIncome").value ? body.get("toogleIncome").value : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.codCausalIngresos = !!body.get("doumentCasualIncome").value ? this.transformation.splitText(body.get("doumentCasualIncome").value)[0] : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.desCausalIngresos = !!body.get("doumentCasualIncome").value ? this.transformation.splitText(body.get("doumentCasualIncome").value)[1] : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.formularioVenta = !!body.get("toogleSale").value ? body.get("toogleSale").value : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.codCausalVenta = !!body.get("doumentCasualSale").value ? this.transformation.splitText(body.get("doumentCasualSale").value)[0] : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.desCausalVenta = !!body.get("doumentCasualSale").value ? this.transformation.splitText(body.get("doumentCasualSale").value)[1] : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.documentoId = !!body.get("toogleDoc").value ? body.get("toogleDoc").value : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.codCausalId = !!body.get("doumentCasualId").value ? this.transformation.splitText(body.get("doumentCasualId").value)[0] : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.desCausalId = !!body.get("doumentCasualId").value ? this.transformation.splitText(body.get("doumentCasualId").value)[1] : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.soporteProcesoId = !!body.get("toogleProc").value ? body.get("toogleProc").value : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.codCausalProId = !!body.get("doumentCasualSopId").value ? this.transformation.splitText(body.get("doumentCasualSopId").value)[0] : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.desCausalProId = !!body.get("doumentCasualSopId").value ? this.transformation.splitText(body.get("doumentCasualSopId").value)[1] : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.tarjetaFirmas = !!body.get("toogleCardSignature").value ? body.get("toogleCardSignature").value : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.codCausalTarjFirma = !!body.get("doumentCasualCardSignature").value ? this.transformation.splitText(body.get("doumentCasualCardSignature").value)[0] : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.desCausalTarjFirma = !!body.get("doumentCasualCardSignature").value ? this.transformation.splitText(body.get("doumentCasualCardSignature").value)[1] : "";
        this.solicitud.datosSolicitud.personaNatural[0].documentos.estadoDocumentos.comentarios = !!body.get("comments").value ? body.get("comments").value.charAt(0).toUpperCase() + body.get("comments").value.slice(1) : "";

        this.solicitud.datosSolicitud.verificador = new Verificador();
        this.solicitud.datosSolicitud.verificador.usuarioVerificador = !!sessionStorage.getItem("loginRed") ? sessionStorage.getItem("loginRed") : "";
        this.solicitud.datosSolicitud.verificador.nombreVerificador = sessionStorage.getItem("fullname");
        return this.solicitud;
    }
}
