import { ValidAddress } from '../../../shared/functions/util/validations/ValidAddress';
import { FormGroup } from "@angular/forms";
import { Solicitud } from "../../models/negocio/Solicitud";
import { Validation } from "../util/validation";
import { Transformation } from "../../../shared/functions/util/Trasnformation";
import { CapitalizeTextPipe } from '../../../shared/pipes/capitalize-text.pipe';
import { TransformationHelper } from '../util/Transformation';
import { filtrarCatalogo, filtrarCatalogoCiiu} from '../../../shared/functions/util/Filter';


export class FormularioViculacionSORMapping {

  public solicitud: Solicitud;
  public validation: Validation;
  public validAddress: ValidAddress;
  public transformation: Transformation;
  public _titlecasePipe: CapitalizeTextPipe;
  public transformationHelper: TransformationHelper;

  constructor() {
    this.validAddress = new ValidAddress();
    this.validation = new Validation();
    this.transformation = new Transformation();
    this._titlecasePipe = new CapitalizeTextPipe();
    this.transformationHelper = new TransformationHelper();
  }

  mappingSolicitudFormularioVinculacion(body: FormGroup, solicitudActividad: Solicitud, rim: number, supportIncome: boolean): Solicitud {

    // Mapeo Informacion Solicitud Anterior
    this.solicitud = solicitudActividad;

    // Constantes
    const VALOR_SEXO = "M";
    const DES_SEXO_MASCULINO = "Masculino";
    const DES_SEXO_FEMENINO = "Femenino";
    const ORIGEN_EXPERIAN = "EXPERIAN";

    // Transoformacion
    let birPlace = !!body.get("birthplace").value ? body.get("birthplace").value.split("-") : "";
    let resPlace = !!body.get("place").value ? body.get("place").value.split("-") : "";
    let locPlace = !!body.get("locate").value ? body.get("locate").value.split("-") : "";
    let ciu = !!body.get("ciiu_control").value ? body.get("ciiu_control").value.split("-") : "";

    const emptyCity = "0-0-0-0";

    if (birPlace.length < 4) { birPlace = emptyCity.split("-"); }
    if (resPlace.length < 4) { resPlace = emptyCity.split("-"); }
    if (locPlace.length < 4) { locPlace = emptyCity.split("-"); }
    if (ciu.length < 4) { ciu = emptyCity.split("-"); }

    // Datos Basicos
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.codCiudadNacimiento = birPlace[1].trim();
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.desCiudadNacimiento = birPlace[0].trim();
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.codDepartamentoNacimiento = birPlace[3].trim();
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.desDepartamentoNacimiento = birPlace[2].trim();
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.fechaNacimiento = !!body.get("date").value ? this.transformation.formatDate(body.get("date").value) + "" + "" : "";
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.codGenero = !!body.get("sexoControl").value ? body.get("sexoControl").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.desGenero = !!body.get("sexoControl").value && body.get("sexoControl").value === VALOR_SEXO ? DES_SEXO_MASCULINO : DES_SEXO_FEMENINO; // Quemado temporalmente

    // Ubicacion
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.direccionResidencia = !!body.get("address").value ? this.validAddress.validacionDireccion(body.get("address").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.codCiudadResidencia = resPlace[1].trim();
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.desCiudadResidencia = resPlace[0].trim();
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.codDepartamentoResidencia = resPlace[3].trim();
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.desDepartamentoResidencia = resPlace[2].trim();
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.correoElectronico = !!body.get("email").value ? body.get("email").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.numeroCelular = !!body.get("phone").value ? body.get("phone").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.residenciaFiscalOtroPais = !!body.get("resPaisControl").value ? body.get("resPaisControl").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.direccionOtroPais = !!body.get("dirPaisControl").value ? body.get("dirPaisControl").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.codOtroPais = !!body.get("country").value ? this.transformation.splitText(body.get("country").value)[1] : "";
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.desOtroPais = !!body.get("country").value ? this.transformation.splitText(body.get("country").value)[0] : "";

    // Actividad Economina
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codOcupacion = !!body.get("typeOcup").value ? body.get("typeOcup").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desOcupacion = !!body.get("typeOcup").value ? this.transformation.getOcupation(body.get("typeOcup").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codCIIU = !!body.get("ciiu_control").value ? this.transformation.splitText(body.get("ciiu_control").value)[0] : "";
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desCIIU = !!body.get("ciiu_control").value ? this.transformation.splitText(body.get("ciiu_control").value)[1] : "";
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.nombreEmpresa = !!body.get("nameEmp").value ? this._titlecasePipe.transform(body.get("nameEmp").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.direccionEmpresa = !!body.get("addEmp").value ? this.validAddress.validacionDireccion(body.get("addEmp").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codCiudadEmpresa = locPlace[1].trim();
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desCiudadEmpresa = locPlace[0].trim();
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codDepartamentoEmpresa = locPlace[3].trim();
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desDepartamentoEmpresa = locPlace[2].trim();
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.telefonoOficina = !!body.get("phoneEmp").value ? body.get("phoneEmp").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio = !!body.get("nomina").value ? this.transformation.splitText(body.get("nomina").value)[1] : "";
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desConvenio = !!body.get("nomina").value ? this.transformation.splitText(body.get("nomina").value)[0] : "";
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codSecEconomico = !!ciu[2] ? ciu[2].trim() : "";
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desSecEconomico = !!ciu[3] ? ciu[3].trim() : "";

    // Informacion Finanicera
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoPrincipalCore = !!body.get("main").value ? body.get("main").value : 0;
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoValidado = !!body.get("validatedIncome") && body.get("validatedIncome").value !== "" ? body.get("validatedIncome").value : 0;
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoEstimado = !!body.get("estimatedIncome") && body.get("estimatedIncome").value !== "" ? body.get("estimatedIncome").value : 0;
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.origenIngresoTercerasFuentes = !!body.get("estimatedIncome") && !!body.get("estimatedIncome").value ? ORIGEN_EXPERIAN : (!!body.get("validatedIncome") && !!body.get("validatedIncome").value ? ORIGEN_EXPERIAN : "");
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.otrosIngresos = !!body.get("others").value ? body.get("others").value : 0;
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.codConceptoOtrosIngresos = !!body.get("conceptoing").value ? this.transformation.splitText(body.get("conceptoing").value)[1] : "";
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.desConceptoOtrosIngresos = !!body.get("conceptoing").value ? this.transformation.splitText(body.get("conceptoing").value)[0] : "";
    const ingresos = !!body.get("main").value ? Number(body.get("main").value) : 0;
    const otrosIngresos = !!body.get("others").value ? Number(body.get("others").value) : 0;
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.totalIngresos = ingresos + otrosIngresos;
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.egresosMensuales = !!body.get("output").value ? body.get("output").value : 0;
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.totalActivos = !!body.get("total").value ? body.get("total").value : 0;
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.totalPasivos = !!body.get("pasive").value ? body.get("pasive").value : 0;
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.patrimonio = !!body.get("patrimonio").value ? Number(body.get("patrimonio").value) : 0;
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.desOtroConcepto = !!body.get("otherConcept").value ? this._titlecasePipe.transform(body.get("otherConcept").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.soporteIngresos = supportIncome;

    // Operacion Moneda Extranjera
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.realizaOperacionesMonedaExtranjera = !!body.get("opeExtControl").value ? body.get("opeExtControl").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionImportaciones = !!body.get("tipoOperacionesInter").value ? this.validation.trueToYes(body.get("tipoOperacionesInter").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionExportaciones = !!body.get("tipoOperacionesExpo").value ? this.validation.trueToYes(body.get("tipoOperacionesExpo").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionInversiones = !!body.get("tipoOperacionesInve").value ? this.validation.trueToYes(body.get("tipoOperacionesInve").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionCredito = !!body.get("tipoOperacionesCred").value ? this.validation.trueToYes(body.get("tipoOperacionesCred").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionPagoServicios = !!body.get("tipoOperacionesServ").value ? this.validation.trueToYes(body.get("tipoOperacionesServ").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionOtras = !!body.get("tipoOperacionesOtro").value ? this.validation.trueToYes(body.get("tipoOperacionesOtro").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.otroTipoOperacion = !!body.get("operation").value ? this._titlecasePipe.transform(body.get("operation").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.titularProductosMonedaExtranjera = !!body.get("titularMonExtranj").value ? body.get("titularMonExtranj").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoProducto = !!body.get("typpro").value ? this._titlecasePipe.transform(body.get("typpro").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.numeroProducto = !!body.get("numpro").value ? body.get("numpro").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.monto = !!body.get("amount").value ? body.get("amount").value : 0;
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.entidad = !!body.get("entity").value ? this._titlecasePipe.transform(body.get("entity").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.codMoneda = !!body.get("coin").value ? this._titlecasePipe.transform(body.get("coin").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.desMoneda = !!body.get("coin").value ? this._titlecasePipe.transform(body.get("coin").value) : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.codPais = !!body.get("countryCoin").value ? this.transformation.splitText(body.get("countryCoin").value)[1] : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.desPais = !!body.get("countryCoin").value ? this.transformation.splitText(body.get("countryCoin").value)[0] : "";
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.ciudad = !!body.get("cityCoin").value ? this._titlecasePipe.transform(body.get("cityCoin").value) : "";

    // Rim Phoenix
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.rymPhoenix = rim;

    return this.solicitud;
  }

  mappingSolicitudFormularioVinculacionAutollenado(body: FormGroup, solicitudActividad: Solicitud, requiredMonedaExtr: boolean, paises: any[], ciiu: any[]) {

    const emptyCity = "0 - 0 - 0 - 0";
    if (!!solicitudActividad) {
      const personaNatural = solicitudActividad.datosSolicitud.personaNatural[0];
      if (!!personaNatural.datosBasicos.codCiudadNacimiento) {
        const data = personaNatural.datosBasicos.desCiudadNacimiento +
          " - " + personaNatural.datosBasicos.codCiudadNacimiento +
          " - " + personaNatural.datosBasicos.desDepartamentoNacimiento +
          " - " + personaNatural.datosBasicos.codDepartamentoNacimiento;
        body.get("birthplace").setValue(data);
      }

      if (!!personaNatural.datosBasicos.fechaNacimiento) {
        const data = personaNatural.datosBasicos.fechaNacimiento;
        const año = data.substring(0, 4);
        const mes = data.substring(5, 7);
        const dia = data.substring(8, 10);
        body.get("dateDay").setValue(dia);
        body.get("dateMonth").setValue(mes);
        body.get("dateYear").setValue(año);
      }
      if (!!personaNatural.datosBasicos.codGenero) {
        const data = personaNatural.datosBasicos.codGenero;
        body.get("sexoControl").setValue(data);
      }

      if (!!personaNatural.ubicacion) {
        if (!!personaNatural.ubicacion.correoElectronico) {
          const data = personaNatural.ubicacion.correoElectronico;
          body.get("email").setValue(data);
        }
        if (!!personaNatural.ubicacion.direccionResidencia) {
          const data = personaNatural.ubicacion.direccionResidencia;
          body.get("address").setValue(data);
        }
        if (!!personaNatural.ubicacion.codCiudadResidencia) {
          let data = personaNatural.ubicacion.desCiudadResidencia +
            " - " + personaNatural.ubicacion.codCiudadResidencia +
            " - " + personaNatural.ubicacion.desDepartamentoResidencia +
            " - " + personaNatural.ubicacion.codDepartamentoResidencia;
          if (data === emptyCity) {
            data = "";
          }
          body.get("place").setValue(data);
        }
        if (!!personaNatural.ubicacion.numeroCelular) {
          const data = personaNatural.ubicacion.numeroCelular;
          body.get("phone").setValue(data);
        }
        if (!!personaNatural.ubicacion.residenciaFiscalOtroPais) {
          const data = personaNatural.ubicacion.residenciaFiscalOtroPais;
          body.get("resPaisControl").setValue(data);
        }
        if (!!personaNatural.ubicacion.direccionOtroPais) {
          const data = personaNatural.ubicacion.direccionOtroPais;
          body.get("dirPaisControl").setValue(data);
        }
        if (!!personaNatural.ubicacion.desOtroPais) {
          const codPais = filtrarCatalogo(personaNatural.ubicacion.desOtroPais, paises, 'nombre');
          if (!!codPais && codPais.length > 0) {
            const data = personaNatural.ubicacion.desOtroPais + " - " + codPais[0].valor;
            body.get("country").setValue(data);
          }
        }

      }

      if (!!personaNatural.actividadEconomica) {
        if (!!personaNatural.actividadEconomica.codOcupacion) {
          const data = personaNatural.actividadEconomica.codOcupacion;
          body.get("typeOcup").setValue(data);
          if (data === "37") {
            if (!!personaNatural.actividadEconomica.codCIIU) {
              const desCIIU = filtrarCatalogoCiiu(personaNatural.actividadEconomica.codCIIU, ciiu, 'valor');
              if (!!desCIIU && desCIIU.length > 0) {
                const data = personaNatural.actividadEconomica.codCIIU + " - " + desCIIU[0].nombre + " - " + desCIIU[0].valorSector + " - " + desCIIU[0].nombreSector;
                body.get("ciiu_control").setValue(data);
              }
            }
          }
        }
        if (!!personaNatural.actividadEconomica.nombreEmpresa) {
          const data = personaNatural.actividadEconomica.nombreEmpresa;
          body.get("nameEmp").setValue(data);
        }

        if (!!personaNatural.actividadEconomica.direccionEmpresa) {
          const data = personaNatural.actividadEconomica.direccionEmpresa;
          body.get("addEmp").setValue(data);
        }

        if (!!personaNatural.actividadEconomica.codCiudadEmpresa) {
          const data = personaNatural.actividadEconomica.desCiudadEmpresa +
            " - " + personaNatural.actividadEconomica.codCiudadEmpresa +
            " - " + personaNatural.actividadEconomica.desDepartamentoEmpresa +
            " - " + personaNatural.actividadEconomica.codDepartamentoEmpresa;
          body.get("locate").setValue(data);
        }

        if (!!personaNatural.actividadEconomica.telefonoOficina) {
          const data = personaNatural.actividadEconomica.telefonoOficina;
          body.get("phoneEmp").setValue(data);
        }

        if (!!personaNatural.actividadEconomica.codConvenio) {
          const data = personaNatural.actividadEconomica.desConvenio +
            " - " + personaNatural.actividadEconomica.codConvenio;
          body.get("nomina").setValue(data);
        }
      }

      // Condiciones para la informacion financiera
      if (!!personaNatural.informacionFinanciera) {

        body.get("pasive").setValue(!!personaNatural.informacionFinanciera.totalPasivos ? personaNatural.informacionFinanciera.totalPasivos : 0);

        body.get("main").setValue(!!personaNatural.informacionFinanciera.ingresoPrincipalCore ? personaNatural.informacionFinanciera.ingresoPrincipalCore : 0);

        body.get("others").setValue(!!personaNatural.informacionFinanciera.otrosIngresos ? personaNatural.informacionFinanciera.otrosIngresos : 0);

        if (!!personaNatural.informacionFinanciera.codConceptoOtrosIngresos && !!personaNatural.informacionFinanciera.desConceptoOtrosIngresos) {
          const data = personaNatural.informacionFinanciera.desConceptoOtrosIngresos + " - " + personaNatural.informacionFinanciera.codConceptoOtrosIngresos;
          body.get("conceptoing").setValue(data);
        }

        if (!!personaNatural.informacionFinanciera.desOtroConcepto) {
          const data = personaNatural.informacionFinanciera.desOtroConcepto;
          body.get("otherConcept").setValue(data);
        }

        body.get("output").setValue(!!personaNatural.informacionFinanciera.egresosMensuales ? personaNatural.informacionFinanciera.egresosMensuales : 0);

        body.get("total").setValue(!!personaNatural.informacionFinanciera.totalActivos ? personaNatural.informacionFinanciera.totalActivos : 0);

        body.get("patrimonio").setValue(!!personaNatural.informacionFinanciera.patrimonio ? personaNatural.informacionFinanciera.patrimonio : 0);
      }

      // Condiciones para las operaciones en moneda extranjera / AUTELLENADO
      if (!!personaNatural.operacionesMonedaExtranjera) {
        if (!!personaNatural.operacionesMonedaExtranjera.realizaOperacionesMonedaExtranjera) {
          const data = personaNatural.operacionesMonedaExtranjera.realizaOperacionesMonedaExtranjera;
          body.get("opeExtControl").setValue(data);
          if (data === "S") {
            if (!!personaNatural.operacionesMonedaExtranjera.tipoOperacionImportaciones) {
              const data = personaNatural.operacionesMonedaExtranjera.tipoOperacionImportaciones;
              body.get("tipoOperacionesInter").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.tipoOperacionExportaciones) {
              const data = personaNatural.operacionesMonedaExtranjera.tipoOperacionExportaciones;
              body.get("tipoOperacionesExpo").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.tipoOperacionInversiones) {
              const data = personaNatural.operacionesMonedaExtranjera.tipoOperacionInversiones;
              body.get("tipoOperacionesInve").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.tipoOperacionCredito) {
              const data = personaNatural.operacionesMonedaExtranjera.tipoOperacionCredito;
              body.get("tipoOperacionesCred").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.tipoOperacionPagoServicios) {
              const data = personaNatural.operacionesMonedaExtranjera.tipoOperacionPagoServicios;
              body.get("tipoOperacionesServ").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.tipoOperacionOtras) {
              const data = personaNatural.operacionesMonedaExtranjera.tipoOperacionOtras;
              body.get("tipoOperacionesOtro").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.otroTipoOperacion) {
              const data = personaNatural.operacionesMonedaExtranjera.otroTipoOperacion;
              body.get("operation").setValue(data);
            }
          }
        }

        if (!!personaNatural.operacionesMonedaExtranjera.titularProductosMonedaExtranjera) {
          const data = personaNatural.operacionesMonedaExtranjera.titularProductosMonedaExtranjera;
          body.get("titularMonExtranj").setValue(data);
          if (data === "S") {
            requiredMonedaExtr = true;

            if (!!personaNatural.operacionesMonedaExtranjera.tipoProducto) {
              const data = personaNatural.operacionesMonedaExtranjera.tipoProducto;
              body.get("typpro").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.numeroProducto) {
              const data = personaNatural.operacionesMonedaExtranjera.numeroProducto;
              body.get("numpro").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.entidad) {
              const data = personaNatural.operacionesMonedaExtranjera.entidad;
              body.get("entity").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.codMoneda) {
              const data = personaNatural.operacionesMonedaExtranjera.codMoneda;
              body.get("coin").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.monto) {
              const data = personaNatural.operacionesMonedaExtranjera.monto;
              body.get("amount").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.desPais) {
              const data = personaNatural.operacionesMonedaExtranjera.desPais;
              body.get("countryCoin").setValue(data);
            }

            if (!!personaNatural.operacionesMonedaExtranjera.ciudad) {
              const data = personaNatural.operacionesMonedaExtranjera.ciudad;
              body.get("cityCoin").setValue(data);
            }
          }
        }
      }
    }

    return [body, requiredMonedaExtr];
  }

}
