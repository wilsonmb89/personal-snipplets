import { FormGroup } from "@angular/forms";
import { Solicitud } from "../../models/negocio/Solicitud";
import { Radicador } from "../../models/negocio/Radicador";
import { CapitalizeTextPipe } from '../../../shared/pipes/capitalize-text.pipe';
import { DatosSolicitud } from '../../models/negocio/DatosSolicitud';
import { Vendedor } from '../../models/negocio/Vendedor';


export class AsignarVentaSORMapping {

    public solicitud: Solicitud;
    public _titlecasePipe: CapitalizeTextPipe;

    constructor() {
        this._titlecasePipe = new CapitalizeTextPipe();
        this.solicitud = new Solicitud();
        this.solicitud.datosSolicitud = new DatosSolicitud();
        this.solicitud.datosSolicitud.vendedor = new Vendedor();
        this.solicitud.datosSolicitud.radicador = new Radicador();
    }

    mappingAsignarVenta(body: FormGroup, instanceId: string, solicitudActividad: Solicitud, rol: boolean): Solicitud {
        // Constantes
        const COD_TIPO_IDENTIFICACION = "1";
        const DES_TIPO_IDENTIFICACION = "Cédula de Ciudadanía";

        // Mapeo informacion solicitud
        if (!!solicitudActividad) { this.solicitud = solicitudActividad; }

        // Solicitud
        this.solicitud.numeroSolicitud = !!instanceId ? instanceId : "";
        this.solicitud.datosSolicitud.numeroSolicitud = !!instanceId ? instanceId : "";

        // Vendedor
        if (rol) {
            this.solicitud.datosSolicitud.vendedor.codOficina = !!body.get("office").value ? body.get("office").value.split("-")[0].trim() : "";
            this.solicitud.datosSolicitud.vendedor.desOficina = !!body.get("office").value ? body.get("office").value.split("-")[1].trim() : "";
            this.solicitud.datosSolicitud.vendedor.desCiudadOficina = !!body.get("office").value ? body.get("office").value.split("-")[2].trim() : "";
            this.solicitud.datosSolicitud.vendedor.nombreVendedor = !!body.get("name").value ? this._titlecasePipe.transform(body.get("name").value) : "";
            this.solicitud.datosSolicitud.vendedor.codTipoIdentificacion = COD_TIPO_IDENTIFICACION;
            this.solicitud.datosSolicitud.vendedor.desTipoIdentificacion = DES_TIPO_IDENTIFICACION;
            this.solicitud.datosSolicitud.vendedor.numeroIdentificacion = !!body.get("documentIdSeller").value ? body.get("documentIdSeller").value : "";
        }

        // Radicador
        if (!(!!solicitudActividad)) {
            this.solicitud.datosSolicitud.radicador.codOficina = !!body.get("office").value ? body.get("office").value.split("-")[0].trim() : "";
            this.solicitud.datosSolicitud.radicador.desOficina = !!body.get("office").value ? body.get("office").value.split("-")[1].trim() : "";
            this.solicitud.datosSolicitud.radicador.desCiudadOficina = !!body.get("office").value ? body.get("office").value.split("-")[2].trim() : "";
            this.solicitud.datosSolicitud.radicador.nombreRadicador = !!body.get("name").value ? this._titlecasePipe.transform(body.get("name").value) : "";
            this.solicitud.datosSolicitud.radicador.usuarioRadicador = !!sessionStorage.getItem("loginRed") ? sessionStorage.getItem("loginRed") : "";
            this.solicitud.datosSolicitud.radicador.codTipoIdentificacion = COD_TIPO_IDENTIFICACION;
            this.solicitud.datosSolicitud.radicador.desTipoIdentificacion = DES_TIPO_IDENTIFICACION;
            this.solicitud.datosSolicitud.radicador.numeroIdentificacion = !!body.get("documentIdSeller").value ? body.get("documentIdSeller").value : "";
        }

        return this.solicitud;
    }


}
