import { GetOrgStructureByUserRqType } from "../../models/services/estructuraComercial/GetOrgStructureByUserRqType";
import { HeaderRequestType } from "../../models/services/estructuraComercial/HeaderRequestType";
import { MessageHeaderType } from "../../models/services/estructuraComercial/MessageHeaderType";
import { MessageInfoType } from "../../models/services/estructuraComercial/MessageInfoType";
import { REQUEST_GET_ORG_STRUCTURE } from "../../../shared/constants/codigosServicios.constant";
import { UserType } from "../../models/services/estructuraComercial/UserType";

/**
 *  Clase que contiene los metodos de mapeo para las operaciones del sercicio de estructura comercial
 *  @author Diego Aguirre - EDA01779
 *  @since 04/01/2019
 */
export class EstructuraComercialMapping {

    public requestGetOrgStructure: GetOrgStructureByUserRqType;

    constructor() {
        this.requestGetOrgStructure = new GetOrgStructureByUserRqType();
        this.requestGetOrgStructure.headerRequest = new HeaderRequestType();
        this.requestGetOrgStructure.headerRequest.messageHeader = new MessageHeaderType();
        this.requestGetOrgStructure.headerRequest.messageHeader.messageInfo = new MessageInfoType();
    }

    /**
     * Metodo para realizar mapeo del objeto canonico del servicio de estructura comercial, operacion getOrgStructure
     * @param loginName
     * @param numeroIdentificacion
     * @returns GetOrgStructureByUserRqType
     */
    mappingGetOrgStructure(loginName: string, numeroIdentificacion: string ): GetOrgStructureByUserRqType {

        this.requestGetOrgStructure.headerRequest.messageHeader.messageInfo.systemId = REQUEST_GET_ORG_STRUCTURE.BPM_AUTHOR;
        this.requestGetOrgStructure.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_GET_ORG_STRUCTURE.BPM_AUTHOR;
        this.requestGetOrgStructure.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_GET_ORG_STRUCTURE.ORIGINATOR_TYPE;
        this.requestGetOrgStructure.headerRequest.messageHeader.messageInfo.terminalId = REQUEST_GET_ORG_STRUCTURE.TERMINAL_ID;

        if (!!loginName) {
            this.requestGetOrgStructure.headerRequest.user = new UserType();
            this.requestGetOrgStructure.headerRequest.user.userName = loginName;
        } else if (!!numeroIdentificacion) {
            this.requestGetOrgStructure.identSerialNum = numeroIdentificacion;
        }
        return this.requestGetOrgStructure;
    }
}
