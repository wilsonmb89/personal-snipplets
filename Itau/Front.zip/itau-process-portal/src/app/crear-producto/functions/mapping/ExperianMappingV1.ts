import { GetCustomerIncomeEstimatedRq } from '../../models/services/experian/v1/GetCustomerIncomeEstimatedRq';
import { CustId } from '../../models/services/experian/v1/CustId';
import { HeaderRequest } from '../../models/services/experian/v1/HeaderRequest';
import { MessageHeader } from '../../models/services/experian/v1/MessageHeader';
import { MessageInfo } from '../../models/services/experian/v1/MessageInfo';
import { MessageKey } from '../../models/services/experian/v1/MessageKey';
import { Solicitud } from '../../models/negocio/Solicitud';
import { REQUEST_EXPERIAN } from '../../../shared/constants/codigosServicios.constant';

export class ExperianMappingV1 {
    public getCustomerIncomeEstimatedMapping: GetCustomerIncomeEstimatedRq;
    constructor() {
        this.getCustomerIncomeEstimatedMapping = new GetCustomerIncomeEstimatedRq();
    }

    mappingToGetCustomerIncomeEstimated(solicitud: Solicitud): GetCustomerIncomeEstimatedRq {
        if (!!solicitud) {
            this.getCustomerIncomeEstimatedMapping = new GetCustomerIncomeEstimatedRq();
            this.getCustomerIncomeEstimatedMapping.custId = new CustId();
            this.getCustomerIncomeEstimatedMapping.custId.custPermId = (!!solicitud.datosSolicitud.personaNatural[0] && !!solicitud.datosSolicitud.personaNatural[0].datosBasicos) ? solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion : "";
            this.getCustomerIncomeEstimatedMapping.custId.custType = (!!solicitud.datosSolicitud.personaNatural[0] && !!solicitud.datosSolicitud.personaNatural[0].datosBasicos) ? solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion : "1";
            this.getCustomerIncomeEstimatedMapping.employmentType = "";
            this.getCustomerIncomeEstimatedMapping.headerRequest = new HeaderRequest();
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader = new MessageHeader();
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageInfo = new MessageInfo();
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageInfo.bankId = "";
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageInfo.bankIdType = "";
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_EXPERIAN.BPM_AUTHOR;
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_EXPERIAN.ORIGINATOR_TYPE;
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageInfo.systemId = REQUEST_EXPERIAN.BPM_AUTHOR;
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageInfo.terminalId = REQUEST_EXPERIAN.TERMINAL_ID;
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageInfo.terminalType = "";
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageInfo.bankId = "";
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageInfo.trnType = "";
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageKey = new MessageKey();
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageKey.integrationId = "";
            this.getCustomerIncomeEstimatedMapping.headerRequest.messageHeader.messageKey.requestVersion = "";
            this.getCustomerIncomeEstimatedMapping.lastName = (!!solicitud.datosSolicitud.personaNatural[0] && !!solicitud.datosSolicitud.personaNatural[0].datosBasicos) ? solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido : "";
            return this.getCustomerIncomeEstimatedMapping;
        } else {
            return null;
        }
    }

}
