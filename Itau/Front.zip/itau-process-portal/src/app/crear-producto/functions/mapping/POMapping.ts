import { Solicitud } from "../../models/negocio/Solicitud";
import { Transformation } from "../../../shared/functions/util/Trasnformation";
import { FinalizarTarea } from "../../../shared/models/request/FinalizarTarea";
import { ProcessObjectVP } from "../../../shared/models/bpm/ProcessObjectVP";
import { ProcessObjectCP } from "../../../shared/models/bpm/ProcessObjectCP";
import { FormGroup } from '@angular/forms';


export class POMapping {

    public finalizarTarea: FinalizarTarea;
    public datosFlujoVP: ProcessObjectVP;
    public datosFlujoCP: ProcessObjectCP;
    public transformation: Transformation;

    constructor() {
        this.finalizarTarea = new FinalizarTarea();
        this.datosFlujoVP = new ProcessObjectVP();
        this.datosFlujoCP = new ProcessObjectCP();
        this.transformation = new Transformation();
    }

    mappingAsignarVentaPO(taskId: string, instanceId: string, seleccionProducto: boolean, loginRedSubGerenteOficina: string ): FinalizarTarea {

        this.finalizarTarea.idTask = taskId;
        this.datosFlujoCP.numeroSolicitud = instanceId;
        this.datosFlujoCP.seleccionProductos = seleccionProducto;
        this.datosFlujoCP.loginRedSubGerenteOp = loginRedSubGerenteOficina;

        this.finalizarTarea.parameters = '{"datosFlujo":' + JSON.stringify(this.datosFlujoCP) + "}";
        return this.finalizarTarea;
    }

    mappingConsultarClientePO(taskId: string, solicitud: Solicitud, formBody: FormGroup, decisionEnrutamiento: string): FinalizarTarea {

        this.finalizarTarea.idTask = taskId;

        this.datosFlujoVP = JSON.parse(sessionStorage.getItem("datosFlujo"));

        if (!!solicitud) {
            this.datosFlujoVP.nombreCliente = !!solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre ? solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre : "";
            this.datosFlujoVP.nombreCliente = !!solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido ? this.datosFlujoVP.nombreCliente + " " + solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido : this.datosFlujoVP.nombreCliente;
            this.datosFlujoVP.nombreCliente = !!solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido ? this.datosFlujoVP.nombreCliente + " " + solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido : this.datosFlujoVP.nombreCliente;
            this.datosFlujoVP.desTipoIdentificacion = !!solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion ? this.transformation.changeTipoIdentificacion(solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion) : "";
            this.datosFlujoVP.numIdentificacion = !!solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion ? solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion : "";
        } else {
            this.datosFlujoVP.nombreCliente = !!formBody.get("fullName").value ? formBody.get("fullName").value : "";
            this.datosFlujoVP.desTipoIdentificacion = !!formBody.get("typeId").value ? this.transformation.changeTipoIdentificacion(this.transformation.splitText(formBody.get("typeId").value)[0]) : "";
            this.datosFlujoVP.numIdentificacion = !!formBody.get("documentId").value ? formBody.get("documentId").value : "";
        }

        this.datosFlujoVP.decisionEnrutamiento = decisionEnrutamiento;

        this.finalizarTarea.parameters = '{"datosFlujo":' + JSON.stringify(this.datosFlujoVP) + "}";
        return this.finalizarTarea;
    }

    mappingValidarConceptoCumplimientoPO(taskId: string, cumplimientoAprobo: boolean): FinalizarTarea {

        this.finalizarTarea.idTask = taskId;

        this.datosFlujoVP = JSON.parse(sessionStorage.getItem("datosFlujo"));
        this.datosFlujoVP.cumplimientoAprobo = cumplimientoAprobo;

        this.finalizarTarea.parameters = '{"datosFlujo":' + JSON.stringify(this.datosFlujoVP) + "}";
        return this.finalizarTarea;
    }

    mappingGenericPO(taskId: string): FinalizarTarea {

        this.finalizarTarea.idTask = taskId;

        this.datosFlujoVP = JSON.parse(sessionStorage.getItem("datosFlujo"));

        this.finalizarTarea.parameters = '{"datosFlujo":' + JSON.stringify(this.datosFlujoVP) + "}";
        return this.finalizarTarea;
    }

    mappingGenericPoCp(taskId: string): FinalizarTarea {

        this.finalizarTarea.idTask = taskId;

        this.datosFlujoCP = JSON.parse(sessionStorage.getItem("datosFlujo"));

        this.finalizarTarea.parameters = '{"datosFlujo":' + JSON.stringify(this.datosFlujoCP) + "}";
        return this.finalizarTarea;
    }

    mappingVerificarDocumentos(taskId: string, docApproved: boolean): FinalizarTarea {

        this.finalizarTarea.idTask = taskId;

        this.datosFlujoCP = JSON.parse(sessionStorage.getItem("datosFlujo"));
        this.datosFlujoCP.documentosAprobados = docApproved;

        this.finalizarTarea.parameters = '{"datosFlujo":' + JSON.stringify(this.datosFlujoCP) + "}";
        return this.finalizarTarea;
    }

}
