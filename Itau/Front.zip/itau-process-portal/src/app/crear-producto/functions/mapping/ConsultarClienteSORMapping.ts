import { FormGroup } from "@angular/forms";
import { PersonaNatural } from "../../models/negocio/PersonaNatural";
import { DatosBasicos } from "../../models/negocio/DatosBasicos";
import { ListaResultado } from "../../models/services/listasRestrictivas/ListaResultado";
import { LLAVES_SOR } from "../../constants/LlavesSOR.constant";
import { Resultado } from "../../models/services/listasRestrictivas/Resultado";
import { Solicitud } from "../../models/negocio/Solicitud";
import { OperacionesMonedaExtranjera } from "../../models/negocio/OperacionesMonedaExtranjera";
import { PublicamenteExpuesto } from "../../models/negocio/PublicamenteExpuesto";
import { CapitalizeTextPipe } from '../../../shared/pipes/capitalize-text.pipe';
import { Transformation } from '../../../shared/functions/util/Trasnformation';
import { ValidAddress } from '../../../shared/functions/util/validations/ValidAddress';
import { Validation } from '../util/validation';
import { Ubicacion } from '../../models/negocio/Ubicacion';
import { ActividadEconomica } from '../../models/negocio/ActividadEconomica';
import { InformacionFinanciera } from '../../models/negocio/InformacionFinanciera';
import { filtrarCatalogo} from '../../../shared/functions/util/Filter';
import { TestBed } from '@angular/core/testing';


export class ConsultarClienteSORMapping {

  public date: string;
  public solicitud: Solicitud;
  public validation: Validation;
  public validAddress: ValidAddress;
  public transformation: Transformation;
  public _titlecasePipe: CapitalizeTextPipe;

  constructor() {
    this.date = new Date().toISOString();
    this.validation = new Validation();
    this.validAddress = new ValidAddress();
    this.transformation = new Transformation();
    this._titlecasePipe = new CapitalizeTextPipe();
  }

  mappingConsultarCliente(body: FormGroup, datos: Map<string, any>, solicitudActividad: Solicitud, customerInformation: any, estadoCliente: string, ciudades: any): Solicitud {

    // Mapeo informacion solicitud anterior
    this.solicitud = solicitudActividad;

    // Inicializacion
    this.solicitud.datosSolicitud.personaNatural = new Array<PersonaNatural>();
    this.solicitud.datosSolicitud.personaNatural[0] = new PersonaNatural();
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos = new DatosBasicos();
    this.solicitud.datosSolicitud.personaNatural[0].ubicacion = new Ubicacion();
    this.solicitud.datosSolicitud.personaNatural[0].consultarListas = new ListaResultado();
    this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados = new Array<Resultado>();
    this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto = new PublicamenteExpuesto();
    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica = new ActividadEconomica();
    this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera = new InformacionFinanciera();
    this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera = new OperacionesMonedaExtranjera();

    // Constantes
    const VALOR_SEXO_M = "M";
    const VALOR_SEXO_F = "F";
    const DES_SEXO_MASCULINO = "Masculino";
    const DES_SEXO_FEMENINO = "Femenino";

    // solicitud
    this.solicitud.datosSolicitud.fechaRadicacion = this.date;
    this.solicitud.datosSolicitud.personaNatural[0].estadoCliente = estadoCliente;

    // datos basicos
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion = !!body.get("documentId").value ? body.get("documentId").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion = !!body.get("typeId").value ? this.transformation.splitText(body.get("typeId").value)[0] : "";
    this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.desTipoIdentificacion = !!body.get("typeId").value ? this.transformation.splitText(body.get("typeId").value)[1] : "";
    if (estadoCliente === "NO EXISTE") {
      this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido = !!body.get("firstLastname").value ? this._titlecasePipe.transform(body.get("firstLastname").value) : "";
      this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido = !!body.get("secondLastname").value ? this._titlecasePipe.transform(body.get("secondLastname").value) : "";
      this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre = !!body.get("name").value ? this._titlecasePipe.transform(body.get("name").value) : "";
    }

    // Publicamente Expuesto
    this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.pep = !!body.get("pepControl").value ? body.get("pepControl").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.prp = !!body.get("prpControl").value ? body.get("prpControl").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.mrp = !!body.get("mrpControl").value ? body.get("mrpControl").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.comentarioPepPrpMrp = !!body.get("comentarioPepPrpMrpControl").value ? body.get("comentarioPepPrpMrpControl").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.familiarPep = !!body.get("familiarPepControl").value ? body.get("familiarPepControl").value : "";
    this.solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.comentarioFamiliarPep = !!body.get("comentarioFamiliarPepControl").value ? body.get("comentarioFamiliarPepControl").value : "";

    // Consultar Listas
    this.solicitud.datosSolicitud.personaNatural[0].consultarListas.resultados = !!datos.get(LLAVES_SOR.RESULTADOS_LISTAS_RESTRICTIVAS) ? datos.get(LLAVES_SOR.RESULTADOS_LISTAS_RESTRICTIVAS) : [];
    this.solicitud.datosSolicitud.personaNatural[0].consultarListas.totalResultados = !!datos.get(LLAVES_SOR.TOTAL_RESULTADOS_LISTAS_RESTRICTIVAS) ? datos.get(LLAVES_SOR.TOTAL_RESULTADOS_LISTAS_RESTRICTIVAS) : 0;

    // Customer Information
    if (!!customerInformation && !!customerInformation.getCustomerDataRsType) {
      const party = customerInformation.getCustomerDataRsType.party;
      if (!!party) {
        if (!!party.personPartyInfo) {
          const datosBasicos = party.personPartyInfo;
          this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codCIIU = !!datosBasicos.sic ? this.transformation.formatCodeZero(datosBasicos.sic, 3) : "";
          if (!!datosBasicos.personData) {
            if (!!datosBasicos.personData.personName && estadoCliente !== "NO EXISTE") {
              this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido = !!datosBasicos.personData.personName.paternalName ? this._titlecasePipe.transform(datosBasicos.personData.personName.paternalName) : "";
              this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido = !!datosBasicos.personData.personName.maternalName ? this._titlecasePipe.transform(datosBasicos.personData.personName.maternalName) : "";
              this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre = !!datosBasicos.personData.personName.givenName ? this._titlecasePipe.transform(datosBasicos.personData.personName.givenName) : "";
            }
            if (!!datosBasicos.personData.contactList && datosBasicos.personData.contactList.contact.length > 0) {
              datosBasicos.personData.contactList.contact.forEach(ubicacion => {
                if (!!ubicacion.phoneNum) {
                  if (ubicacion.phoneNum.phoneType === "Mobile") {
                    this.solicitud.datosSolicitud.personaNatural[0].ubicacion.numeroCelular = !!ubicacion.phoneNum.phone ? ubicacion.phoneNum.phone : "";
                  }
                  if (ubicacion.phoneNum.phoneType === "Phone2") {
                    this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.telefonoOficina = !!ubicacion.phoneNum.phone ? ubicacion.phoneNum.phone : "";
                  }
                }
                if (!!ubicacion.postAddr) {
                  const direccion = !!ubicacion.postAddr.addr1 ? this.validAddress.validacionDireccion(ubicacion.postAddr.addr1) : "";
                  this.solicitud.datosSolicitud.personaNatural[0].ubicacion.direccionResidencia = !!ubicacion.postAddr.addr1 ? this.transformation.addressComparison(direccion) : "";
                  if (!!ubicacion.postAddr.stateProvCode) {
                    const depUbicacion = filtrarCatalogo(ubicacion.postAddr.stateProvCode, ciudades, 'valorPadre');
                    if (!!depUbicacion && depUbicacion.length > 0 && !!ubicacion.postAddr.city) {
                      const ciuUbicacion = filtrarCatalogo(ubicacion.postAddr.city, depUbicacion, 'nombre');
                      if (!!ciuUbicacion && ciuUbicacion.length > 0) {
                        this.solicitud.datosSolicitud.personaNatural[0].ubicacion.codDepartamentoResidencia = !!ubicacion.postAddr.stateProvCode ? ubicacion.postAddr.stateProvCode : "";
                        this.solicitud.datosSolicitud.personaNatural[0].ubicacion.desDepartamentoResidencia = !!depUbicacion ? depUbicacion[0].nombreDpto : "";
                        this.solicitud.datosSolicitud.personaNatural[0].ubicacion.codCiudadResidencia = !!ubicacion.postAddr.cityCode ? ubicacion.postAddr.cityCode : "";
                        this.solicitud.datosSolicitud.personaNatural[0].ubicacion.desCiudadResidencia = !!ciuUbicacion ? ciuUbicacion[0].nombre : "";
                      }
                    }
                  }
                }
              });
            }
            if (!!datosBasicos.birthStateProv) {
              const depEncontrado = filtrarCatalogo(datosBasicos.birthStateProv, ciudades, 'valorPadre');
              if (!!depEncontrado && depEncontrado.length > 0 && !!datosBasicos.birthPlace) {
                const ciudadEncontrada = filtrarCatalogo(datosBasicos.birthPlace, depEncontrado, 'nombre');
                if (!!ciudadEncontrada && ciudadEncontrada.length > 0) {
                  this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.codDepartamentoNacimiento = ciudadEncontrada[0].valorPadre;
                  this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.desDepartamentoNacimiento = ciudadEncontrada[0].nombreDpto;
                  this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.codCiudadNacimiento = ciudadEncontrada[0].valor;
                  this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.desCiudadNacimiento = ciudadEncontrada[0].nombre;
                }
              }
            }
          }
          this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.fechaNacimiento = !!datosBasicos.birthDt ? datosBasicos.birthDt : "";
          this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.codGenero = !!datosBasicos.gender ? datosBasicos.gender : "";
          this.solicitud.datosSolicitud.personaNatural[0].datosBasicos.desGenero = !!datosBasicos.gender ? datosBasicos.gender === VALOR_SEXO_M ? DES_SEXO_MASCULINO : datosBasicos.gender === VALOR_SEXO_F ? DES_SEXO_FEMENINO : "" : "";
        }
      }
    }

    if (!!customerInformation) {
      if (!!customerInformation.getCustomerAdditionalDataRsType) {
        const getCustomerAdditionalDataRsType = customerInformation.getCustomerAdditionalDataRsType;
        if (!!getCustomerAdditionalDataRsType.partyAdditionalInfoList.partyAdditionalInfo) {
          const aditionalInfo = getCustomerAdditionalDataRsType.partyAdditionalInfoList.partyAdditionalInfo;
          aditionalInfo.forEach(info => {
            switch (info.additionalInfoName) {
              // Ubicacion
              case "Correo Electrónico":
                this.solicitud.datosSolicitud.personaNatural[0].ubicacion.correoElectronico = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? info.additionalInfoValue : "";
                break;
              case "Residencia fiscal Otro País":
                this.solicitud.datosSolicitud.personaNatural[0].ubicacion.residenciaFiscalOtroPais = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "";
                break;
              case "Tiene ud una direccion en el extranjero":
                this.solicitud.datosSolicitud.personaNatural[0].ubicacion.direccionOtroPais = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "";
                break;
              case "País (segunda dirección)":
                this.solicitud.datosSolicitud.personaNatural[0].ubicacion.desOtroPais = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? info.additionalInfoValue : "";
                break;

              // Actividad Economica
              case "Ocupación":
                this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.desOcupacion = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? info.additionalInfoValue : "";
                this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codOcupacion = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.transformation.getCodOcupation(info.additionalInfoValue) : "";
                break;
              case "Nombre de la Empresa donde Trabaja":
                this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.nombreEmpresa = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this._titlecasePipe.transform(info.additionalInfoValue) : "";
                break;
              case "Dirección de la Empresa u Oficina":
                this.solicitud.datosSolicitud.personaNatural[0].actividadEconomica.direccionEmpresa = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? info.additionalInfoValue : "";
                break;

              // Informacion Financiera
              case "Ingresos Fijos o Salario":
                this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.ingresoPrincipalCore = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.transformation.deFormatMoney(info.additionalInfoValue) : 0;
                break;
              case "Detallar Otros Ingresos":
                if (!!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== ".") {
                  let valueIngresos: string;
                  valueIngresos = this.transformation.getOtrosIngresos(this.transformation.deleteAccent(info.additionalInfoValue));
                  if (this.transformation.deleteAccent(info.additionalInfoValue) !== "ninguno") {
                    if (valueIngresos === this.transformation.deleteAccent(info.additionalInfoValue)) {
                      this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.codConceptoOtrosIngresos = "17";
                      this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.desConceptoOtrosIngresos = "Otros";
                      this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.desOtroConcepto = info.additionalInfoValue;
                    } else {
                      this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.codConceptoOtrosIngresos = this.transformation.splitText(valueIngresos)[0].toString();
                      this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.desConceptoOtrosIngresos = this.transformation.splitText(valueIngresos)[1].toString();
                    }
                  }
                }
                break;
              case "Otros Ingresos":
                this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.otrosIngresos = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.transformation.deFormatMoney(info.additionalInfoValue) : 0;
                break;
              case "Comisiones":
                this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.desConceptoOtrosIngresos = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? info.additionalInfoValue : "";
                break;
              case "Honorarios":
                this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.desConceptoOtrosIngresos = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? info.additionalInfoValue : "";
                break;
              case "Arrendamientos":
                this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.desConceptoOtrosIngresos = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? info.additionalInfoValue : "";
                break;
              case "Total Ingresos":
                this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.totalIngresos = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.transformation.deFormatMoney(info.additionalInfoValue) : 0;
                break;
              case "Total Egresos":
                this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.egresosMensuales = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.transformation.deFormatMoney(info.additionalInfoValue) : 0;
                break;
              case "Total Activos":
                this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.totalActivos = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.transformation.deFormatMoney(info.additionalInfoValue) : 0;
                break;
              case "Total Pasivos":
                this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.totalPasivos = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.transformation.deFormatMoney(info.additionalInfoValue) : 0;
                break;
              case "Total Patrimonio":
                this.solicitud.datosSolicitud.personaNatural[0].informacionFinanciera.patrimonio = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.transformation.deFormatMoney(info.additionalInfoValue) : 0;
                break;

              // Operaciones Moneda Extranjera
              case "Realiza Transacciones en Moneda Extranje":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.realizaOperacionesMonedaExtranjera = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "";
                break;
              case "Importaciones":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionImportaciones = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "";
                break;
              case "Exportaciones":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionExportaciones = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "";
                break;
              case "Inversiones":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionInversiones = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "";
                break;
              case "Crédito en Moneda Extranjera":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionCredito = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "";
                break;
              case "Pago de Servicios en Moneda Extranjera":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoOperacionPagoServicios = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "";
                break;
              case "Cual Operacion en Moneda Extranjera?":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.otroTipoOperacion = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this._titlecasePipe.transform(info.additionalInfoValue) : "";
                break;
              case "Posees Productos en Moneda Extranjera?":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.titularProductosMonedaExtranjera = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.validation.trueToYesValue(info.additionalInfoValue) : "";
                break;
              case "Tipo de Producto":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.tipoProducto = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this._titlecasePipe.transform(info.additionalInfoValue) : "";
                break;
              case "Numero de producto":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.numeroProducto = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? info.additionalInfoValue : "";
                break;
              case "Monto":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.monto = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this.transformation.deFormatMoney(info.additionalInfoValue) : 0;
                break;
              case "Entidad":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.entidad = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this._titlecasePipe.transform(info.additionalInfoValue) : "";
                break;
              case "Tipo de Moneda Extranjera":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.desMoneda = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this._titlecasePipe.transform(info.additionalInfoValue) : "";
                break;
              case "País Moneda Extranjera":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.desPais = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? info.additionalInfoValue : "";
                break;
              case "Ciudad Moneda Extranjera":
                this.solicitud.datosSolicitud.personaNatural[0].operacionesMonedaExtranjera.ciudad = !!info.additionalInfoValue && info.additionalInfoValue !== " " && info.additionalInfoValue !== "." ? this._titlecasePipe.transform(info.additionalInfoValue) : "";
                break;
            }
          });
        }
      }
    }

    return this.solicitud;
  }
}
