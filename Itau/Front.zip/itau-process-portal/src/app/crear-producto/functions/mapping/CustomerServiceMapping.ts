import { FormGroup } from "@angular/forms";
import { Validation } from '../util/validation';
import { Transformation } from "../../../shared/functions/util/Trasnformation";
import { ValidAddress } from '../../../shared/functions/util/validations/ValidAddress';
import { REQUEST_CUSTOMER_ADD_CUSTOMER } from '../../../shared/constants/codigosServicios.constant';
import { KEYS_INFORMACION_ADICIONAL_EVENTOS } from '../../../shared/constants/mensaje-eventos-constant';
import { Solicitud } from "../../models/negocio/Solicitud";
import { RequestWrapperAddCustomer } from '../../models/services/customer/addCustomer/RequestWrapperAddCustomer';
import { AddCustomerRqType } from '../../models/services/customer/addCustomer/AddCustomerRqType';
import { HeaderRequestType } from '../../models/services/customer/commons/HeaderRequestType';
import { MessageHeaderType } from '../../models/services/customer/commons/MessageHeaderType';
import { MessageInfoType } from '../../models/services/customer/commons/MessageInfoType';
import { PartyType } from '../../models/services/customer/commons/PartyType';
import { PartyKeyType } from '../../models/services/customer/commons/PartyKeyType';
import { PersonPartyInfoType } from '../../models/services/customer/commons/PersonPartyInfoType';
import { EmploymentType } from '../../models/services/customer/commons/EmploymentType';
import { IndustIdentType } from '../../models/services/customer/commons/IndustIdentType';
import { PersonDataType } from '../../models/services/customer/commons/PersonDataType';
import { IssuedIdentType } from '../../models/services/customer/commons/IssuedIdentType';
import { PersonNameType } from '../../models/services/customer/commons/PersonNameType';
import { ContactListType } from '../../models/services/customer/commons/ContactListType';
import { ContactType } from '../../models/services/customer/commons/ContactType';
import { PhoneNumType } from '../../models/services/customer/commons/PhoneNumType';
import { PostAddrType } from '../../models/services/customer/commons/PostAddrType';
import { CountryType } from '../../models/services/customer/commons/CountryType';
import { PartyAdditionalInfoListType } from '../../models/services/customer/commons/PartyAdditionalInfoListType';
import { PartyAdditionalInfoType } from '../../models/services/customer/commons/PartyAdditionalInfoType';
import { EmailType } from '../../models/services/customer/commons/EmailType';
import { CapitalizeTextPipe } from '../../../shared/pipes/capitalize-text.pipe';


export class CustomerServiceMapping {

    public date: string;
    public validAddress: ValidAddress;
    public transformation: Transformation;
    public validation: Validation;
    public _titlecasePipe: CapitalizeTextPipe;
    public request: RequestWrapperAddCustomer;

    constructor() {
        this.date = new Date().toISOString();
        this.validAddress = new ValidAddress();
        this.transformation = new Transformation();
        this.validation = new Validation();
        this.request = new RequestWrapperAddCustomer();
        this._titlecasePipe = new CapitalizeTextPipe();
    }

    /**
     * Construye un objeto tipo RequestWrapperAddCustomer
     *
     * @name addCustomerMapping
     * @param body
     * @param solicitud
     * @returns RequestWrapperAddCustomer
     * @since 12/03/2019
     */
    addCustomerMapping(body: FormGroup, solicitud: Solicitud): RequestWrapperAddCustomer {
        // transformacion
        let birPlace = !!body.get("birthplace").value ? body.get("birthplace").value.split("-") : "";
        let resPlace = !!body.get("place").value ? body.get("place").value.split("-") : "";
        let locPlace = !!body.get("locate").value ? body.get("locate").value.split("-") : "";
        let ciu = !!body.get("ciiu_control").value ? body.get("ciiu_control").value.split("-") : "";

        const emptyCity = "0-0-0-0";

        if (birPlace.length < 4) {
            birPlace = emptyCity.split("-");
        }
        if (resPlace.length < 4) {
            resPlace = emptyCity.split("-");
        }
        if (locPlace.length < 4) {
            locPlace = emptyCity.split("-");
        }
        if (ciu.length < 4) {
            ciu = emptyCity.split("-");
        }

        this.request.addCustomerRqType = new AddCustomerRqType();
        this.request.addCustomerRqType.headerRequest = new HeaderRequestType();
        this.request.addCustomerRqType.headerRequest.messageHeader = new MessageHeaderType();
        this.request.addCustomerRqType.headerRequest.messageHeader.messageInfo = new MessageInfoType();
        this.request.addCustomerRqType.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_CUSTOMER_ADD_CUSTOMER.BPM_AUTHOR;
        this.request.addCustomerRqType.headerRequest.messageHeader.messageInfo.systemId = REQUEST_CUSTOMER_ADD_CUSTOMER.BPM_AUTHOR;
        this.request.addCustomerRqType.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_CUSTOMER_ADD_CUSTOMER.ORIGINATOR_TYPE;
        this.request.addCustomerRqType.headerRequest.messageHeader.messageInfo.terminalId = REQUEST_CUSTOMER_ADD_CUSTOMER.TERMINAL_ID;
        this.request.addCustomerRqType.opnInd = REQUEST_CUSTOMER_ADD_CUSTOMER.OPN_IND;
        this.request.addCustomerRqType.party = new PartyType();
        this.request.addCustomerRqType.party.partyKey = new PartyKeyType();
        this.request.addCustomerRqType.party.partyKey.partyType = REQUEST_CUSTOMER_ADD_CUSTOMER.IDENTIFICADOR_CLASE_PHOENIX;
        this.request.addCustomerRqType.party.personPartyInfo = new PersonPartyInfoType();
        this.request.addCustomerRqType.party.personPartyInfo.serviceLevelCode = REQUEST_CUSTOMER_ADD_CUSTOMER.SERVICE_LEVEL_CODE;
        this.request.addCustomerRqType.party.personPartyInfo.birthDt = this.transformation.formatDateYearMonthDay2(this.transformation.formatDate(body.get("date").value));
        this.request.addCustomerRqType.party.personPartyInfo.birthPlace = birPlace[1].trim();
        this.request.addCustomerRqType.party.personPartyInfo.birthStateProv = birPlace[3].trim();
        this.request.addCustomerRqType.party.personPartyInfo.campaignIdent = REQUEST_CUSTOMER_ADD_CUSTOMER.CAMPAÑA;
        this.request.addCustomerRqType.party.personPartyInfo.educationLevel = "";
        this.request.addCustomerRqType.party.personPartyInfo.electronicStmtInd = REQUEST_CUSTOMER_ADD_CUSTOMER.MARCACION_EXTRACTO_DIGITAL;
        this.request.addCustomerRqType.party.personPartyInfo.employment = new EmploymentType();
        this.request.addCustomerRqType.party.personPartyInfo.employment.occupation = this.transformation.getOcupation(body.get("typeOcup").value);
        this.request.addCustomerRqType.party.personPartyInfo.feePlan = !!body.get("nomina").value ? this.transformation.splitText(body.get("nomina").value)[1] : REQUEST_CUSTOMER_ADD_CUSTOMER.GRUPO_CARGO_NINGUNO;
        this.request.addCustomerRqType.party.personPartyInfo.gender = body.get("sexoControl").value;
        this.request.addCustomerRqType.party.personPartyInfo.industIdent = new IndustIdentType();
        this.request.addCustomerRqType.party.personPartyInfo.industIdent.industNum = ciu[2].trim();
        this.request.addCustomerRqType.party.personPartyInfo.nationality = REQUEST_CUSTOMER_ADD_CUSTOMER.CODIGO_NACIONALIDAD;
        this.request.addCustomerRqType.party.personPartyInfo.originatingBranch = solicitud.datosSolicitud.radicador.codOficina;
        this.request.addCustomerRqType.party.personPartyInfo.originationInfo = REQUEST_CUSTOMER_ADD_CUSTOMER.BPM_AUTHOR;
        this.request.addCustomerRqType.party.personPartyInfo.sic = ciu[0].trim();
        this.request.addCustomerRqType.party.personPartyInfo.personData = new PersonDataType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.issuedIdent = new IssuedIdentType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.issuedIdent.issuedIdentType = solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion;
        this.request.addCustomerRqType.party.personPartyInfo.personData.issuedIdent.issuedIdentValue = solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion;
        this.request.addCustomerRqType.party.personPartyInfo.personData.personName = new PersonNameType();
        const fullname = solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre + " " + solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido + " " + solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido;
        this.request.addCustomerRqType.party.personPartyInfo.personData.personName.fullName = fullname;
        this.request.addCustomerRqType.party.personPartyInfo.personData.personName.givenName = solicitud.datosSolicitud.personaNatural[0].datosBasicos.nombre;
        this.request.addCustomerRqType.party.personPartyInfo.personData.personName.paternalName = solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido;
        this.request.addCustomerRqType.party.personPartyInfo.personData.personName.maternalName = !!solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido ? solicitud.datosSolicitud.personaNatural[0].datosBasicos.segundoApellido : "";

        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList = new ContactListType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact = new Array<ContactType>();

        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[0] = new ContactType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[0].phoneNum = new PhoneNumType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[0].phoneNum.phone = body.get("phone").value;
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[0].phoneNum.phoneDesc = "";
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[0].phoneNum.phoneType = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_TELEFONO_CELULAR;

        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[1] = new ContactType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[1].phoneNum = new PhoneNumType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[1].phoneNum.phone = body.get("phone").value;
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[1].phoneNum.phoneDesc = "";
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[1].phoneNum.phoneType = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_TELEFONO_FIJO;

        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2] = new ContactType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr = new PostAddrType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr.addr1 = this.validAddress.validacionDireccion(body.get("address").value);
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr.addrDesc = "";
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr.addrType = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_RESIDENCIA;
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr.city = resPlace[0].trim();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr.cityCode = resPlace[1].trim();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr.stateProv = resPlace[2].trim();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr.stateProvCode = resPlace[3].trim();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr.country = new CountryType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr.country.countryCode = REQUEST_CUSTOMER_ADD_CUSTOMER.CODIGO_NACIONALIDAD;
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[2].postAddr.country.countryName = REQUEST_CUSTOMER_ADD_CUSTOMER.NACIONALIDAD;

        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[3] = new ContactType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[3].email = new EmailType();
        this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[3].email.emailAddr = body.get("email").value;

        if (!!body.get("phoneEmp").value) {
            this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[4] = new ContactType();
            this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[4].phoneNum = new PhoneNumType();
            this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[4].phoneNum.phone = body.get("phoneEmp").value;
            this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[4].phoneNum.phoneDesc = "";
            this.request.addCustomerRqType.party.personPartyInfo.personData.contactList.contact[4].phoneNum.phoneType = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_TELEFONO_EMPRESA;
        }

        this.request.addCustomerRqType.party.partyAdditionalInfoList = new PartyAdditionalInfoListType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo = new Array<PartyAdditionalInfoType>();
        let longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        if (!!body.get("output").value) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.EGRESOS;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = String(body.get("output").value);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }
        if (!!body.get("main").value || body.get("main").value === 0) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.INGRESOS;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = String(body.get("main").value);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }
        if (!!body.get("nameEmp").value) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.NOMBRE_EMPRESA;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this._titlecasePipe.transform(body.get("nameEmp").value);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }
        if (!!body.get("others").value || body.get("others").value === 0) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.OTROS_INGRESOS;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = String(body.get("others").value);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }
        if (!!body.get("patrimonio").value || body.get("patrimonio").value === 0) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TOTAL_PATRIMONIO;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = String(body.get("patrimonio").value);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }
        if (!!body.get("total").value || body.get("total").value === 0) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TOTAL_ACTIVOS;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = String(body.get("total").value);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }
        if (!!body.get("pasive").value || body.get("pasive").value === 0) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TOTAL_PASIVOS;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = String(body.get("pasive").value);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }
        if (!!solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto && solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.pep !== "") {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.PEP;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.changeYesNo(solicitud.datosSolicitud.personaNatural[0].publicamenteExpuesto.pep);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }

        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TIENE_DIRECCION_OTRO_PAIS;
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.changeYesNo(body.get("dirPaisControl").value);
        longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.REALIZA_OPERACIONES_MONEDA_EXTRANJERA;
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.changeYesNo(body.get("opeExtControl").value);
        longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        if (body.get("opeExtControl").value === "S") {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_OPERACION_CREDITO;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.changeYesNo(this.validation.trueToYes(body.get("tipoOperacionesCred").value));
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_OPERACION_EXPORTACIONES;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.changeYesNo(this.validation.trueToYes(body.get("tipoOperacionesExpo").value));
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_OPERACION_IMPORTACIONES;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.changeYesNo(this.validation.trueToYes(body.get("tipoOperacionesInter").value));
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_OPERACION_INVERSIONES;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.changeYesNo(this.validation.trueToYes(body.get("tipoOperacionesInve").value));
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_OPERACION_PAGO_SERVICIOS;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.changeYesNo(this.validation.trueToYes(body.get("tipoOperacionesServ").value));
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

            if (!!body.get("operation").value) {
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.OTRO_TIPO_OPERACION;
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this._titlecasePipe.transform(body.get("operation").value);
                longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
            }
        }

        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TIENE_RESIDENCIA_FISCAL_OTRO_PAIS;
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.changeYesNo(body.get("resPaisControl").value);
        longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TITULAR_PRODUCTOS_MONEDA_EXTRANJERA;
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.changeYesNo(body.get("titularMonExtranj").value);
        longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        if (body.get("titularMonExtranj").value === "S") {
            if (!!body.get("numpro").value) {
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.NUMERO_PRODUCTO_MONEDA_EXTRANJERA;
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = body.get("numpro").value;
                longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
            }
            if (!!body.get("entity").value) {
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.ENTIDAD_OPERACION_MONEDA_EXTRANJERA;
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this._titlecasePipe.transform(body.get("entity").value);
                longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
            }
            if (!!body.get("countryCoin").value) {
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.CODIGO_PAIS_RESIDENCIA_FISCAL;
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = body.get("countryCoin").value;
                longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
            }
            if (!!body.get("amount").value || body.get("amount").value === 0) {
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.MONTO_OPERACION_MONEDA_EXTRANJERA;
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = String(body.get("amount").value);
                longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
            }
            if (!!body.get("cityCoin").value) {
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.CIUDAD_OPERACION_MONEDA_EXTRANJERA;
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue =  this._titlecasePipe.transform(body.get("cityCoin").value);
                longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
            }
        }

        if (!!body.get("typeOcup").value) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_OCUPACION;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this.transformation.getOcupation(body.get("typeOcup").value);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }

        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.PAIS_RECIDENCIA_FISCAL;
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = REQUEST_CUSTOMER_ADD_CUSTOMER.NACIONALIDAD_UPPER;
        longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        const ingresos = !!body.get("main").value ? Number(body.get("main").value) : 0;
        const otrosIngresos = !!body.get("others").value ? Number(body.get("others").value) : 0;
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TOTAL_INGRESOS;
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = String(ingresos + otrosIngresos);
        longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        if (!!body.get("output").value || body.get("output").value === 0) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TOTAL_EGRESOS;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue =  String(body.get("output").value);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }

        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.CODIGO_NACIONALIDAD_ADD;
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = REQUEST_CUSTOMER_ADD_CUSTOMER.NACIONALIDAD_UPPER;
        longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.PAIS_OPERACION_MONEDA_EXTRANJERA;
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = !!body.get("country").value ? this.transformation.splitText(body.get("country").value)[0] : REQUEST_CUSTOMER_ADD_CUSTOMER.NACIONALIDAD_UPPER;
        longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.RESULTADO_ENTREVISTA;
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = REQUEST_CUSTOMER_ADD_CUSTOMER.RESULTADO_ENTREVISTA_VALOR;
        longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
        this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.CONCEPTO_OTROS_INGRESOS;

        if (!(!!body.get("others").value) || String(body.get("others").value) === "0") {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = REQUEST_CUSTOMER_ADD_CUSTOMER.NINGUNO;
        } else if (!!body.get("conceptoing").value) {
            const llave = this.transformation.splitText(body.get("conceptoing").value)[1];
            const valor = this.transformation.splitText(body.get("conceptoing").value)[0];
            if (llave === "17" && !!body.get("otherConcept").value) {
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = this._titlecasePipe.transform(body.get("otherConcept").value);
            } else {
                this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue = valor;
            }
        }
        longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;

        if (!!body.get("addEmp").value) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.DIRECCION_EMPRESA;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue =  this.validAddress.validacionDireccion(body.get("addEmp").value);
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }

        /*
        if (!!body.get("typpro").value) {
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional] = new PartyAdditionalInfoType();
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoId = REQUEST_CUSTOMER_ADD_CUSTOMER.TIPO_PRODUCTO_MONEDA_EXTRANJERA;
            this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo[longitudInfoAdicional].additionalInfoValue =  body.get("typpro").value;
            longitudInfoAdicional = this.request.addCustomerRqType.party.partyAdditionalInfoList.partyAdditionalInfo.length;
        }*/

        const informacionFinanciera = {};
        informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.INGRESO_TERCERAS_FUENTES] = !!body.get('estimatedIncome').value ? body.get('estimatedIncome').value : (!!body.get('validatedIncome').value ? body.get('validatedIncome').value : "");
        informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.ORIGEN_INGRESO_TERCERAS_FUENTES] = !!body.get("estimatedIncome") && !!body.get("estimatedIncome").value ? "Experian" : (!!body.get("validatedIncome") && !!body.get("validatedIncome").value ? "Experian" : "");
        informacionFinanciera[KEYS_INFORMACION_ADICIONAL_EVENTOS.TIPO_INGRESO_TERCERAS_FUENTES] = !!body.get("estimatedIncome") && !!body.get("estimatedIncome").value ? "Estimado" : (!!body.get("validatedIncome") && !!body.get("validatedIncome").value ? "Validado" : "");

        const radicador = {};
        radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.USUARIO] = solicitud.datosSolicitud.radicador.usuarioRadicador;
        radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.NOMBRE] = solicitud.datosSolicitud.radicador.nombreRadicador;
        radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_IDENTIFICACION] = solicitud.datosSolicitud.radicador.numeroIdentificacion;
        radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.CODIGO_OFICINA] = solicitud.datosSolicitud.radicador.codOficina;

        this.request.infoAdicionalEventos = {};
        this.request.infoAdicionalEventos[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_SOLICITUD] = solicitud.numeroSolicitud;
        this.request.infoAdicionalEventos[KEYS_INFORMACION_ADICIONAL_EVENTOS.INFORMACION_FINANCIERA] = informacionFinanciera;
        this.request.infoAdicionalEventos[KEYS_INFORMACION_ADICIONAL_EVENTOS.RADICADOR] = radicador;

        if (solicitud.datosSolicitud.personaNatural[0].estadoCliente === "EXISTE") {
            this.request.infoAdicionalEventos[KEYS_INFORMACION_ADICIONAL_EVENTOS.DESCRIPCION_OPERACION] = "Actualizacion de cliente";
        } else {
            this.request.infoAdicionalEventos[KEYS_INFORMACION_ADICIONAL_EVENTOS.DESCRIPCION_OPERACION] = "Creacion de cliente";
        }

        return this.request;
    }

}
