import { FormGroup } from '@angular/forms';
import { Solicitud } from '../../models/negocio/Solicitud';
import { CapitalizeTextPipe } from '../../../shared/pipes/capitalize-text.pipe';

export class DocumentosRechazadosSORMapping {
    public solicitud: Solicitud;
    public _titlecasePipe: CapitalizeTextPipe;

    constructor() {
        this._titlecasePipe = new CapitalizeTextPipe();
    }

    mappingDocumentosRechazados(body: FormGroup, solicitudActividad: Solicitud): Solicitud {
        // Mapeo informacion solicitud anterior
        this.solicitud = solicitudActividad;

        this.solicitud.datosSolicitud.personaNatural[0].documentos.comentarioRechazado = !!body.get("comentarioRechazado").value ? this._titlecasePipe.transform(body.get("comentarioRechazado").value) : "";

        return this.solicitud;
    }
}
