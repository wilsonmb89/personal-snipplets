import { ConsultaListasRestrictivas } from './../../models/services/listasRestrictivas/RequestConsultaListas';
import { FormGroup } from "@angular/forms";
import { REQUEST_SAFEWATCH_V2 } from '../../../shared/constants/codigosServicios.constant';
import { HeaderRequest } from '../../models/services/consultaListas/HeaderRequest';
import { MessageHeader } from '../../models/services/consultaListas/MessageHeader';
import { MessageInfo } from '../../models/services/consultaListas/MessageInfo';
import { MessageKey } from '../../models/services/consultaListas/MessageKey';
import { CustId } from '../../models/services/consultaListas/CustId';

export class ConsultaListasMapping {
    public requestListasRestrictivas: ConsultaListasRestrictivas;
    constructor() {
        this.requestListasRestrictivas = new ConsultaListasRestrictivas();
    }

    fillRequestConsultaListas(body: FormGroup): ConsultaListasRestrictivas {

        const documentId = body.get("documentId").value;
        let fullName: string;

        if (!!body.get("fullName").value && body.get("fullName").value.length > 0) {
            fullName = (body.get("fullName").value.trim()).toUpperCase();
        } else {
            fullName = (body.get("name").value.trim() + " " + body.get("firstLastname").value.trim() + " " + body.get("secondLastname").value.trim()).toUpperCase();
        }

        this.requestListasRestrictivas.headerRequest = new HeaderRequest();
        this.requestListasRestrictivas.headerRequest.messageHeader = new MessageHeader();
        this.requestListasRestrictivas.headerRequest.messageHeader.messageKey = new MessageKey();
        this.requestListasRestrictivas.headerRequest.messageHeader.messageKey.requestUUID = "";
        this.requestListasRestrictivas.headerRequest.messageHeader.messageInfo = new MessageInfo();
        this.requestListasRestrictivas.headerRequest.messageHeader.messageInfo.dateTime = "";
        this.requestListasRestrictivas.headerRequest.messageHeader.messageInfo.systemId = REQUEST_SAFEWATCH_V2.SYSTEM_ID;
        this.requestListasRestrictivas.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_SAFEWATCH_V2.ORIGINATOR_NAME;
        this.requestListasRestrictivas.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_SAFEWATCH_V2.ORIGINATOR_TYPE;
        this.requestListasRestrictivas.headerRequest.messageHeader.messageInfo.terminalId = REQUEST_SAFEWATCH_V2.TERMINAL_ID;
        this.requestListasRestrictivas.custId = new CustId();
        this.requestListasRestrictivas.custId.custPermId = documentId;
        this.requestListasRestrictivas.custId.spname = fullName;
        this.requestListasRestrictivas.custId.custType = "1";
        this.requestListasRestrictivas.comment = REQUEST_SAFEWATCH_V2.COMMENT;
        this.requestListasRestrictivas.applicationCode = REQUEST_SAFEWATCH_V2.APPLICATION_CODE;

        return this.requestListasRestrictivas;
    }

}
