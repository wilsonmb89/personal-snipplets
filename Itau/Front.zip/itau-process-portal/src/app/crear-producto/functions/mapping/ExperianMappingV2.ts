import { Solicitud } from '../../models/negocio/Solicitud';
import { GetCustomerIncomeEstimatedRq } from '../../models/services/experian/v2/GetCustomerIncomeEstimatedRq';
import { CustId } from '../../models/services/experian/v2/CustId';
import { HeaderRequest } from '../../models/services/experian/v2/HeaderRequest';
import { MessageHeader } from '../../models/services/experian/v2/MessageHeader';
import { MessageInfo } from '../../models/services/experian/v2/MessageInfo';
import { REQUEST_EXPERIAN } from '../../../shared/constants/codigosServicios.constant';

/**
 *  Clase que contiene el metodo de mapeo para las operaciones del sercicio de CustomerIncomeEstimated Version 2
 *  @author Juan Umbarila - EJU03419
 *  @since 17/04/2019
 */
export class ExperianMappingV2 {

    public customerIncomeEstimated: GetCustomerIncomeEstimatedRq;

    constructor() {
        this.customerIncomeEstimated = new GetCustomerIncomeEstimatedRq();
        this.customerIncomeEstimated.custId = new CustId();
        this.customerIncomeEstimated.headerRequest = new HeaderRequest();
        this.customerIncomeEstimated.headerRequest.messageHeader = new MessageHeader();
        this.customerIncomeEstimated.headerRequest.messageHeader.messageInfo = new MessageInfo();
    }

    /**
     * Metodo para realizar mapeo del objeto canonico del servicio de CustomerIncomeEstimated, operacion getCustomerIncomeEstimated
     * @param solicitud
     * @returns GetCustomerIncomeEstimatedRq
     */
    mappingToGetCustomerIncomeEstimated(solicitud: Solicitud): GetCustomerIncomeEstimatedRq {
        if (!!solicitud) {
            this.customerIncomeEstimated.custId.custPermId = (!!solicitud.datosSolicitud.personaNatural[0] && !!solicitud.datosSolicitud.personaNatural[0].datosBasicos) ? solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion : "";
            this.customerIncomeEstimated.custId.custType = (!!solicitud.datosSolicitud.personaNatural[0] && !!solicitud.datosSolicitud.personaNatural[0].datosBasicos) ? solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion : "1";
            this.customerIncomeEstimated.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_EXPERIAN.BPM_AUTHOR;
            this.customerIncomeEstimated.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_EXPERIAN.ORIGINATOR_TYPE;
            this.customerIncomeEstimated.headerRequest.messageHeader.messageInfo.systemId = REQUEST_EXPERIAN.BPM_AUTHOR;
            this.customerIncomeEstimated.headerRequest.messageHeader.messageInfo.terminalId = REQUEST_EXPERIAN.TERMINAL_ID;
            this.customerIncomeEstimated.lastName = (!!solicitud.datosSolicitud.personaNatural[0] && !!solicitud.datosSolicitud.personaNatural[0].datosBasicos) ? solicitud.datosSolicitud.personaNatural[0].datosBasicos.primerApellido : "";
            return this.customerIncomeEstimated;
        } else {
            return null;
        }
    }
}
