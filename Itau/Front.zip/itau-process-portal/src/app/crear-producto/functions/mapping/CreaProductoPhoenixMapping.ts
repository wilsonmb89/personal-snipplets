import { AddAccountRq } from "../../models/services/productoPhoenix/AddAccountRq";
import { Solicitud } from "../../models/negocio/Solicitud";
import { HeaderRequestType } from "../../models/services/productoPhoenix/HeaderRequestType";
import { MessageHeaderType } from "../../models/services/productoPhoenix/MessageHeaderType";
import { MessageInfoType } from "../../models/services/productoPhoenix/MessageInfoType";
import { REQUEST_CREA_PRODUCTO_PHOENIX } from "../../../shared/constants/codigosServicios.constant";
import { UserType } from "../../models/services/productoPhoenix/UserType";
import { AcctType } from "../../models/services/productoPhoenix/AcctType";
import { AcctKeyType } from "../../models/services/productoPhoenix/AcctKeyType";
import { PartyAcctRelInfoType } from "../../models/services/productoPhoenix/PartyAcctRelInfoType";
import { PersonDataType } from "../../models/services/productoPhoenix/PersonDataType";
import { IssuedIdentType } from "../../models/services/productoPhoenix/IssuedIdentType";
import { AcctInfoType } from "../../models/services/productoPhoenix/AcctInfoType";
import { ListRecurXferInfoType } from "../../models/services/productoPhoenix/ListRecurXferInfoType";
import { RecurXferInfoType } from "../../models/services/productoPhoenix/RecurXferInfoType";
import { FormGroup } from "@angular/forms";
import { XferInfoType } from "../../models/services/productoPhoenix/XferInfoType";
import { CurrencyAmountType } from "../../models/services/productoPhoenix/CurrencyAmountType";
import { RecurModelType } from "../../models/services/productoPhoenix/RecurModelType";
import { RecurRuleType } from "../../models/services/productoPhoenix/RecurRuleType";
import { RequestWrapperAddAccount } from '../../models/services/productoPhoenix/RequestWrapperAddAccount';
import { KEYS_INFORMACION_ADICIONAL_EVENTOS } from '../../../shared/constants/mensaje-eventos-constant';

export class CreaProductoPhoenixMapping {

    public requestCreaProducto: RequestWrapperAddAccount;
    public informacionProducto: any;
    public actividadEconomina: any;
    public radicador: any;
    public vendedor: any;

    constructor() {
        this.requestCreaProducto = new RequestWrapperAddAccount();
        this.requestCreaProducto.addAccountRq = new AddAccountRq();
        this.requestCreaProducto.addAccountRq.headerRequest = new HeaderRequestType();
        this.requestCreaProducto.addAccountRq.headerRequest.messageHeader = new MessageHeaderType();
        this.requestCreaProducto.addAccountRq.headerRequest.messageHeader.messageInfo = new MessageInfoType();
        this.requestCreaProducto.addAccountRq.headerRequest.user = new UserType();
        this.requestCreaProducto.addAccountRq.acct = new AcctType();
        this.requestCreaProducto.addAccountRq.acct.acctKey = new AcctKeyType();
        this.requestCreaProducto.addAccountRq.acct.partyAcctRelInfo = new PartyAcctRelInfoType();
        this.requestCreaProducto.addAccountRq.acct.partyAcctRelInfo.personData = new PersonDataType();
        this.requestCreaProducto.addAccountRq.acct.partyAcctRelInfo.personData.issuedIdent = new IssuedIdentType();
        this.requestCreaProducto.addAccountRq.acct.acctInfo = new AcctInfoType();
        this.requestCreaProducto.addAccountRq.listRecurXferInfo = new ListRecurXferInfoType();
        this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo = new Array<RecurXferInfoType>();
        this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0] = new RecurXferInfoType();
        this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].xferInfo = new XferInfoType();
        this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].xferInfo.fromAcctRef = new AcctKeyType();
    }

    mappingCreaCuentaAhorros(solicitud: Solicitud, data: any, formAhorroProgramado: FormGroup): RequestWrapperAddAccount {

        this.requestCreaProducto.addAccountRq.headerRequest.messageHeader.messageInfo.bankId = "";
        this.requestCreaProducto.addAccountRq.headerRequest.messageHeader.messageInfo.bankIdType = "";
        this.requestCreaProducto.addAccountRq.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_CREA_PRODUCTO_PHOENIX.BPM_AUTHOR;
        this.requestCreaProducto.addAccountRq.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_CREA_PRODUCTO_PHOENIX.ORIGINATOR_TYPE;
        this.requestCreaProducto.addAccountRq.headerRequest.messageHeader.messageInfo.systemId = REQUEST_CREA_PRODUCTO_PHOENIX.BPM_AUTHOR;
        this.requestCreaProducto.addAccountRq.headerRequest.messageHeader.messageInfo.terminalId = REQUEST_CREA_PRODUCTO_PHOENIX.TERMINAL_ID;
        this.requestCreaProducto.addAccountRq.headerRequest.messageHeader.messageInfo.terminalType = "";
        this.requestCreaProducto.addAccountRq.headerRequest.messageHeader.messageInfo.trnType = "";
        this.requestCreaProducto.addAccountRq.headerRequest.user.userName = REQUEST_CREA_PRODUCTO_PHOENIX.USER_NAME;
        this.requestCreaProducto.addAccountRq.acct.acctKey.acctType = data.codProducto;
        this.requestCreaProducto.addAccountRq.acct.acctKey.acctSubType = data.codSubProducto;
        this.requestCreaProducto.addAccountRq.acct.acctKey.branchIdent = solicitud.datosSolicitud.radicador.codOficina;
        this.requestCreaProducto.addAccountRq.acct.partyAcctRelInfo.personData.issuedIdent.issuedIdentType = solicitud.datosSolicitud.personaNatural[0].datosBasicos.codTipoIdentificacion;
        this.requestCreaProducto.addAccountRq.acct.partyAcctRelInfo.personData.issuedIdent.issuedIdentValue = solicitud.datosSolicitud.personaNatural[0].datosBasicos.numeroIdentificacion;
        this.requestCreaProducto.addAccountRq.acct.acctInfo.acctDebitInd = true;
        this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].debitCredit = REQUEST_CREA_PRODUCTO_PHOENIX.DEBITO;
        this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].xferInfo.fromAcctRef.acctIdent = "";
        this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].xferInfo.fromAcctRef.acctType = "";

        if (!!formAhorroProgramado) {
            if (!!formAhorroProgramado.get("objetivoAhorroProgramado").value) {
                this.requestCreaProducto.addAccountRq.acct.acctInfo.desc = formAhorroProgramado.get("objetivoAhorroProgramado").value;
            }
            if (!!formAhorroProgramado.get("cuentaOrigen").value && formAhorroProgramado.get("cuentaOrigen").value !== "NA") {
                this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].xferInfo.fromAcctRef.acctIdent = formAhorroProgramado.get("cuentaOrigen").value;
                this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].xferInfo.fromAcctRef.acctType = "AHO"; // temporalmente mientras vengan productos de otro tipo
            }
            if (!!formAhorroProgramado.get("montoAhorroPeriodico").value) {
                this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].xferInfo.curAmt = new CurrencyAmountType();
                this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].xferInfo.curAmt.amt = formAhorroProgramado.get("montoAhorroPeriodico").value;
                this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].xferInfo.curAmt.curCode = "COP"; // temporalmente mientras vengan otro tipo de monedas
            }
            if (!!formAhorroProgramado.get("diaDebito").value) {
                this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].recurModel = new RecurModelType();
                this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].recurModel.recurRule = new RecurRuleType();
                this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].recurModel.recurRule.recurType = "Meses";
                this.requestCreaProducto.addAccountRq.listRecurXferInfo.recurXferInfo[0].recurModel.recurRule.recurStartDate = formAhorroProgramado.get("diaDebito").value;
            }
        }

        // infoAdicionalEventos
        this.informacionProducto = {};
        this.informacionProducto[KEYS_INFORMACION_ADICIONAL_EVENTOS.DESCRIPCION_PRODUCTO] = data.desProducto + " " + data.desSubProducto;

        this.actividadEconomina = {};
        this.actividadEconomina[KEYS_INFORMACION_ADICIONAL_EVENTOS.CODIGO_CONVENIO] = solicitud.datosSolicitud.personaNatural[0].actividadEconomica.codConvenio;

        this.radicador = {};
        this.radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.USUARIO] = solicitud.datosSolicitud.radicador.usuarioRadicador;
        this.radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.NOMBRE] = solicitud.datosSolicitud.radicador.nombreRadicador;
        this.radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_IDENTIFICACION] = solicitud.datosSolicitud.radicador.numeroIdentificacion;
        this.radicador[KEYS_INFORMACION_ADICIONAL_EVENTOS.CODIGO_OFICINA] = solicitud.datosSolicitud.radicador.codOficina;

        this.vendedor = {};
        this.vendedor[KEYS_INFORMACION_ADICIONAL_EVENTOS.NOMBRE] = solicitud.datosSolicitud.vendedor.nombreVendedor;
        this.vendedor[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_IDENTIFICACION] = solicitud.datosSolicitud.vendedor.numeroIdentificacion;
        this.vendedor[KEYS_INFORMACION_ADICIONAL_EVENTOS.CODIGO_OFICINA] = solicitud.datosSolicitud.vendedor.codOficina;

        this.requestCreaProducto.infoAdicionalEventos = {};
        this.requestCreaProducto.infoAdicionalEventos[KEYS_INFORMACION_ADICIONAL_EVENTOS.NUMERO_SOLICITUD] = solicitud.datosSolicitud.numeroSolicitud;
        this.requestCreaProducto.infoAdicionalEventos[KEYS_INFORMACION_ADICIONAL_EVENTOS.INFORMACION_PRODUCTO] = this.informacionProducto;
        this.requestCreaProducto.infoAdicionalEventos[KEYS_INFORMACION_ADICIONAL_EVENTOS.ACTIVIDAD_ECONOMICA] = this.actividadEconomina;
        this.requestCreaProducto.infoAdicionalEventos[KEYS_INFORMACION_ADICIONAL_EVENTOS.RADICADOR] = this.radicador;
        this.requestCreaProducto.infoAdicionalEventos[KEYS_INFORMACION_ADICIONAL_EVENTOS.VENDEDOR] = this.vendedor;

        return this.requestCreaProducto;
    }

}
