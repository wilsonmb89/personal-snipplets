import { FormGroup } from '@angular/forms';

export class TransformationHelper {
  setCIIU(valor: string, formLinkForm: FormGroup, visibilidadCIIU: boolean, isIndependetCapital: boolean, requiredSectionEmpresa: boolean) {

    formLinkForm.get('nameEmp').setValue('');
    formLinkForm.get('addEmp').setValue('');
    formLinkForm.get('locate').setValue('');
    formLinkForm.get('phoneEmp').setValue('');
    formLinkForm.get('nomina').setValue('');

    formLinkForm.get('nameEmp').markAsUntouched();
    formLinkForm.get('addEmp').markAsUntouched();
    formLinkForm.get('locate').markAsUntouched();
    formLinkForm.get('phoneEmp').markAsUntouched();
    formLinkForm.get('nomina').markAsUntouched();

    formLinkForm.get('ciiu_control').markAsUntouched();


    if (valor === "40" || valor === "39") {
      formLinkForm.get("ciiu_control").setValue("082 - Personas Naturales Subsidiadas Por Terceros - 0 - Persona Natural");
      visibilidadCIIU = true;
      isIndependetCapital = false;
      requiredSectionEmpresa = false;
      return [visibilidadCIIU, requiredSectionEmpresa, isIndependetCapital];
    } else if (valor === "36") {
      formLinkForm.get("ciiu_control").setValue("010 - Asalariados: Personas Naturales Y Sucesiones Ilíqu - 0 - Persona Natural");
      visibilidadCIIU = true;
      isIndependetCapital = false;
      requiredSectionEmpresa = true;
      return [visibilidadCIIU, requiredSectionEmpresa, isIndependetCapital];
    } else if (valor === "41") {
      formLinkForm.get("ciiu_control").setValue("010 - Asalariados: Personas Naturales Y Sucesiones Ilíqu - 0 - Persona Natural");
      visibilidadCIIU = true;
      isIndependetCapital = false;
      requiredSectionEmpresa = false;
      return [visibilidadCIIU, requiredSectionEmpresa, isIndependetCapital];

    } else if (valor === "37") {
      formLinkForm.get("ciiu_control").setValue("");
      visibilidadCIIU = false;
      requiredSectionEmpresa = true;
      isIndependetCapital = false;
      return [visibilidadCIIU, requiredSectionEmpresa, isIndependetCapital];
    }
  }

  homologationCards (value) {
    switch (value) {
      case "Personal Bank":
        return "PBDM";
      case "Itaú sucursales":
        return "ISDM";
    }
  }
}
