export class Validation {
  trueToYes(value) {
    if (value) {
      return "S";
    } else {
      return "N";
    }
  }

  trueToYesValue(value) {
    if (value === "NO" || value === "No") {
      return "N";
    } else if (value === "SI" || value === "Si") {
      return "S";
    }
  }
}
