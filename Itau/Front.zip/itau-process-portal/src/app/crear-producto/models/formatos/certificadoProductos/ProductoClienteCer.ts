export class ProductoClienteCer {
    nombre: string;
    numero: string;
    fechaApertura: string;

    constructor(p_nombre: string, p_numero: string, p_fechaApertura: string) {
        this.nombre = p_nombre;
        this.numero = p_numero;
        this.fechaApertura = p_fechaApertura;
    }
}
