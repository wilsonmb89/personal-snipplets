import { ProductoClienteCer } from "./ProductoClienteCer";

export class DataCerProducto {
    aQuienInterese: string;
    personaReferencia: string;
    tipoIdentificacion: string;
    numeroIdentificacion: string;
    prodsClienteList: Array<ProductoClienteCer>;
}
