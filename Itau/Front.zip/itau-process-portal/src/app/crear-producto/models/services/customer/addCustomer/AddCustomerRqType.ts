import { HeaderRequestType } from '../commons/HeaderRequestType';
import { PartyType } from '../commons/PartyType';

export class AddCustomerRqType {
    headerRequest: HeaderRequestType;
    party: PartyType;
    opnInd: boolean;
}
