import { CountryType } from './CountryType';

export class PostAddrType {
    addr1: string;
    addrDesc: string;
    addrType: string;
    city: string;
    cityCode: string;
    stateProv: string;
    stateProvCode: string;
    country: CountryType;
}
