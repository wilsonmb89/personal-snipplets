import { XferInfoType } from "./XferInfoType";
import { RecurModelType } from "./RecurModelType";

export class RecurXferInfoType {
    xferInfo: XferInfoType;
    recurModel: RecurModelType;
    debitCredit: String;
}
