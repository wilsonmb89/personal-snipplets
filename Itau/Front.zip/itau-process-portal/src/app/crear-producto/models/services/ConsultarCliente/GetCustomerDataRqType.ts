import { HeaderRequest } from './HeaderRequest';
import { IssuedIdent } from './IssuedIdent';

export class GetCustomerDataRqType {
    headerRequest: HeaderRequest;
    issuedIdent: IssuedIdent;
}
