import { MessageHeader } from './MessageHeader';


export class HeaderRequest {
    messageHeader: MessageHeader;

    toString() {
        return "[messageHeader: " + this.messageHeader.toString() + "]";
    }
}
