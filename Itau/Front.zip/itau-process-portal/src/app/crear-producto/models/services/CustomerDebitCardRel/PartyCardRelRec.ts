import { ProductCard } from './ProductCard';

export class PartyCardRelRec {
    issuedIdentType: string;
    issuedIdentValue: string;
    cardCategory: string;
    productCard: ProductCard;
}
