export class CustId {
    custPermId: string;
    custType: string;
}
