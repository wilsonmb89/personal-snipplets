import { PersonDataType } from "./PersonDataType";

export class PartyAcctRelInfoType {
    personData: PersonDataType;
}
