import { GetCustomerDataRqType } from './GetCustomerDataRqType';
import { GetCustomerAdditionalDataRqType } from './GetCustomerAdditionalDataRqType';

export class RequestWrapperConsultaCliente {
    getCustomerAdditionalDataRqType: GetCustomerAdditionalDataRqType;
    getCustomerDataRqType: GetCustomerDataRqType;
}
