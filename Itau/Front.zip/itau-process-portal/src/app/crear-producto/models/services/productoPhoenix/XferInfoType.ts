import { AcctKeyType } from "./AcctKeyType";
import { CurrencyAmountType } from "./CurrencyAmountType";

export class XferInfoType {
    fromAcctRef: AcctKeyType;
    curAmt: CurrencyAmountType;
}
