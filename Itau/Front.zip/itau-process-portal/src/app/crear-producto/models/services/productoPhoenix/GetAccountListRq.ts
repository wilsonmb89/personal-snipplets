import { HeaderRequestType } from "./HeaderRequestType";
import { IssuedIdentType } from './IssuedIdentType';

export class GetAccountListRq {

    headerRequest: HeaderRequestType;
    acctListSel: IssuedIdentType;

}
