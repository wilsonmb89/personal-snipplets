export class EmailType {
    emailAddr: string;
}
