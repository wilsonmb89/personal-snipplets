import { MessageInfo } from './MessageInfo';
import { MessageKey } from './MessageKey';

export class MessageHeader {
    messageInfo: MessageInfo;
    messageKey: MessageKey;

    toString() {
        return "[messageInfo: " + this.messageInfo.toString() + " - messageKey: " + this.messageKey.toString() + "]";
    }
}
