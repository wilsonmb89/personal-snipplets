export class IssuedIdent {
    issuedIdentType: string;
    issuedIdentValue: string;
}
