import { HeaderRequest } from "../consultaListas/HeaderRequest";
import { CustId } from "../consultaListas/CustId";
export class ConsultaListasRestrictivas {

    headerRequest: HeaderRequest;
    custId: CustId;
    comment: string;
    applicationCode: string;

    toString() {
        return "[headerRequest: " + this.headerRequest.toString()
        + " - custId: " + this.custId.toString()
        + " - comment: " + this.comment
        + " - applicationCode: " + this.applicationCode + "]";
    }
}
