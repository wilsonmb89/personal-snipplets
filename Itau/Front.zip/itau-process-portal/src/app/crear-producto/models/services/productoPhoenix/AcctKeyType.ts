export class AcctKeyType {
    acctIdent: string;
    acctSubType: string;
    acctType: string;
    branchIdent: string;
}
