import { EmploymentType } from './EmploymentType';
import { IndustIdentType } from './IndustIdentType';
import { PersonDataType } from './PersonDataType';

export class PersonPartyInfoType {
    serviceLevelCode: string;
    birthDt: string;
    birthPlace: string;
    birthStateProv: string;
    campaignIdent: string;
    educationLevel: string;
    electronicStmtInd: string;
    employment: EmploymentType;
    feePlan: string;
    gender: string;
    industIdent: IndustIdentType;
    nationality: string;
    originatingBranch: string;
    originationInfo: string;
    personData: PersonDataType;
    sic: string;
}
