export class MessageKey {
    integrationId: string;
    requestVersion: string;

    toString() {
        return "[integrationId: " + this.integrationId + " - requestVersion: " + this.requestVersion + "]";
    }
}
