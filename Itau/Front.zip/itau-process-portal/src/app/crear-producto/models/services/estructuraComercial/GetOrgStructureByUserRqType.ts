import { HeaderRequestType } from "./HeaderRequestType";

export class GetOrgStructureByUserRqType {
    headerRequest: HeaderRequestType;
    identSerialNum: string;
}
