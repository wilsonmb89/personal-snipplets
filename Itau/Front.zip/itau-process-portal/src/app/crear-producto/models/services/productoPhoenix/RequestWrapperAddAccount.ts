import { AddAccountRq } from './AddAccountRq';

export class RequestWrapperAddAccount {
    addAccountRq: AddAccountRq;
    infoAdicionalEventos: any;
}
