export class UserType {
    userName: string;
}
