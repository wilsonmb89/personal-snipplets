import { PartyAdditionalInfoType } from './PartyAdditionalInfoType';

export class PartyAdditionalInfoListType {
    partyAdditionalInfo: Array<PartyAdditionalInfoType>;
}
