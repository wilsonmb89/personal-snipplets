import { RecurXferInfoType } from "./RecurXferInfoType";

export class ListRecurXferInfoType {
    recurXferInfo: Array<RecurXferInfoType>;
}
