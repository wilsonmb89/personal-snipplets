export class PartyKeyType {
    partyType: string;
}
