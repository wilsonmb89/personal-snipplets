import { MessageHeader } from './MessageHeader';

export class HeaderRequest {
    messageHeader: MessageHeader;
}
