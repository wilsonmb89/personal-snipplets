import { MessageHeaderType } from "./MessageHeaderType";
import { UserType } from "./UserType";

export class HeaderRequestType {
    messageHeader: MessageHeaderType;
    user: UserType;
}
