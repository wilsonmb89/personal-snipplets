export class CustId {
    custPermId: string;
    custType: string;
    spname: string;

    toString() {
        return "[custPermId: " + this.custPermId
        + " - custType: " + this.custType
        + " - spname: " + this.spname + "]";
    }
}
