export class CountryType {
    countryCode: string;
    countryName: string;
}
