export class ProductCard {
    bin: string;
    segmentation: string;
    affinityGroup: string;
}
