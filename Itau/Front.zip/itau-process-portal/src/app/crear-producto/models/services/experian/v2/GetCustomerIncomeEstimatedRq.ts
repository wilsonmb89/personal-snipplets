import { HeaderRequest } from './HeaderRequest';
import { CustId } from './CustId';

export class GetCustomerIncomeEstimatedRq {
    headerRequest: HeaderRequest;
    custId: CustId;
    lastName: string;
}
