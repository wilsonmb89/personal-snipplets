import { Resultado } from "./Resultado";

export class ListaResultado {
    totalResultados: number;
    resultados: Array<Resultado>;
}
