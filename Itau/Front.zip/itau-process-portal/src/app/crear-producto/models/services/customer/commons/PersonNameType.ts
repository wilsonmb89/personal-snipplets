export class PersonNameType {
    fullName: string;
    givenName: string;
    maternalName: string;
    middleName: string;
    paternalName: string;
}
