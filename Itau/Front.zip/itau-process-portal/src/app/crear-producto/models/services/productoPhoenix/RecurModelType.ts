import { RecurRuleType } from "./RecurRuleType";

export class RecurModelType {
    recurRule: RecurRuleType;
}
