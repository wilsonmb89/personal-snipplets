export class RecurRuleType {
    recurType: string;
    recurStartDate: string;
}
