import { AddCustomerRqType } from './AddCustomerRqType';

export class RequestWrapperAddCustomer {
    addCustomerRqType: AddCustomerRqType;
    infoAdicionalEventos: any;
}
