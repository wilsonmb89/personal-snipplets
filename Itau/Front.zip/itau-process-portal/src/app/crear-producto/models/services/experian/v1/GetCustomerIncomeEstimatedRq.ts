import { CustId } from './CustId';
import { HeaderRequest } from './HeaderRequest';

export class GetCustomerIncomeEstimatedRq {
    custId: CustId;
    employmentType: string;
    headerRequest: HeaderRequest;
    lastName: string;

    toString() {
        return "[custId: " + this.custId.toString() + " - employmentType: " + this.employmentType + " - headerRequest: " + this.headerRequest.toString() + " - lastName: " + this.lastName + "]";
    }
}
