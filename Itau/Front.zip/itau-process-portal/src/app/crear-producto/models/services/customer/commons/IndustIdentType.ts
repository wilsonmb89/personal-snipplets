export class IndustIdentType {
    industNum: string;
}
