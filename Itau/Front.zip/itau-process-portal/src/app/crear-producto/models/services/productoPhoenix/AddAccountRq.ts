import { HeaderRequestType } from "./HeaderRequestType";
import { AcctType } from "./AcctType";
import { ListRecurXferInfoType } from "./ListRecurXferInfoType";

export class AddAccountRq {

    headerRequest: HeaderRequestType;
    acct: AcctType;
    listRecurXferInfo: ListRecurXferInfoType;

}
