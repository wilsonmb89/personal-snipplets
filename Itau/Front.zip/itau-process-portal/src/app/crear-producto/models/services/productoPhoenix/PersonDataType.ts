import { IssuedIdentType } from "./IssuedIdentType";

export class PersonDataType {
    issuedIdent: IssuedIdentType;
}
