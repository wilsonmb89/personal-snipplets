export class MessageInfoType {
    systemId: string;
    originatorName: string;
    originatorType: number;
    terminalId: string;
}
