import { ContactListType } from './ContactListType';
import { IssuedIdentType } from './IssuedIdentType';
import { PersonNameType } from './PersonNameType';

export class PersonDataType {
    contactList: ContactListType;
    issuedIdent: IssuedIdentType;
    personName: PersonNameType;
}
