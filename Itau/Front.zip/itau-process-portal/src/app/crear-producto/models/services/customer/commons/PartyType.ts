import { PartyKeyType } from './PartyKeyType';
import { PartyAdditionalInfoListType } from './PartyAdditionalInfoListType';
import { PersonPartyInfoType } from './PersonPartyInfoType';

export class PartyType {
    partyKey: PartyKeyType;
    partyAdditionalInfoList: PartyAdditionalInfoListType;
    personPartyInfo: PersonPartyInfoType;
}
