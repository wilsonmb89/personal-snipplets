import { AcctKeyType } from "./AcctKeyType";
import { PartyAcctRelInfoType } from "./PartyAcctRelInfoType";
import { AcctInfoType } from "./AcctInfoType";

export class AcctType {
    acctKey: AcctKeyType;
    partyAcctRelInfo: PartyAcctRelInfoType;
    acctInfo: AcctInfoType;
}
