export class PartyAdditionalInfoType {
    additionalInfoId: number;
    additionalInfoValue: string;
}
