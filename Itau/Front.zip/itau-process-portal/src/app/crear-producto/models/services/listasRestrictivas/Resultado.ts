export class Resultado {
    matchPercent: string;
    listName: string;
    matchedValue: string;
    detail: string;
}
