export class PhoneNumType {
    phone: string;
    phoneDesc: string;
    phoneType: string;
}
