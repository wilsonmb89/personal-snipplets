export class MessageInfo {
    bankId: string;
    bankIdType: string;
    originatorName: string;
    originatorType: number;
    systemId: string;
    terminalId: string;
    terminalType: string;
    trnType: string;

    toString() {
        return "[bankId: " + this.bankId
                + " - bankIdType: " + this.bankIdType
                + " - originatorName: " + this.originatorName
                + " - originatorType: " + this.originatorType
                + " - systemId: " + this.systemId
                + " - terminalId: " + this.terminalId
                + " - terminalType: " + this.terminalType
                + " - trnType: " + this.trnType + "]";
    }
}
