import { ContactType } from './ContactType';

export class ContactListType {
    contact: Array<ContactType>;
}
