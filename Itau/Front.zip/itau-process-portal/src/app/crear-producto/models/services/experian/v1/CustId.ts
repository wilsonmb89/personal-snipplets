export class CustId {
    custLoginId: string;
    custPermId: string;
    custType: string;
    spname: string;

    toString() {
        return "[custLoginId: " + this.custLoginId + " - custPermId: " + this.custPermId + " - custType: " + this.custType + " - spname: " + this.spname + "]";
    }
}
