export class MessageInfoType {
    systemId: string;
    originatorName: string;
    originatorType: number;
    terminalId: string;
    terminalType: string;
    bankIdType: string;
    bankId: string;
    trnType: string;
}
