import { GetAccountListRq } from './GetAccountListRq';

export class RequestWrapperGetAccountList {
    getAccountListRq: GetAccountListRq;
    infoAdicionalEventos: any;
}
