export class AcctKey {
    acctId: string;
    acctType: string;
    curCode: string;
    branchIdent: string;
}
