export class CurrencyAmountType {
    amt: number;
    curCode: string;
}
