export class MessageInfo {
    originatorName: string;
    originatorType: number;
    systemId: string;
    terminalId: string;
}
