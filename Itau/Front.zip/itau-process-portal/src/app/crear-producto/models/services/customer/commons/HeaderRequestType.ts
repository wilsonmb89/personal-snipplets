import { MessageHeaderType } from './MessageHeaderType';

export class HeaderRequestType {
    messageHeader: MessageHeaderType;
}
