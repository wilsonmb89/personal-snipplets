export class IssuedIdentType {
    issuedIdentType: string;
    issuedIdentValue: string;
}
