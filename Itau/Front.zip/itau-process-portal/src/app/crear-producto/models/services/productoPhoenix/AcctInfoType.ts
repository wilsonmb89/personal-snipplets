export class AcctInfoType {
    acctDebitInd: boolean;
    desc;
}
