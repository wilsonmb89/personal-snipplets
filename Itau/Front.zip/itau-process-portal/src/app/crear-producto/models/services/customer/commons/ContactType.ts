import { EmailType } from './EmailType';
import { PhoneNumType } from './PhoneNumType';
import { PostAddrType } from './PostAddrType';

export class ContactType {
    email: EmailType;
    phoneNum: PhoneNumType;
    postAddr: PostAddrType;
}
