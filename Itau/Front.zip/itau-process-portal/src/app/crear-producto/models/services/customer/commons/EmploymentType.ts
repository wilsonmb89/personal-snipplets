export class EmploymentType {
    occupation: string;
}
