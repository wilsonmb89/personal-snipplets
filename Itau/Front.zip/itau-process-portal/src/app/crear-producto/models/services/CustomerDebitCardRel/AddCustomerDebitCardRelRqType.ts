import { HeaderRequest } from './HeaderRequest';
import { PartyCardRelRec } from './PartyCardRelRec';
import { AcctKey } from './AcctKey';

export class AddCustomerDebitCardRelRqType {
    headerRequest: HeaderRequest;
    partyCardRelRec: PartyCardRelRec;
    acctKey: AcctKey;
}
