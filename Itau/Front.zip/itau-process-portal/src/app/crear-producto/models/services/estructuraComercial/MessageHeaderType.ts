import { MessageInfoType } from "./MessageInfoType";

export class MessageHeaderType {
    messageInfo: MessageInfoType;
}
