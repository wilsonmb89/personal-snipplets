export class MessageInfo {
    systemId: string;
    originatorName: string;
    originatorType: number;
    terminalId: string;
}
