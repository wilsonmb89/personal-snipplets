import { HeaderRequest } from './HeaderRequest';
import { IssuedIdent } from './IssuedIdent';

export class GetCustomerAdditionalDataRqType {
    headerRequest: HeaderRequest;
    issuedIdent: IssuedIdent;
}
