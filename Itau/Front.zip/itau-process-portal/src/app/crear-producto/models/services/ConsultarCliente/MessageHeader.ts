import { MessageInfo } from './MessageInfo';

export class MessageHeader {
    messageInfo: MessageInfo;
}
