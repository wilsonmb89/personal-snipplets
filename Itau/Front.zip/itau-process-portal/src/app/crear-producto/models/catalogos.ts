export interface CatalogosNameValuePair {
    nombre: string;
    valor: string;
    nombreDpto: string;
    valorPadre: string;
}
