export class OperacionesMonedaExtranjera {
    realizaOperacionesMonedaExtranjera: string;
    tipoOperacionImportaciones: string;
    tipoOperacionExportaciones: string;
    tipoOperacionInversiones: string;
    tipoOperacionCredito: string;
    tipoOperacionPagoServicios: string;
    tipoOperacionOtras: string;
    otroTipoOperacion: string;
    titularProductosMonedaExtranjera: string;
    tipoProducto: string;
    numeroProducto: number;
    monto: number;
    entidad: string;
    codMoneda: string;
    desMoneda: string;
    codPais: string;
    desPais: string;
    ciudad: string;
}
