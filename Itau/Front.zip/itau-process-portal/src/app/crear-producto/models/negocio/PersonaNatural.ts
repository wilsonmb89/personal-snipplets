import { DatosBasicos } from './DatosBasicos';
import { Ubicacion } from './Ubicacion';
import { ActividadEconomica } from './ActividadEconomica';
import { InformacionFinanciera } from './InformacionFinanciera';
import { OperacionesMonedaExtranjera } from './OperacionesMonedaExtranjera';
import { PublicamenteExpuesto } from './PublicamenteExpuesto';
import { ListaResultado } from '../services/listasRestrictivas/ListaResultado';
import { Producto } from './Producto';
import { Documentos } from './Documentos';

export class PersonaNatural {
    datosBasicos: DatosBasicos;
    ubicacion: Ubicacion;
    actividadEconomica: ActividadEconomica;
    informacionFinanciera: InformacionFinanciera;
    operacionesMonedaExtranjera: OperacionesMonedaExtranjera;
    publicamenteExpuesto: PublicamenteExpuesto;
    consultarListas: ListaResultado;
    producto: Array<Producto>;
    documentos: Documentos;
    estadoCliente: string;
}
