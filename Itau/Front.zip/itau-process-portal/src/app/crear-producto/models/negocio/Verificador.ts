export class Verificador {
    usuarioVerificador: string;
    nombreVerificador: string;
}
