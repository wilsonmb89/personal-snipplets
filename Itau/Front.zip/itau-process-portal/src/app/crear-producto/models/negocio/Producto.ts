export class Producto {
    codProducto: string;
    desProducto: string;
    codSubProducto: string;
    desSubProducto: string;
    numeroCuenta: string;
    datosAdicionales: any;
}
