export class Radicador {
    numeroIdentificacion: string;
    codTipoIdentificacion: string;
    desTipoIdentificacion: string;
    nombreRadicador: string;
    codOficina: string;
    desOficina: string;
    usuarioRadicador: string;
    desCiudadOficina: string;
}
