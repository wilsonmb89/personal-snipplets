export class PublicamenteExpuesto {
    pep: string;
    prp: string;
    mrp: string;
    comentarioPepPrpMrp: string;
    familiarPep: string;
    comentarioFamiliarPep: string;
}
