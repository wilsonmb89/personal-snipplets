export class Ubicacion {
    direccionResidencia: string;
    codCiudadResidencia: string;
    desCiudadResidencia: string;
    codDepartamentoResidencia: string;
    desDepartamentoResidencia: string;
    correoElectronico: string;
    numeroCelular: string;
    residenciaFiscalOtroPais: string;
    direccionOtroPais: string;
    codOtroPais: string;
    desOtroPais: string;
}
