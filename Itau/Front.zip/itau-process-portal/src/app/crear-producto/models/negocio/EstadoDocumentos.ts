export class EstadoDocumentos {
    soporteIngresos: string;
    codCausalIngresos: string;
    desCausalIngresos: string;
    formularioVenta: string;
    codCausalVenta: string;
    desCausalVenta: string;
    documentoId: string;
    codCausalId: string;
    desCausalId: string;
    soporteProcesoId: string;
    codCausalProId: string;
    desCausalProId: string;
    tarjetaFirmas: string;
    codCausalTarjFirma: string;
    desCausalTarjFirma: string;
    comentarios: string;
}
