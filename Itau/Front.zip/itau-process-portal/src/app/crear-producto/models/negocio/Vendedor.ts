export class Vendedor {
    numeroIdentificacion: string;
    codTipoIdentificacion: string;
    desTipoIdentificacion: string;
    nombreVendedor: string;
    codOficina: string;
    desOficina: string;
    desCiudadOficina: string;
}
