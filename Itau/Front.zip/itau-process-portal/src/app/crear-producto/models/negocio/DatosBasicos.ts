export class DatosBasicos {
    numeroIdentificacion: string;
    codTipoIdentificacion: string;
    desTipoIdentificacion: string;
    nombre: string;
    primerApellido: string;
    segundoApellido: string;
    codCiudadNacimiento: string;
    desCiudadNacimiento: string;
    codDepartamentoNacimiento: string;
    desDepartamentoNacimiento: string;
    fechaNacimiento: string;
    codGenero: string;
    desGenero: string;
    rymPhoenix: number;
}
