import { Resultado } from "../services/listasRestrictivas/Resultado";

export class ConsultarListas {
    totalResultados: number;
    resultados: Resultado;
}
