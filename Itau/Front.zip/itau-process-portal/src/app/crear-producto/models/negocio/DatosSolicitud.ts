import { Radicador } from "./Radicador";
import { PersonaNatural } from "./PersonaNatural";
import { Vendedor } from './Vendedor';
import { Verificador } from './Verificador';

export class DatosSolicitud {
    fechaRadicacion: string;
    numeroSolicitud: string;
    vendedor: Vendedor;
    radicador: Radicador;
    verificador: Verificador;
    personaNatural: Array<PersonaNatural>;
    causalCumplimiento: string;
}
