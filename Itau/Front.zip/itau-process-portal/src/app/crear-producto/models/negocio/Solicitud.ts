
import { DatosSolicitud } from './DatosSolicitud';

export class Solicitud {
    numeroSolicitud: string;
    datosSolicitud: DatosSolicitud;
}
