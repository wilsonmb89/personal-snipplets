export class InformacionFinanciera {
    ingresoPrincipalCore: number;
    origenIngresoTercerasFuentes: string;
    ingresoEstimado: number;
    ingresoValidado: number;
    otrosIngresos: number;
    codConceptoOtrosIngresos: string;
    desConceptoOtrosIngresos: string;
    totalIngresos: number;
    egresosMensuales: number;
    totalActivos: number;
    totalPasivos: number;
    patrimonio: number;
    desOtroConcepto: string;
    soporteIngresos: boolean;
}
