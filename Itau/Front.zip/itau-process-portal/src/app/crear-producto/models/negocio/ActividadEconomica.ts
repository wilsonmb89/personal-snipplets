
export class ActividadEconomica {
    codOcupacion: string;
    desOcupacion: string;
    codCIIU: string;
    desCIIU: string;
    nombreEmpresa: string;
    direccionEmpresa: string;
    codCiudadEmpresa: string;
    desCiudadEmpresa: string;
    codDepartamentoEmpresa: string;
    desDepartamentoEmpresa: string;
    telefonoOficina: string;
    codConvenio: string;
    desConvenio: string;
    codSecEconomico: string;
    desSecEconomico: string;
}
