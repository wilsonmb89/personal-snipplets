import { EstadoDocumentos } from "./EstadoDocumentos";

export class Documentos {
    estadoDocumentos: EstadoDocumentos;
    comentarioRechazado: string;
}
