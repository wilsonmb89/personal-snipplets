export class DatosCuenta {
    codeAccount: string;
    accountType: string;
    accounSubtType: string;
    accountCodeSubType: string;
    accountNumber: string;
    nombreTarjeta: string;
    numeroTarjeta: string;
}
