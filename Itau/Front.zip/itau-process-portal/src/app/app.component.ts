import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  isSticky = false;

  constructor(private router: Router) { }

  public global = {

    showHeader: false,
    nombre: '',
    id: '',
    showId: false,
    profileImage: '',
    scrollHide: false

  };
  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    if (this.global.scrollHide) {
      this.isSticky = window.pageYOffset >= 20;
    } else {
      this.isSticky = false;
    }
  }

  ngOnInit() { }
}
