import { Injectable } from '@angular/core';
import { HttpClientService } from '../../shared/services/HttpClient.service';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { PATH_API } from '../../shared/constants/servicePath.constant';

@Injectable()
export class GetPublicKeyService {

  constructor(
    public _httpClientService: HttpClientService,
    public http: Http,
    public _httpClient: HttpClient
  ) {}

  getKey() {
    const options = {
      responseType: "text"
    };
    return this._httpClientService.invokeGetRequest(PATH_API.GETKEY, options);
  }

}
