import { Injectable } from "@angular/core";
import { HttpClientService } from '../../shared/services/HttpClient.service';
import { PATH_API } from "../../shared/constants/servicePath.constant";

@Injectable()
export class LoginService {

  constructor(public _httpClientService: HttpClientService) {}

  login(body) {
    return this._httpClientService.invokePostRequest(PATH_API.LOGIN, body);
  }
}
