// Navigation services
import { AuthGuardService as AuthGuard } from '../shared/services/auth-guard.service';

// Modules
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { HttpModule } from '@angular/http';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../material/material.module';

// Components
import { LoginComponent } from './components/login/login.component';
import { InboxComponent } from './components/inbox/inbox.component';
import { SearchContainerComponent } from '../shared/components/search-container/search-container.component';

// Services
import { PaginationService } from '../shared/services/pagination.service';
import { LoginService } from './services/login.service';
import { GetPublicKeyService } from './services/get-public-key.service';

// Pipes
import { InfoUserInboxPipe } from './pipes/info-user-inbox.pipe';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'bandeja-tareas', component: InboxComponent, canActivate: [AuthGuard] },
];

@NgModule({
  declarations: [LoginComponent, InboxComponent, SearchContainerComponent, InfoUserInboxPipe],
  imports: [
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    SharedModule,
    HttpModule,
    CommonModule
  ],
  providers: [
    LoginService,
    GetPublicKeyService,
    PaginationService
  ]
})
export class PortalModule { }
