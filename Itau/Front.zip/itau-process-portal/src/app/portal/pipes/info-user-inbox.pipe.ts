import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "infoUserInbox"
})
export class InfoUserInboxPipe implements PipeTransform {

  result: any;

  transform(text: any, idx): string {
    if (!!text) {
      this.result = text.split("-");
      if (this.result[1] !== " ") {
        this.result[1] = this.result[1].concat(' - ');
      }
      this.result = this.result[idx];
      return this.result;
    } else {
      return "";
    }
  }
}
