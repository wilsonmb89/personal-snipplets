import { InfoUserInboxPipe } from './info-user-inbox.pipe';

describe('InfoUserInboxPipe', () => {
  it('create an instance', () => {
    const pipe = new InfoUserInboxPipe();
    expect(pipe).toBeTruthy();
  });
});
