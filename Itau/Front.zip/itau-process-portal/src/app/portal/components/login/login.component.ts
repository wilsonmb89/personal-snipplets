import { FormControl, FormGroup, Validators } from "@angular/forms";
import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { LoginService } from "../../services/login.service";
import { AppComponent } from "../../../app.component";
import { GetPublicKeyService } from "../../services/get-public-key.service";
import { Encryption } from '../../../shared/functions/encryption';
import { TimerClass } from "../../../shared/functions/timer";
import { AMBIENTE } from "../../../shared/constants/servicePath.constant";
import { IndexedDBService } from '../../../shared/services/indexedDB.service';
import { environment } from '../../../../environments/environment';
import { debug } from 'util';

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"]
})
export class LoginComponent implements OnInit {
  public loginForm: FormGroup;
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  infoMessage: String;
  visibility: boolean;
  modalIsShowed = false;
  ipAddress: any = {};
  activeSession = false;
  userInvalid = false;
  passwordIsFocus = false;
  public isLogin;
  public inboxButton;
  public isLoadingActive = false;
  public version: string;

  constructor(
    private router: Router,
    private _indexedDBService: IndexedDBService,
    private _loginService: LoginService,
    private _getPublicKey: GetPublicKeyService,
    private app: AppComponent,
    private _encryption: Encryption,
    private timer?: TimerClass
  ) {
    this.app.global.showHeader = false;
    this.app.global.showId = false;
    this.isLogin = true;
    this.inboxButton = true;
    window.scroll(0, 0);
    sessionStorage.removeItem("instanceId");
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("taskId");
    sessionStorage.removeItem("fullName");
    sessionStorage.removeItem("user");
    this.version = AMBIENTE.version;
  }

  async ngOnInit() {

    if (!environment.production) {
      this.version = AMBIENTE.version;
    }

    if (!!this.timer.getSuscription()) {
      this.timer.getSuscription().unsubscribe();
      this.timer.setSuscription(null);
    }

    this.loginForm = new FormGroup({
      username: new FormControl("", [
        Validators.required,
        Validators.maxLength(80)
      ]),
      password: new FormControl("", [
        Validators.required,
        Validators.maxLength(20),
        Validators.minLength(8)
      ])
    });

    const getAll = await this._indexedDBService.getAll();
    if (!!getAll && typeof (getAll) !== "string" && getAll.length > 0) {
      const sessionData = JSON.parse(getAll[0].bpmData);
      this.mapSessionData(sessionData).then(
        mapOk => {
          this.router.navigate(["/portal/bandeja-tareas"]);
        },
        mapNok => {
          console.error(mapNok);
          this.getPublicKey();
        }
      );
    } else {
      this.getPublicKey();
    }
  }

  OnDestroy() {
    this._getPublicKey.getKey();
  }

  async getPublicKey() {
    await this._getPublicKey.getKey().then(
      response => {
        this._encryption.storePublickKey(response);
        this._encryption.generateKeys();
      },
      err => {
        console.log("ERROR AL OBTENER LA LLAVE PÚBLICA");
        console.error(err);
      }
    );
  }

  onSubmit(): void {
    this.isLoadingActive = true;
    const body = {
      user: this.loginForm.get("username").value,
      password: this.loginForm.get("password").value
    };
    this._loginService.login(body).then(
      (repos: any) => {
        const body = repos.body;
        const fullname = body.fullName;
        const user = body.userName;
        const token = body.token;
        sessionStorage.setItem("token", token);
        sessionStorage.setItem("user", user);
        sessionStorage.setItem("fullname", fullname);
        sessionStorage.setItem("loginRed", this.loginForm.get("username").value);
        this._indexedDBService.addData(JSON.stringify(sessionStorage));
        this.router.navigate(["/portal/bandeja-tareas"]);
        this.isLoadingActive = false;
      }, (err: any) => {
        console.log(err);
        this.userInvalid = true;
        this.isLoadingActive = false;
      }
    );
  }

  get formIsInValid(): boolean {
    return this.loginForm.invalid;
  }

  clearUserInvalid() {
    this.userInvalid = false;
  }

  showPass() {
    if (
      document.getElementById("password").getAttribute("type") === "password"
    ) {
      document.getElementById("password").setAttribute("type", "text");
    } else {
      document.getElementById("password").setAttribute("type", "password");
    }
    this.visibility = !this.visibility;
  }

  mapSessionData(sessionData): Promise<any> {
    return new Promise((resolve, reject) => {
      if (!!sessionData
        && !!sessionData.token
        && !!sessionData.user
        && !!sessionData.fullname
        && !!sessionData.loginRed
        && !!sessionData.privateKey
        && !!sessionData.frontKey
        && !!sessionData.publicKeyBack) {
        sessionStorage.setItem("token", sessionData.token);
        sessionStorage.setItem("user", sessionData.user);
        sessionStorage.setItem("fullname", sessionData.fullname);
        sessionStorage.setItem("loginRed", sessionData.loginRed);
        sessionStorage.setItem("privateKey", sessionData.privateKey);
        sessionStorage.setItem("frontKey", sessionData.frontKey);
        sessionStorage.setItem("publicKeyBack", sessionData.publicKeyBack);
        resolve();
      } else {
        reject("No datos suficientes para continuar con la sesion");
      }
    });
  }

}
