import { Router } from "@angular/router";
import { Component, OnInit, HostListener } from "@angular/core";
import { BpmService } from "../../../shared/services/bpm.service";
import { Task } from "../../../shared/models/bpm/Task";
import { AppComponent } from "../../../app.component";
import { BpmUtils } from "../../../shared/functions/util/bpm.util";
import { TimerClass } from "../../../shared/functions/timer";
import { PaginationService } from '../../../shared/services/pagination.service';
import { Transformation } from '../../../shared/functions/util/Trasnformation';
import { environment } from '../../../../environments/environment';

@Component({
  selector: "app-inbox",
  templateUrl: "./inbox.component.html",
  styleUrls: ["./inbox.component.scss"]
})
export class InboxComponent implements OnInit {
  fullname: string;
  name: string;
  user: string;
  taskItemsShow: any = 5;
  tasksList: Task[] = [];
  showMoreItemsToMe = false;
  showMoreClientsToMe = false;
  tasksListOrigin: Task[] = [];
  tasksListOriginRes: Task[] = [];
  taskListDuplicate: Array<any> = [];
  listedProcess: Array<string> = [];
  listedServices: Array<string> = [];
  processDirectory: Array<any> = [];
  private bpmUtil: BpmUtils;
  showButtonProcess;
  isLogin;

  public taskId: string;
  public instanceId: string;
  public isLoadingActive = false;
  collapseContainer = true;
  // pager object
  pager: any = {};
  pagedItemsInitial: any[];
  newest = true;
  pageSelected = 1;

  constructor(
    private bpmService: BpmService,
    private router: Router,
    private app: AppComponent,
    private timer: TimerClass,
    private _pagination: PaginationService,
    private transformation: Transformation
  ) {
    window.scroll(0, 0);
    this.fullname = sessionStorage.getItem("fullname");
    this.user = sessionStorage.getItem("user");
    this.app.global.nombre = this.fullname;
    this.app.global.showHeader = true;
    this.app.global.scrollHide = false;
    this.app.global.showId = !!sessionStorage.getItem("instanceId");
    this.isLogin = true;
    this.bpmUtil = new BpmUtils();
  }

  async ngOnInit() {
    window.scroll(0, 0);
    this.getAllProcess();
    this.consultOriginatorProcess();
  }

  async consultProcess() {
    this.bpmService.getActiveTasks().then(response => {
      const res = response.body.data.items;
      this.tasksList = res;
      this.refreshList(res);
      this.showMoreItemsToMe = true;
      this.showMoreClientsToMe = true;
    });
  }

  async consultOriginatorProcess() {
    console.log("consultOriginatorProcess");
    this.bpmService.getOwnerTask().then(response => {
      const res = response.body.data.processDetails;
      for (let index = 0; index < res.length; index++) {
        this.tasksListOrigin.push(res[index].tasks);
      }

      for (let index = 0; index < this.tasksListOrigin.length; index++) {
        const taskList = <any> this.tasksListOrigin[index];

        for (let index = 0; index < taskList.length; index++) {
          if (!!taskList[index]) {
            const task = taskList[index];
            if ((!!task.owner && task.owner !== this.user && task.status !== "Closed") || (!(!!task.owner))) {
              this.taskListDuplicate.push(task);
            }
          }
        }
      }
      this.tasksListOriginRes = this.removeDuplicates(
        this.taskListDuplicate,
        "activationTime"
      );
      this.tasksListOriginRes = this.transformation.orderActiveTaskByDate(this.tasksListOriginRes);
      this.setPageInitial(this.pageSelected);
      console.log("respuesta tasksListOrigin:", this.tasksListOriginRes);
    });
  }

  refreshList(listResponse: Task[]) {
    if (!(JSON.stringify(this.tasksList) === JSON.stringify(listResponse))) {
      listResponse.forEach(task => {
        this.addToList(task);
      });
    }
  }

  addToList(task: Task) {
    if (
      !(this.tasksList.filter(task => task.TKIID === task.TKIID).length > 0)
    ) {
      this.tasksList.push(task);
    }
  }

  showMoreToMe() {
    if (this.taskItemsShow < this.tasksList.length) {
      this.taskItemsShow += 5;
    } else {
      this.showMoreItemsToMe = false;
    }
  }

  showMoreClients() {
    if (this.taskItemsShow < this.tasksListOriginRes.length) {
      this.taskItemsShow += 5;
    } else {
      this.showMoreClientsToMe = false;
    }
  }

  createProcess(processAcromyn) {
    this.isLoadingActive = true;
    const processObj = this.bpmUtil.getObjectByCollection(
      this.processDirectory,
      processAcromyn
    );
    if (!!processObj) {
      this.bpmService.createProcessByObj(processObj).then(
        result => {
          console.log(result);
          const body = result;
          // body = this._encryption.desencrypt(body);
          this.taskId = body.data.tasks[0].tkiid;
          this.instanceId = body.data.piid;
          sessionStorage.setItem("instanceId", this.instanceId);
          this.consultProcess();
        },
        err => {
          console.log(err);
          this.isLoadingActive = false;
        }
      );
    }
  }

  removeDuplicates(originalArray, prop) {
    const newArray = [];
    const lookupObject = {};
    const A = true;

    for (const i in originalArray) {
      if (A) {
        lookupObject[originalArray[i][prop]] = originalArray[i];
      }
    }

    for (const i in lookupObject) {
      if (A) {
        newArray.push(lookupObject[i]);
      }
    }
    return newArray;
  }

  async getAllProcess() {
    this.bpmService.getAllExposed().then(
      response => {
        let resp = (!!response && !!response.body && !!response.body.data && !!response.body.data[0] && !!response.body.data[0].exposedItemsList) ? response.body.data[0].exposedItemsList : [];
        resp = resp.concat((!!response && !!response.body && !!response.body.data && !!response.body.data[1] && !!response.body.data && !!response.body.data[1].exposedItemsList) ? response.body.data[1].exposedItemsList : []);
        for (let x = 0; x < resp.length; x++) {
          if (!resp[x].tip) {
            switch (resp[x].type) {
              case 'process':
                this.processDirectory.push(resp[x]);
                this.listedProcess.push(resp[x].processAppAcronym);
                break;
              case 'service':
                this.listedServices.push(resp[x].display);
                break;
              default:
                break;
            }
          }
        }
      },
      err => {
        console.error("ERROR");
        console.error(err);
      }
    );
  }

  createAutoAssignProcess(processAcromyn) {
    this.isLoadingActive = true;
    let hasInternalError = true;
    const processObj = this.bpmUtil.getObjectByCollection(
      this.processDirectory,
      processAcromyn
    );
    if (!!processObj) {
      this.bpmService.createProcessByObj(processObj).then(
        result => {
          console.log(result);
          const body = result.body;
          console.log(body.data);
          // const body = this._encryption.desencrypt((<any>result)._body);
          let isCreateNOK = true;
          if (!!body.data && !!body.data.tasks && body.data.tasks.length > 0) {
            const taskReceived = this.bpmUtil.getTaskReceived(body.data.tasks);
            if (
              !!taskReceived &&
              !!sessionStorage.getItem("user") &&
              taskReceived.owner.toUpperCase() ===
                sessionStorage.getItem("user").toUpperCase()
            ) {
              isCreateNOK = false;
              sessionStorage.setItem("taskId", taskReceived.tkiid);
              sessionStorage.setItem("instanceId", taskReceived.piid);
              const datosFlujo = body.data.variables.datosFlujo;
              if (!!datosFlujo) {
                delete datosFlujo["@metadata"];
                sessionStorage.setItem(
                  "datosFlujo",
                  JSON.stringify(datosFlujo)
                );
              }
              if (!!this.timer && !!this.timer.getSuscription()) {
                this.timer.getSuscription().unsubscribe();
              }
              hasInternalError = false;
              this.routePage(taskReceived.displayName);
            }
          }
          if (isCreateNOK) {
            this.setInitialProcessData(body);
          }
          if (hasInternalError) {
            this.isLoadingActive = false;
          }
        },
        err => {
          console.error(err);
          this.isLoadingActive = false;
        }
      );
    }
  }

  setInitialProcessData(body) {
    this.taskId = body.data.tasks[0].tkiid;
    this.instanceId = body.data.piid;
    sessionStorage.setItem("instanceId", this.instanceId);
    this.consultProcess();
  }

  routePage(appName: string) {
    switch (appName) {
      case "Asignar Venta":
        this.router.navigate(["crearProductos/asignar-venta"]);
        break;
      default:
        break;
    }
  }

  /* Metodo para expandir y colapsar el contenedor de mis clientes */
  changeContainer() {
    if (this.collapseContainer) {
      this.collapseContainer = false;
    } else {
      this.collapseContainer = true;
    }
  }

  /* Metodo para la paginación de las tareas de mis clientes */
  setPageInitial(page: number, target?: boolean) {
    // get pager object from service
    this.pager = this._pagination.getPager(this.tasksListOriginRes.length, page);
    this.pageSelected = page;

    // get current page of items
    this.pagedItemsInitial = this.tasksListOriginRes.slice(
      this.pager.startIndex,
      this.pager.endIndex + 1
    );
    if (target) {
      document.getElementById('clientes').scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }

  /* Ordena la lista de tareas de mis clientes */
  orderList() {
    this.tasksListOriginRes.reverse();
      this.setPageInitial(this.pageSelected, true);
      if (this.newest) {
        this.newest = false;
      } else {
        this.newest = true;
      }
  }

  activeLoading(value) {
    this.isLoadingActive = value;
  }

   /* Redireccion que no deben generar instancias */
  redirectNoProcess(destination) {
    switch (destination) {
      case 'KIBANA':
        window.open(window.location.origin.concat(environment.KIBANA));
        break;
      case 'CONSULTA_PCC':
        this.router.navigate(["cliente360/consultar-cliente-pcc"]);
        break;
      case 'GESTION_CATALOGOS':
        this.router.navigate(["crearProductos/administrar-catalogos"]);
        break;
      default:
        break;
    }
  }
}
