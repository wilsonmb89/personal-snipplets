import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'itauCurrencyCust360'
})
export class ItauCurrencyCust360Pipe implements PipeTransform {

  transform(value: any, noParenthesis: any, valorDefecto: any): any {

    const defaultReturn = !!valorDefecto ? valorDefecto : "-";
    if (!!value) {
      let transform = value.toString().replace(/[.]/g, ",");
      transform = transform.replace(/[a-zA-Z.$'\s]/g, "");
      let decimalVal = "";
      if (transform.lastIndexOf(",") !== -1) {
        decimalVal = transform.substring(transform.lastIndexOf(","), transform.length);
        transform = transform.substring(0, transform.lastIndexOf(","));
      }
      if (!!transform && transform.length > 1) {
        transform = transform.toString().replace(/(\d)(?=(\d{3})+\b)/g, "$1.");
        transform = (transform.split(".").length  >= 3 ? transform.replace(".", "'") : transform);
        if (!!noParenthesis && noParenthesis) {
          return "$ " + transform + decimalVal;
        } else {
          return "($ " + transform + decimalVal + ")";
        }
      } else {
        return defaultReturn;
      }
    } else {
      return defaultReturn;
    }
  }

}
