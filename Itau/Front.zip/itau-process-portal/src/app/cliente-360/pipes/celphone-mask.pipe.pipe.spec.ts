import { CelphoneMaskPipe } from './celphone-mask.pipe';

describe('CelphoneMaskPipe', () => {
  it('create an instance', () => {
    const pipe = new CelphoneMaskPipe();
    expect(pipe).toBeTruthy();
  });
});
