import { ItauCurrencyCust360Pipe } from './itau-currency-cust-360.pipe';

describe('ItauCurrencyCust360Pipe', () => {
  it('create an instance', () => {
    const pipe = new ItauCurrencyCust360Pipe();
    expect(pipe).toBeTruthy();
  });
});
