import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'celphoneMask'
})
export class CelphoneMaskPipe implements PipeTransform {
    transform(value: any): any {
        if (!!value && value.length > 6) {
            const transform = value.split(/(\d{0,3})(\d{0,3})(\d{0,4})/);
            value = '(' + transform[1] + ') ' + transform[2] + ' ' + transform[3];

            return value;
        } else {
            return "";
        }
    }
}
