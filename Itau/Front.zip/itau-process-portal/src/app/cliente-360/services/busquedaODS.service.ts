import { Injectable } from '@angular/core';
import { HttpClientService } from '../../shared/services/HttpClient.service';
import { PATH_DB } from '../../shared/constants/servicePath.constant';

@Injectable()
export class ODSSearchService {

  constructor(
    public _httpClientService: HttpClientService
  ) {
  }

  searchCustomer(tipoIdentificacion: string, numeroIdentificacion: string) {
    if (!!tipoIdentificacion && !!numeroIdentificacion) {
      return this._httpClientService.invokeGetRequest(PATH_DB.ODS.concat(tipoIdentificacion).concat('/').concat(numeroIdentificacion));
    } else {
      return null;
    }
  }
}
