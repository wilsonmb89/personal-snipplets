import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { CatalogosServiceService } from "./../../../shared/services/catalogos-service.service";
import { Router } from "@angular/router";
import { BpmService } from "../../../shared/services/bpm.service";
import { AppComponent } from '../../../app.component';
import { DataInjectProvider } from '../../../shared/services/data';
import { ODSSearchService } from '../../services/busquedaODS.service';

@Component({
  selector: 'app-search-customer',
  templateUrl: './search-customer.component.html',
  styleUrls: ['./search-customer.component.scss']
})
export class SearchCustomerComponent implements OnInit {

  public fullname: string;
  public isLoadingActive = false;
  public isClienteNoEncontrado = false;
  public searchCustomerForm: FormGroup;
  public tipoDocCatalog: Array<any> = [];
  public codigosDocumento = ["1", "2", "3", "4", "5", "7", "11", "17", "24"]; // Codigos establecidos a mostrar en el menu de seleccion
  public rolesNegociacion = ["Negociador 360"];
  public dataModal: any;
  public isRolNegociacion = false;

  constructor(
    private _catalogoService: CatalogosServiceService,
    private _router: Router,
    private _bpmService: BpmService,
    private _app: AppComponent,
    private _odsSearchService: ODSSearchService,
    private _dataProvider: DataInjectProvider
  ) {
    this.fullname = sessionStorage.getItem("fullname");
    this._app.global.nombre = sessionStorage.getItem("fullname");
    this._app.global.showHeader = true;
    this._app.global.showId = false;
  }

  ngOnInit() {
    this.searchCustomerForm = new FormGroup({
      tipoIdentificacion: new FormControl("", [Validators.maxLength(30), Validators.required]),
      numeroIdentificacion: new FormControl("", [Validators.required, Validators.maxLength(30)]),
    });
    this.getTiposIdentificacion();
    this.validarRolNegociacion();
  }

  realizarConsultaCliente() {
    this.isLoadingActive = true;
    this.isClienteNoEncontrado = false;
    this._odsSearchService.searchCustomer(this.searchCustomerForm.get("tipoIdentificacion").value,
        this.searchCustomerForm.get("numeroIdentificacion").value).then(
      response => {
        if (!!response && !!response.body && !!response.body.cliente) {
          this._dataProvider.storage = response.body;
          this._dataProvider.storage.isRolNegociacion = this.isRolNegociacion;
          this._router.navigate(['cliente360/resultado-consulta-pcc']);
        } else {
          this.isClienteNoEncontrado = true;
        }
        this.isLoadingActive = false;
      },
      error => {
        console.error(error);
        this.isLoadingActive = false;
      }
    );
  }

  getTiposIdentificacion() {
    this.isLoadingActive = true;
    this._catalogoService.loadCatalog("TIPO_IDENTIFICACION").then(
      response => {
        console.log(response);
        if (!!response) {
          const list = response.body;
          const filteredList = [];
          for (let x = 0 ; x < list.length ; x++) {
            if (this.codigosDocumento.indexOf(list[x].llave) !== -1) {
              filteredList.push(list[x]);
            }
          }
          this.tipoDocCatalog = filteredList.map(catalog => {
            return {
              nombre: catalog.valor,
              valor: catalog.llave
            };
          });
        }
        this.isLoadingActive = false;
      },
      error => {
        console.error(error);
        this.isLoadingActive = false;
      }
    );
  }

  finalizarActividad() {
    this.isLoadingActive = true;
    this.resetSessionData();
  }

  resetIsClienteNoEncontrado() {
    this.isClienteNoEncontrado = false;
  }

  resetSessionData() {
    this._dataProvider.storage = null;
    sessionStorage.removeItem("taskId");
    sessionStorage.removeItem("instanceId");
    this._router.navigate(["portal/bandeja-tareas"]);
  }

  validarRolNegociacion() {
    this.isLoadingActive = true;
    const userName = !!sessionStorage.getItem("loginRed") ? sessionStorage.getItem("loginRed") : "";
    this._bpmService.getUserDetails(userName).then(
      result => {
        if (!!result.body && result.body.body && !!result.body.body.status && result.body.body.status === "200" && result.body.body.data && result.body.body.data.memberships) {
          const rolesUsuario = result.body.body.data.memberships;
          for (let x = 0; x < rolesUsuario.length; x++) {
            const rol = rolesUsuario[x];
            if (this.rolesNegociacion.indexOf(rol) !== -1) {
              this.isRolNegociacion = true;
              break;
            }
          }
        }
        this.isLoadingActive = false;
      },
      error => {
        console.error(error);
        this.isLoadingActive = false;
      }
    );
  }
}
