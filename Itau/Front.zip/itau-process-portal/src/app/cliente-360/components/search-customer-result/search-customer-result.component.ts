import { Component, OnInit} from '@angular/core';
import { DataInjectProvider } from '../../../shared/services/data';
import { AppComponent } from '../../../app.component';
import { Router } from "@angular/router";
import { DataCertificado } from '../../models/certificadoDeudaCliente/DataCertificado';
import { DataCertificadoPazSalvo } from '../../models/pazSalvoCliente/DataCertificadoPazSalvo';
import { ProductoCliente } from '../../models/certificadoDeudaCliente/ProductoCliente';
import { CreatePdfService } from '../../../shared/services/create-pdf.service';
import { DataWrapper } from '../../../shared/models/formatos/DataWrapper';
import { DataFichaNegociacion } from '../../models/fichaNegociacion/DataFichaNegociacion';
import { DatosDemograficos } from '../../models/fichaNegociacion/DatosDemograficos';
import { InformacionEconomica } from '../../models/fichaNegociacion/InformacionEconomica';
import { SimulacionCuota } from '../../models/fichaNegociacion/SimulacionCuota';
import { OperacionesActuales } from '../../models/fichaNegociacion/OperacionesActuales';
import { OperacionesMora } from '../../models/fichaNegociacion/OperacionesMora';
import { DetalleCuotasSinLiquidar } from '../../models/fichaNegociacion/DetalleCuotasSinLiquidar';
import { Transformation } from '../../../shared/functions/util/Trasnformation';
import { ProductoClientePazSalvo } from '../../models/pazSalvoCliente/ProductoClientePazSalvo';
import { EXTERNAL_PAGES } from '../../../shared/constants/servicePath.constant';

@Component({
  selector: 'app-search-customer-result',
  templateUrl: './search-customer-result.component.html',
  styleUrls: ['./search-customer-result.component.scss']
})
export class SearchCustomerResultComponent implements OnInit {

  public CONST_MODIFICADO_SI = "S";
  public CONST_REESTRUCTURADO_SI = "S";
  public CONST_CASTIGADO_SI = "S";
  public CONST_OBLIGACIONES = "OBLIGACIONES";
  public CONST_HISTORICO = "HISTORICO";
  public linkAdminfo = EXTERNAL_PAGES.URL_ADMINFO;
  public pantallaActual = this.CONST_OBLIGACIONES;
  public showModalConfirm = false;
  public showModalChip = false;
  public showModalChipInfo = false;
  public isLoadingActive = false;
  public tieneCoresFaltantes = false;
  public personaDirigida = "";
  public isNegociacionActive = false;
  public prodsNegociacion = [];
  public prodsPazSalvo = [];
  public isAllSelected = false;
  public isAllSelectedActTitular = false;
  public isAllSelectedActInterviniente = false;
  public dataCliente: any;
  public dataTransformation = new Transformation();
  public dataModal: any;
  public showPazSalvo = false;
  public oblTitularSeleccionadas = "";
  public oblIntervinienteSeleccionadas = "";
  public oblCanceladasSeleccionadas = "";

  constructor(
    private _dataProvider: DataInjectProvider,
    private _app: AppComponent,
    private _router: Router,
    private _pdfService: CreatePdfService,
    private transformation: Transformation
  ) {
    if (!!this._dataProvider.storage) {
      this.dataCliente = this._dataProvider.storage;
      this.fillDataCliente();
      this.tieneCoresFaltantes = !!this.dataCliente.coresFaltantes;
    } else {
      this._router.navigate(['cliente360/consultar-cliente-pcc']);
    }
    this._app.global.nombre = sessionStorage.getItem("fullname");
    this._app.global.showHeader = true;
    this._app.global.showId = false;
  }

  ngOnInit() {}

  /**
   * Metodo para finalizar la actividad del proceso de Consulta de endeudamiento del cliente
   * y finalizar el proceso
   */
  goToInbox() {
    this.isLoadingActive = true;
    this.resetSessionData();
  }

  /**
   * Metodo para limpiar las variables del session storage al momento de volver a la
   * bandeja de tareas
   */
  resetSessionData() {
    this._dataProvider.storage = null;
    sessionStorage.removeItem("taskId");
    sessionStorage.removeItem("instanceId");
    this._router.navigate(["portal/bandeja-tareas"]);
  }

  /**
   * Metodo para expandir y colapsar la seccion de obligaciones
   * @param idNodeProduct
   */
  expandDetail(idNodeProduct) {
    const nodeProduct = document.getElementById(idNodeProduct);
    if (!!nodeProduct) {
      const dataGeneralNode = nodeProduct.querySelector("#generalDetail");
      const dataPrincipalNode = nodeProduct.querySelector("#principalDetail");
      let newHeigth = 0;
      if (!!dataGeneralNode && dataPrincipalNode) {
        if (dataPrincipalNode.classList.contains("display-none")) {
          dataGeneralNode.classList.add("display-none");
          dataPrincipalNode.classList.remove("display-none");
          newHeigth = dataPrincipalNode.clientHeight;
          nodeProduct.classList.add("expanded-element", "send-front");
        } else {
          dataPrincipalNode.classList.add("display-none");
          dataGeneralNode.classList.remove("display-none");
          newHeigth = dataGeneralNode.clientHeight;
          nodeProduct.classList.remove("expanded-element", "send-front");
        }
      }
      const detailBody: HTMLElement = nodeProduct.querySelector(".tr-data-container") as HTMLElement;
      if (!!detailBody) {
        detailBody.style.height = newHeigth + "px";
      }
    }
  }

 /**
  * Metodo para cerrar el modal de error que se muestra al momento de rechazar la generacion de paz y salvo
  * @param show
  */
  onClose(show: boolean ) {
    this.showPazSalvo = show;
  }

  /**
   * Metodo para abrir el modal de la persona dirigida en la generacion del certificado
   */
  generarCertificado() {
      if (this.pantallaActual === "OBLIGACIONES"
          || (this.pantallaActual === "HISTORICO" && this.validatePazSalvo())) {
        this.showModalConfirm = true;
        this.personaDirigida = "A quién le interese";
      }
  }

  validatePazSalvo() {
    const result = ((!!this.dataCliente.cliente.estCastigo && this.dataCliente.cliente.estCastigo.toUpperCase().indexOf("S") !== -1) ||
                    (!!this.dataCliente.cliente.estJudicializadoAval && this.dataCliente.cliente.estJudicializadoAval.toUpperCase().indexOf("S") !== -1) ||
                    (!!this.dataCliente.cliente.estJudicializadoCli && this.dataCliente.cliente.estJudicializadoCli.toUpperCase().indexOf("S") !== -1) ||
                    (!!this.dataCliente.cliente.estLeyInsolvencia && this.dataCliente.cliente.estLeyInsolvencia.toUpperCase().indexOf("S") !== -1) ||
                    (!!this.dataCliente.cliente.estVentaCartera && this.dataCliente.cliente.estVentaCartera.toUpperCase().indexOf("S") !== -1));
    if (result) {
      this.showPazSalvo = true;
    }
    return !result;
  }

  /**
   * Metodo para activar las opciones visuales de la negociacion de las obligaciones
   */
  generarNegociacion() {
    this.isNegociacionActive = true;
  }

  /**
   * Metodo para generar el archivo XLSX de la negociacion con el cliente
   */
  confirmarNegociacion() {
    this.getXLS(this.createReqObject());
    this.showModalChipInfo = true;
  }

  /**
   * Metodo para cerrar el modal de la confirmacion del certificado
   */
  closeModal() {
    this.showModalConfirm = false;
  }

  /**
   * Valida que el campo de la persona dirigida este correctamente diligenciado
   */
  validateTxtAQuienInterese() {
    return !(!!this.personaDirigida);
  }

  /**
   * Metodo para generar el certificado de deuda cliente o el paz y salvo de
   * acuerdo a la logica de la aplicacion
   */
  confirmarGenCertificado() {
    if (this.pantallaActual === "OBLIGACIONES") {
      this.generarCertDeudaCliente();
    } else if (this.pantallaActual === "HISTORICO") {
      this.generarPazYSalvo();
    }
  }

  /**
   * Metodo que obtiene el modelo de datos y realiza el llamado para la generacion de deuda
   * del cliente
   */
  generarCertDeudaCliente() {
    const dataCertificado = new DataCertificado();
    dataCertificado.aQuienInterese = this.personaDirigida;
    dataCertificado.personaReferencia = this.dataCliente.cliente.nomCliente;
    dataCertificado.tipoIdentificacion = this.dataTransformation.changeTipoIdentificacion(this.dataCliente.cliente.tipId);
    dataCertificado.numeroIdentificacion = this.dataCliente.cliente.numId;
    dataCertificado.prodsClienteList = new Array<ProductoCliente>();
    const allProds = (!!this.dataCliente.obligacionesTitular ? this.dataCliente.obligacionesTitular : []).concat(!!this.dataCliente.obligacionesInterviniente ? this.dataCliente.obligacionesInterviniente : []);
    allProds.forEach(element => {
      const saldoProd = (!!element.saldoMl ? parseFloat(element.saldoMl) : 0)
        + (!!element.saldoMora ? parseFloat(element.saldoMora) : 0)
        + (!!element.saldoIntCorrientes ? parseFloat(element.saldoIntCorrientes) : 0)
        + (!!element.saldoIntMora ? parseFloat(element.saldoIntMora) : 0)
        + (!!element.saldoOtrosCargos ? parseFloat(element.saldoOtrosCargos) : 0)
        + (!!element.saldoExtracontable ? parseFloat(element.saldoExtracontable) : 0);
      dataCertificado.prodsClienteList.push(new ProductoCliente(element.nomSubproducto, element.numCuenta, this.dataTransformation.changeCurrencyStrValue(saldoProd)));
    });
    this.getPDF(dataCertificado, "co.itau.apiformatos.adapter.pdfAdapter.impl.DataAdapterDeudaClienteImpl");
  }

  /**
   * Metodo para realizar el llamado que hace la generacion del PDF de acuerdo a los parametros
   * @param body
   * @param className
   */
  getPDF(body, className) {
    this.isLoadingActive = true;
    const dataWrapper = new DataWrapper(className,  JSON.stringify(body));
    this._pdfService.createPDF(dataWrapper).then(
      response => {
        if (!!response) {
          const file = this.transformation.base64ToBlob(response.body, 'application/pdf');
          const fileURL = URL.createObjectURL(file);
          window.open(fileURL);
        }
        this.closeModal();
        this.isLoadingActive = false;
      },
      error => {
        console.error("Error en el servicio de generacion de formatos PDF.");
        console.error(error);
        this.closeModal();
        this.isLoadingActive = false;
      }
    );
  }

  /**
   * Metodo que almacena un elemento a un arreglo de tipo String de acuerdo a que si ya se encuentra o no
   * en dicho arreglo
   * @param idElement
   * @param listElements
   */
  validateElementList(idElement, listElements) {
    const idxElement = listElements.indexOf(idElement);
    if (idxElement !== -1) {
      listElements.splice(idxElement, 1);
    } else {
      listElements.push(idElement);
    }
  }

  /**
   * Metodo que genera el modelo de datos para la ficha de negociacion
   */
  createReqObject(): DataFichaNegociacion {

    const dataCliente = this.dataCliente;
    const allProdsNegociacion = (!!this.dataCliente.obligacionesTitular ? this.dataCliente.obligacionesTitular : []).concat(!!this.dataCliente.obligacionesInterviniente ? this.dataCliente.obligacionesInterviniente : [] );

    const dataFichaNegociacion = new DataFichaNegociacion();
    dataFichaNegociacion.datosDemograficos = new DatosDemograficos(this.dataTransformation.formatDateYearMonthDay(new Date()), (!!dataCliente.cliente.numId ? dataCliente.cliente.numId : ""), (!!dataCliente.cliente.nomCliente ? dataCliente.cliente.nomCliente : ""), (!!dataCliente.cliente.ciudadContacto ? dataCliente.cliente.ciudadContacto : ""), (!!dataCliente.cliente.direccion ? dataCliente.cliente.direccion : ""), (!!dataCliente.cliente.telefono ? dataCliente.cliente.telefono : ""), (!!dataCliente.cliente.numCelular ? dataCliente.cliente.numCelular : ""), (!!dataCliente.cliente.email ? dataCliente.cliente.email : ""));
    dataFichaNegociacion.informacionEconomica = new InformacionEconomica("", (!!dataCliente.cliente.ingresoFijo ? dataCliente.cliente.ingresoFijo : ""), (!!dataCliente.cliente.otrosIngresos ? dataCliente.cliente.otrosIngresos : ""), "", (!!dataCliente.cliente.totalIngresos ? dataCliente.cliente.totalIngresos : ""), "", "");
    dataFichaNegociacion.simulacionCuota = new SimulacionCuota("", "", "", "", "", "");

    this.setProdsNegociacion();
    dataFichaNegociacion.operacionesActualesList = new Array<OperacionesActuales>();
    for (let x = 0 ; x < allProdsNegociacion.length ; x++) {
      const producto = allProdsNegociacion[x];
      let productoAplica = "No";
      if (!!this.getObjectFromArray(this.prodsNegociacion, producto.numCuenta, producto.codSubproducto)) {
        productoAplica = "Sí";
      }
      dataFichaNegociacion.operacionesActualesList.push(new OperacionesActuales((!!producto.nomProduco ? producto.nomProduco : ""), (!!producto.numCuenta ? producto.numCuenta : ""), (!!producto.nomSubproducto ? producto.nomSubproducto : ""), (!!producto.impIniMl ? producto.impIniMl : ""), (!!producto.fecDesembolso ? this.dataTransformation.formatDateFromInt(producto.fecDesembolso) : ""), (!!producto.cuotasPactadas ? producto.cuotasPactadas : ""), (!!producto.cuotasPagadas ? producto.cuotasPagadas : ""), (!!producto.tasInt ? producto.tasInt : ""), (!!producto.valorCuota ? producto.valorCuota : ""), (!!producto.saldoMora ? producto.saldoMora : ""), (!!producto.capitalVigente ? producto.capitalVigente : ""), productoAplica));
    }

    dataFichaNegociacion.operacionesMoraList = new Array<OperacionesMora>();
    for (let x = 0 ; x < allProdsNegociacion.length ; x++) {
      const producto = allProdsNegociacion[x];
      if (!!producto.saldoMora && producto.saldoMora > 0) {
        const intCorrienteMora = String((!!producto.intCorrientes ? parseFloat(producto.intCorrientes) : 0) + (!!producto.intMora ? parseFloat(producto.intMora) : 0));
        dataFichaNegociacion.operacionesMoraList.push(new OperacionesMora((!!producto.nomProduco ? producto.nomProduco : ""), (!!producto.numCuenta ? producto.numCuenta : ""), (!!producto.nomSubproducto ? producto.nomSubproducto : ""), (!!producto.numDiaMora ? producto.numDiaMora : ""), (!!producto.capitalVigente ? producto.capitalVigente : ""), intCorrienteMora, (!!producto.intExtracontable ? producto.intExtracontable : ""), (!!producto.otrosCargos ? producto.otrosCargos : ""), (!!producto.honorarios ? producto.honorarios : ""), (!!producto.provisionCapital ? producto.provisionCapital : ""), (!!producto.provisionIntereses ? producto.provisionIntereses : ""), (!!producto.saldoCastigo ? producto.saldoCastigo : "")));
      }
    }
    dataFichaNegociacion.detalleCuotasSinLiquidarList = new Array<DetalleCuotasSinLiquidar>();

    dataFichaNegociacion.seguimientoJuridico = "";
    dataFichaNegociacion.motivoMora = "";
    dataFichaNegociacion.recomendacion = "";
    dataFichaNegociacion.resolucionComite = "";
    return dataFichaNegociacion;
  }

  /**
   * Establece los productos del acta de negociacion segun la seleccion
   */
  setProdsNegociacion() {
    this.prodsNegociacion = [];
    if (!!this.dataCliente.obligacionesTitular) {
      this.dataCliente.obligacionesTitular.forEach(element => {
        if (element.isActaNegociacionSelected) {
          this.prodsNegociacion.push(element.codSubproducto + '_' + element.numCuenta);
        }
      });
    }
    if (!!this.dataCliente.obligacionesInterviniente) {
      this.dataCliente.obligacionesInterviniente.forEach(element => {
        if (element.isActaNegociacionSelected) {
          this.prodsNegociacion.push(element.codSubproducto + '_' + element.numCuenta);
        }
      });
    }
  }

  /**
   * Metodo que realiza el llamado a la generacion del XLSX de la ficha de negociacion
   * @param body
   */
  getXLS(body) {
    this.isLoadingActive = true;
    const dataWrapper = new DataWrapper("co.itau.apiformatos.adapter.xlsAdapter.impl.DataXlsFichaNegImpl",  JSON.stringify(body));
    this._pdfService.createXLS(dataWrapper).then(
      response => {
        if (!!response.body) {
          const fileBlob = this.transformation.base64ToBlob(response.body, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
          const link = document.createElement('a');
          link.href = window.URL.createObjectURL(fileBlob);
          link.download = 'FichaNegociacion.xlsx';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
        this.closeModal();
        this.isLoadingActive = false;
      },
      error => {
        console.error("Error en el servicio de generacion de formatos.");
        console.error(error);
        this.closeModal();
        this.isLoadingActive = false;
      }
    );
  }

  /**
   * Metodo que con la informacion obtenida en la consulta completa la informacion requerida en la pantalla
   */
  fillDataCliente() {
    if (!!this.dataCliente) {
      this.dataCliente.cliente.edad = this.getAge(this.dataCliente.cliente.fecNacimiento);
      this.dataCliente.totalEndeudamiento = 0;
      this.dataCliente.capitalVigenteTitular = 0;
      this.dataCliente.capitalVigenteInterviniente = 0;
      this.dataCliente.saldoTotalVencidoTitular = 0;
      this.dataCliente.saldoTotalVencidoInterviniente = 0;
      this.dataCliente.valorCuotaTitular = 0;
      this.dataCliente.valorCuotaInterviniente = 0;

      // Obligaciones
      for (let x = 0 ; x < this.dataCliente.obligacionesTitular.length ; x++) {
        const productoCliente = this.dataCliente.obligacionesTitular[x];
        // Total endeudamiento consolidado
        const saldoProd = (!!productoCliente.saldoMl ? parseFloat(productoCliente.saldoMl) : 0)
          + (!!productoCliente.saldoMora ? parseFloat(productoCliente.saldoMora) : 0)
          + (!!productoCliente.saldoIntCorrientes ? parseFloat(productoCliente.saldoIntCorrientes) : 0)
          + (!!productoCliente.saldoIntMora ? parseFloat(productoCliente.saldoIntMora) : 0)
          + (!!productoCliente.saldoOtrosCargos ? parseFloat(productoCliente.saldoOtrosCargos) : 0)
          + (!!productoCliente.saldoExtracontable ? parseFloat(productoCliente.saldoExtracontable) : 0);
        this.dataCliente.totalEndeudamiento = this.dataCliente.totalEndeudamiento + saldoProd;
        // Total valor cuota titular
        this.dataCliente.valorCuotaTitular = this.dataCliente.valorCuotaTitular + (!!productoCliente.valorCuota ? parseFloat(productoCliente.valorCuota) : 0);
        // Total capital vigente titular
        this.dataCliente.capitalVigenteTitular = this.dataCliente.capitalVigenteTitular + (!!productoCliente.capitalVigente ? parseFloat(productoCliente.capitalVigente) : 0);
        // Total saldo vencido titular
        this.dataCliente.saldoTotalVencidoTitular = this.dataCliente.saldoTotalVencidoTitular + (!!productoCliente.saldoMora ? parseFloat(productoCliente.saldoMora) : 0);
        // Total provision e interes extracontable producto
        productoCliente.totalProvision = ((!!productoCliente.provisionCapital ? parseFloat(productoCliente.provisionCapital) : 0) + (!!productoCliente.provisionIntereses ? parseFloat(productoCliente.provisionIntereses) : 0)) * 100 / 100;
        productoCliente.totalIntExtraContable = ((!!productoCliente.intExtracontable ? parseFloat(productoCliente.intExtracontable) : 0)) * 100 / 100;
        // Total cuotas producto
        productoCliente.totalCuotas = (!!productoCliente.numDeCuota ? parseInt(productoCliente.numDeCuota) : 0) + (!!productoCliente.cuotasPagadas ? parseInt(productoCliente.cuotasPagadas) : 0) + (!!productoCliente.cuotasEnMora ? parseInt(productoCliente.cuotasEnMora) : 0);
        productoCliente.isActaNegociacionSelected = false;
        // Formateo de dias de mora
        productoCliente.numDiaMora = parseInt(productoCliente.numDiaMora);
      }

      for (let x = 0 ; x < this.dataCliente.obligacionesInterviniente.length ; x++) {
        const productoCliente = this.dataCliente.obligacionesInterviniente[x];
        // Total endeudamiento consolidado
        const saldoProd = (!!productoCliente.saldoMl ? parseFloat(productoCliente.saldoMl) : 0)
          + (!!productoCliente.saldoMora ? parseFloat(productoCliente.saldoMora) : 0)
          + (!!productoCliente.saldoIntCorrientes ? parseFloat(productoCliente.saldoIntCorrientes) : 0)
          + (!!productoCliente.saldoIntMora ? parseFloat(productoCliente.saldoIntMora) : 0)
          + (!!productoCliente.saldoOtrosCargos ? parseFloat(productoCliente.saldoOtrosCargos) : 0)
          + (!!productoCliente.saldoExtracontable ? parseFloat(productoCliente.saldoExtracontable) : 0);
        this.dataCliente.totalEndeudamiento = this.dataCliente.totalEndeudamiento + saldoProd;
        // Total valor cuota titular
        this.dataCliente.valorCuotaInterviniente = this.dataCliente.valorCuotaInterviniente + (!!productoCliente.valorCuota ? parseFloat(productoCliente.valorCuota) : 0);
        // Total capital vigente interviniente
        this.dataCliente.capitalVigenteInterviniente = this.dataCliente.capitalVigenteInterviniente + (!!productoCliente.capitalVigente ? parseFloat(productoCliente.capitalVigente) : 0);
        // Total saldo vencido interviniente
        this.dataCliente.saldoTotalVencidoInterviniente = this.dataCliente.saldoTotalVencidoInterviniente + (!!productoCliente.saldoMora ? parseFloat(productoCliente.saldoMora) : 0);
        // Total provision e interes extracontable producto
        productoCliente.totalProvision = ((!!productoCliente.provisionCapital ? parseFloat(productoCliente.provisionCapital) : 0) + (!!productoCliente.provisionIntereses ? parseFloat(productoCliente.provisionIntereses) : 0)) * 100 / 100;
        productoCliente.totalIntExtraContable = ((!!productoCliente.intExtracontable ? parseFloat(productoCliente.intExtracontable) : 0)) * 100 / 100;
        // Total cuotas producto
        productoCliente.totalCuotas = (!!productoCliente.numDeCuota ? parseInt(productoCliente.numDeCuota) : 0) + (!!productoCliente.cuotasPagadas ? parseInt(productoCliente.cuotasPagadas) : 0) + (!!productoCliente.cuotasEnMora ? parseInt(productoCliente.cuotasEnMora) : 0);
        productoCliente.isActaNegociacionSelected = false;
        // Formateo de dias de mora
        productoCliente.numDiaMora = parseInt(productoCliente.numDiaMora);
      }
      // Valores de saldo de Pasivo
      const valuesPasivoTitular = [];
      const valuesPasivosInterviniente = [];

      if (!!this.dataCliente.pasivosTitular) {
        this.dataCliente.pasivosTitular.forEach(pasivosTitular => {
          valuesPasivoTitular.push(!!pasivosTitular.saldoMl ? parseFloat(pasivosTitular.saldoMl) : 0);
        });
      }

      if (!!this.dataCliente.pasivosInterviniente) {
        this.dataCliente.pasivosInterviniente.forEach(pasivosInterviniente => {
          valuesPasivosInterviniente.push(!!pasivosInterviniente.saldoMl ? parseFloat(pasivosInterviniente.saldoMl) : 0);
        });
      }
      // TotalPasivo Titular
      this.dataCliente.saldoTotalVencidoPasivoTitular = valuesPasivoTitular.reduce((a, b) => a + b, 0);
      // TotalPasivo Interviniente
      this.dataCliente.saldoTotalVencidoPasivoInterveniente = valuesPasivosInterviniente.reduce((a, b) => a + b, 0);
      // SnackBar para productos no vigentes
      this.noProductsModal(this.dataCliente);
      // Variable para seleccion en paz y salvo
      if (!!this.dataCliente.productosCancelados) {
        this.dataCliente.productosCancelados.forEach(element => {
          element.isPazSalvo = true;
        });
      }
      // Se redondean los valores
      this.dataCliente.totalEndeudamiento = this.redondearValor(this.dataCliente.totalEndeudamiento);
      this.dataCliente.capitalVigenteTitular = this.redondearValor(this.dataCliente.capitalVigenteTitular);
      this.dataCliente.capitalVigenteInterviniente = this.redondearValor(this.dataCliente.capitalVigenteInterviniente);
      this.dataCliente.saldoTotalVencidoTitular = this.redondearValor(this.dataCliente.saldoTotalVencidoTitular);
      this.dataCliente.saldoTotalVencidoInterviniente = this.redondearValor(this.dataCliente.saldoTotalVencidoInterviniente);
      this.dataCliente.saldoTotalVencidoPasivoTitular = this.redondearValor(this.dataCliente.saldoTotalVencidoPasivoTitular);
      this.dataCliente.saldoTotalVencidoPasivoInterveniente = this.redondearValor(this.dataCliente.saldoTotalVencidoPasivoInterveniente);
      this.dataCliente.valorCuotaTitular = this.redondearValor(this.dataCliente.valorCuotaTitular);
      this.dataCliente.valorCuotaInterviniente = this.redondearValor(this.dataCliente.valorCuotaInterviniente);

      this.validateProdsCanceladosSel();
    }
  }

  /**
   * Redondea un valor decimal con dos decimas
   * @param valorInicial
   */
  redondearValor (valorInicial) {
    return Math.round(valorInicial * 100) / 100;
  }

  /**
   * Identificacion de falta de productos para abrir SnackBar
   */
  noProductsModal(dataCliente) {
    if ((!(!!dataCliente.obligacionesTitular) || (!!dataCliente.obligacionesTitular && dataCliente.obligacionesTitular.length === 0))
      || (!(!!dataCliente.obligacionesInterviniente) || (!!dataCliente.obligacionesInterviniente && dataCliente.obligacionesInterviniente.length === 0))
      || (!(!!dataCliente.pasivosTitular) || (!!dataCliente.pasivosTitular && dataCliente.pasivosTitular.length === 0))
      || (!(!!dataCliente.pasivosInterviniente) || (!!dataCliente.pasivosInterviniente && dataCliente.pasivosInterviniente.length === 0))
      || (!(!!dataCliente.garantiasAbiertas) || (!!dataCliente.garantiasAbiertas && dataCliente.garantiasAbiertas.length === 0))
      || (!(!!dataCliente.garantiasCerradas) || (!!dataCliente.garantiasCerradas && dataCliente.garantiasCerradas.length === 0))) {
      this.showModalChip = true;
    }
  }

  /**
   * Cierra el SnackBar Productos no Vigentes
   */
  closeModalChip() {
    this.showModalChip = false;
  }

  /**
   * Cierra el SnackBar Informativo
   */
  closeModalChipInfo() {
    this.showModalChipInfo = false;
  }

  getObjectFromArray(prodsCollection: Array<any>, numCuenta: string, codSubproducto: string): any {
    let result = "";
    prodsCollection.forEach(element => {
      if (element === codSubproducto + "_" + numCuenta) {
        result = element;
      }
    });
    return result;
  }

  /**
   * Actualiza el valor de la variable tieneCoresFaltantes que es la que controla la visibilida del modal
   * de los cores faltantes
   */
  cerrarModalCoresFaltantes() {
    this.tieneCoresFaltantes = false;
  }

  /**
   * Actualiza el valor de la variable pantallaActual que se encarga de mostrar un contenido determinado
   * en la pantalla
   * @param p_pantallaActual
   */
  setPantallaActual(p_pantallaActual: string) {
    this.pantallaActual = p_pantallaActual;
  }

  /**
   * Metodo para seleccionar o deseleccionar todos los elementos de la lista de paz y salvo
   */
  seleccionarTodos() {
    if (!!this.dataCliente.productosCancelados) {
      this.dataCliente.productosCancelados.forEach(element => {
        element.isPazSalvo = this.isAllSelected;
      });
      this.validateProdsCanceladosSel();
    }
  }

  /**
   * Metodo que valida que por lo menos este seleccionado un producto de la seccion historico para
   * la generacion del paz y salvo
   */
  validateGenerarPazSalvoBtn(): boolean {
    let result = false;
    if (!!this.dataCliente.productosCancelados) {
      for (let x = 0; x < this.dataCliente.productosCancelados.length; x++) {
        const element = this.dataCliente.productosCancelados[x];
        if (element.isPazSalvo) {
          result = true;
          break;
        }
      }
    }
    return result;
  }

  getAge(fechaNacimiento) {
    const onlyNumbersRegex = /^\d+$/;
    let res = "-";
    try {
      if (!!fechaNacimiento
          && onlyNumbersRegex.test(fechaNacimiento)
          && fechaNacimiento.length === 8) {
        const formatFechaNacimiento = fechaNacimiento.substring(0, 4) + "/" + fechaNacimiento.substring(4, 6) + "/" + fechaNacimiento.substring(6, 8);
        const present = new Date();
        const birth = new Date(formatFechaNacimiento);
        const month = present.getMonth() - birth.getMonth();
        let age = present.getFullYear() - birth.getFullYear();

        if (month < 0 || (month === 0 && present.getDate() < birth.getDate())) {
          age--;
        }
        if (age > 0) {
          res = age + " años";
        }
      }
    } catch (e) {
      console.error("Error calculando edad del cliente: " + e);
    }
    return res;
  }

  /**
   * Crea modelo de datos para la generacion del paz y salvo
   */
  generarPazYSalvo() {
    const dataPazSalvo = new DataCertificadoPazSalvo();
    dataPazSalvo.aQuienInterese = this.personaDirigida;
    dataPazSalvo.personaReferencia = this.dataCliente.cliente.nomCliente;
    dataPazSalvo.tipoIdentificacion = this.dataTransformation.changeTipoIdentificacion(this.dataCliente.cliente.tipId);
    dataPazSalvo.numeroIdentificacion = this.dataCliente.cliente.numId;
    dataPazSalvo.prodsClienteList = new Array<ProductoClientePazSalvo>();
    this.dataCliente.productosCancelados.forEach(element => {
      if (element.isPazSalvo) {
        dataPazSalvo.prodsClienteList.push(new ProductoClientePazSalvo(element.nomSubproducto, element.numCuenta));
      }
    });
    this.getPDF(dataPazSalvo, "co.itau.apiformatos.adapter.pdfAdapter.impl.DataAdapterPazSalvoImpl");
  }

  /**
   * Abre una nueva pestaña para el portal de adminfo
   */
  openAdminfoPortal() {
    window.open(this.linkAdminfo);
  }

  /**
   * Selecciona o quita la seleccion de todos las obligaciones para la generacion del acta de negociacion
   */
  seleccionarTodosAct(calidad) {
    if (calidad === "TITULAR") {
      if (this.isAllSelectedActTitular) {
        if (!!this.dataCliente.obligacionesTitular) {
          this.dataCliente.obligacionesTitular.forEach(element => {
            element.isActaNegociacionSelected = true;
          });
        }
      } else {
        if (!!this.dataCliente.obligacionesTitular) {
          this.dataCliente.obligacionesTitular.forEach(element => {
            element.isActaNegociacionSelected = false;
          });
        }
      }
    } else if (calidad === "INTERVINIENTE") {
      if (this.isAllSelectedActInterviniente) {
        if (!!this.dataCliente.obligacionesInterviniente) {
          this.dataCliente.obligacionesInterviniente.forEach(element => {
            element.isActaNegociacionSelected = true;
          });
        }
      } else {
        if (!!this.dataCliente.obligacionesInterviniente) {
          this.dataCliente.obligacionesInterviniente.forEach(element => {
            element.isActaNegociacionSelected = false;
          });
        }
      }
    }
  }

  /**
   * Validacion de los elementos seleccionados para habilitar el boton de generacion del acta de negociacion
   */
  validateGenerarActa() {
    const totalProdsTitular = ((!!this.dataCliente.obligacionesTitular) ? this.dataCliente.obligacionesTitular.length : 0);
    const totalProdsInterviente = ((!!this.dataCliente.obligacionesInterviniente) ? this.dataCliente.obligacionesInterviniente.length : 0);
    let contSeleccionadosTitular = 0;
    let contSeleccionadosInterviniente = 0;
    if (!!this.dataCliente.obligacionesTitular) {
      for (let x = 0; x < this.dataCliente.obligacionesTitular.length; x++) {
        const element = this.dataCliente.obligacionesTitular[x];
        if (element.isActaNegociacionSelected) {
          contSeleccionadosTitular++;
        }
      }
    }
    if (!!this.dataCliente.obligacionesInterviniente) {
      for (let x = 0; x < this.dataCliente.obligacionesInterviniente.length; x++) {
        const element = this.dataCliente.obligacionesInterviniente[x];
        if (element.isActaNegociacionSelected) {
          contSeleccionadosInterviniente++;
        }
      }
    }
    this.oblTitularSeleccionadas = this.validateSeleccionados(contSeleccionadosTitular, totalProdsTitular);
    this.oblIntervinienteSeleccionadas = this.validateSeleccionados(contSeleccionadosInterviniente, totalProdsInterviente);
    return !((contSeleccionadosTitular + contSeleccionadosInterviniente) > 0);
  }

  /**
   * Construye una cadena de texto para mostrar cuantos productos cancelados fueron seleccionados
   */
  validateProdsCanceladosSel() {
    const totalProdsCancelados = (!!this.dataCliente.productosCancelados) ? this.dataCliente.productosCancelados.length : 0;
    let contProdsCanceladosSel = 0;
    if (!!this.dataCliente.productosCancelados) {
      for (let x = 0; x < this.dataCliente.productosCancelados.length; x++) {
        const element = this.dataCliente.productosCancelados[x];
        if (element.isPazSalvo) {
          contProdsCanceladosSel++;
        }
      }
      this.oblCanceladasSeleccionadas = this.validateSeleccionados(contProdsCanceladosSel, totalProdsCancelados);
    }
  }

  /**
   * Validacion para mostrar en pantalla los elementos seleccionados
   * @param contSeleccionados
   * @param totalProductos
   */
  validateSeleccionados(contSeleccionados, totalProductos) {
    let result = "";
    if (contSeleccionados > 0) {
      if (contSeleccionados === totalProductos) {
        result = "Todos los ítems seleccionados";
      } else if (contSeleccionados === 1) {
        result = "1 ítem seleccionado";
      } else {
        result = contSeleccionados + " ítems seleccionados";
      }
    }
    return result;
  }

  cerrarModalCliRestr() {
    this.showPazSalvo = false;
  }
}
