export class OperacionesActuales {
    tipoOperacion: string;
    numOperacion: string;
    nombreProducto: string;
    valorInicial: string;
    fechaAlza: string;
    cuotasPactadas: string;
    cuotasPagadas: string;
    tasa: string;
    cuota: string;
    saldoMora: string;
    capital: string;
    aplica: string;

    constructor(tipoOperacion_p: string, numOperacion_p: string, nombreProducto_p: string , valorInicial_p: string, fechaAlza_p: string, cuotasPactadas_p: string,
            cuotasPagadas_p: string, tasa_p: string, cuota_p: string, saldoMora_p: string, capital_p: string, aplica_p: string) {
        this.tipoOperacion = tipoOperacion_p;
        this.numOperacion = numOperacion_p;
        this.nombreProducto = nombreProducto_p;
        this.valorInicial = valorInicial_p;
        this.fechaAlza = fechaAlza_p;
        this.cuotasPactadas = cuotasPactadas_p;
        this.cuotasPagadas = cuotasPagadas_p;
        this.tasa = tasa_p;
        this.cuota = cuota_p;
        this.saldoMora = saldoMora_p;
        this.capital = capital_p;
        this.aplica = aplica_p;
    }
}
