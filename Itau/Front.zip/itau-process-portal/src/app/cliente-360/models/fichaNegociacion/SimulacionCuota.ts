export class SimulacionCuota {
    public tasa: string;
    public plazo: string;
    public capital: string;
    public amortizacion: string;
    public cuota: string;
    public producto: string;

    constructor(tasa_p: string, plazo_p: string, capital_p: string, amortizacion_p: string, cuota_p: string, producto_p: string) {
        this.tasa = tasa_p;
        this.plazo = plazo_p;
        this.capital = capital_p;
        this.amortizacion = amortizacion_p;
        this.cuota = cuota_p;
        this.producto = producto_p;
    }
}
