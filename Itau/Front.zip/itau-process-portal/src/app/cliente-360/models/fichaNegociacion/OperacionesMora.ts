export class OperacionesMora {
    tipoOperacion: string;
    numOperacion: string;
    nombreProducto: string;
    diasMora: string;
    capitalVigente: string;
    intCorrientesConMora: string;
    intExtContables: string;
    otrosCargos: string;
    honorarios: string;
    provCapital: string;
    provIntereses: string;
    saldoCastigado: string;

    constructor(tipoOperacion_p: string, numOperacion_p: string, nombreProducto_p: string, diasMora_p: string, capitalVigente_p: string, intCorrientesConMora_p: string, intExtContables_p: string,
            otrosCargos_p: string, honorarios_p: string, provCapital_p: string, provIntereses_p: string, saldoCastigado_p: string) {
        this.tipoOperacion = tipoOperacion_p;
        this.numOperacion = numOperacion_p;
        this.nombreProducto = nombreProducto_p;
        this.diasMora = diasMora_p;
        this.capitalVigente = capitalVigente_p;
        this.intCorrientesConMora = intCorrientesConMora_p;
        this.intExtContables = intExtContables_p;
        this.otrosCargos = otrosCargos_p;
        this.honorarios = honorarios_p;
        this.provCapital = provCapital_p;
        this.provIntereses = provIntereses_p;
        this.saldoCastigado = saldoCastigado_p;
    }
}
