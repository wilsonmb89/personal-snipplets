export class DetalleCuotasSinLiquidar {
    tipoOperacion: string;
    numOperacion: string;
    numCuota: string;
    fechaVcto: string;
    capitalCuota: string;
    intCorriente: string;
    intMora: string;
    otrosCargos: string;
    pagoCapital: string;
    pagoIntCte: string;
    pagoIntMora: string;
    pagoOtrosCargos: string;

    constructor(tipoOperacion_p: string, numOperacion_p: string, numCuota_p: string, fechaVcto_p: string, capitalCuota_p: string,
            intCorriente_p: string, intMora_p: string, otrosCargos_p: string, pagoCapital_p: string,
            pagoIntCte_p: string, pagoIntMora_p: string, pagoOtrosCargos_p: string) {
        this.tipoOperacion = tipoOperacion_p;
        this.numOperacion = numOperacion_p;
        this.numCuota = numCuota_p;
        this.fechaVcto = fechaVcto_p;
        this.capitalCuota = capitalCuota_p;
        this.intCorriente = intCorriente_p;
        this.intMora = intMora_p;
        this.otrosCargos = otrosCargos_p;
        this.pagoCapital = pagoCapital_p;
        this.pagoIntCte = pagoIntCte_p;
        this.pagoIntMora = pagoIntMora_p;
        this.pagoOtrosCargos = pagoOtrosCargos_p;
    }
}
