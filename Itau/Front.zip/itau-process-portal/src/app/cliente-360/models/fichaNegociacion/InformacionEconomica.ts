export class InformacionEconomica {
    public actividadEconomica: string;
    public salario: string;
    public otrosIngresos: string;
    public porcIngresosDisponble: string;
    public totalIngresosDisponible: string;
    public tasaEsfuerzo: string;
    public decision: string;

    constructor(actividadEconomica_p: string, salario_p: string, otrosIngresos_p: string, porcIngresosDisponble_p: string, totalIngresosDisponible_p: string, tasaEsfuerzo_p: string, decision_p: string) {
        this.actividadEconomica = actividadEconomica_p;
        this.salario = salario_p;
        this.otrosIngresos = otrosIngresos_p;
        this.porcIngresosDisponble = porcIngresosDisponble_p;
        this.totalIngresosDisponible = totalIngresosDisponible_p;
        this.tasaEsfuerzo = tasaEsfuerzo_p;
        this.decision = decision_p;
    }
}
