export class DatosDemograficos {
    public fechaCorteDatos: string;
    public id: string;
    public nombre: string;
    public ciudadRes: string;
    public direccionRes: string;
    public telefonoLocal: string;
    public telefonoCelular: string;
    public email: string;

    constructor(fechaCorteDatos_p: string, id_p: string, nombre_p: string, ciudadRes_p: string, direccionRes_p: string,
                telefonoLocal_p: string, telefonoCelular_p: string, email_p: string) {
        this.fechaCorteDatos = fechaCorteDatos_p;
        this.id = id_p;
        this.nombre = nombre_p;
        this.ciudadRes = ciudadRes_p;
        this.direccionRes = direccionRes_p;
        this.telefonoLocal = telefonoLocal_p;
        this.telefonoCelular = telefonoCelular_p;
        this.email = email_p;
    }
}
