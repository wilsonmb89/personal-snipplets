import { DatosDemograficos } from "./DatosDemograficos";
import { InformacionEconomica } from "./InformacionEconomica";
import { SimulacionCuota } from "./SimulacionCuota";
import { OperacionesActuales } from "./OperacionesActuales";
import { OperacionesMora } from "./OperacionesMora";
import { DetalleCuotasSinLiquidar } from "./DetalleCuotasSinLiquidar";

export class DataFichaNegociacion {
    public datosDemograficos: DatosDemograficos;
    public informacionEconomica: InformacionEconomica;
    public operacionesActualesList: Array<OperacionesActuales>;
    public operacionesMoraList: Array<OperacionesMora>;
    public detalleCuotasSinLiquidarList: Array<DetalleCuotasSinLiquidar>;
    public simulacionCuota: SimulacionCuota;
    public seguimientoJuridico: string;
    public motivoMora: string;
    public recomendacion: string;
    public resolucionComite: string;
}
