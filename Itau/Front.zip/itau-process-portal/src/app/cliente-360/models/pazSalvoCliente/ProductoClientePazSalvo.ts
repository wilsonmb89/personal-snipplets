export class ProductoClientePazSalvo {
    nombre: string;
    numero: string;

    constructor(p_nombre: string, p_numero: string) {
        this.nombre = p_nombre;
        this.numero = p_numero;
    }
}
