import { ProductoClientePazSalvo } from "./ProductoClientePazSalvo";

export class DataCertificadoPazSalvo {
    aQuienInterese: string;
    personaReferencia: string;
    tipoIdentificacion: string;
    numeroIdentificacion: string;
    prodsClienteList: Array<ProductoClientePazSalvo>;
}
