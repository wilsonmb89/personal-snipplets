import { ProductoCliente } from "./ProductoCliente";

export class DataCertificado {
    aQuienInterese: string;
    personaReferencia: string;
    tipoIdentificacion: string;
    numeroIdentificacion: string;
    prodsClienteList: Array<ProductoCliente>;
}
