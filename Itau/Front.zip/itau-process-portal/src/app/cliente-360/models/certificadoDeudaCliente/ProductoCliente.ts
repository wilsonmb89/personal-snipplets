export class ProductoCliente {
    nombre: string;
    numero: string;
    saldo: string;

    constructor(p_nombre: string, p_numero: string, p_saldo: string) {
        this.nombre = p_nombre;
        this.numero = p_numero;
        this.saldo = p_saldo;
    }
}
