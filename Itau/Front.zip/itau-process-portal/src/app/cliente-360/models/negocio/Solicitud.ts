export class Solicitud {
    numeroSolicitud: string;
    datosSolicitud: any;
}
