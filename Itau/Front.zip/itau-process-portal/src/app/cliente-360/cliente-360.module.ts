// Navigation services
import { AuthGuardService as AuthGuard } from '../shared/services/auth-guard.service';

// Modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../material/material.module';

// Components
import { SearchCustomerComponent } from './components/search-customer/search-customer.component';
import { SearchCustomerResultComponent } from './components/search-customer-result/search-customer-result.component';

// Services
import { ODSSearchService } from './services/busquedaODS.service';
import { CreatePdfService } from '../shared/services/create-pdf.service';
import { DataInjectProvider } from '../shared/services/data';
import { AutoflowService } from '../shared/services/autoflow.service';
import { SolicitudesServiceService } from '../shared/services/solicitudes-service.service';

// Pipes
import { ItauCurrencyCust360Pipe } from './pipes/itau-currency-cust-360.pipe';
import { DateFormatPipe } from '../shared/pipes/date-format.pipe';
import { CelphoneMaskPipe } from './pipes/celphone-mask.pipe';


const routes: Routes = [
  { path: '', redirectTo: 'consultar-cliente-pcc', pathMatch: 'full' },
  { path: 'consultar-cliente-pcc', component: SearchCustomerComponent, canActivate: [AuthGuard] },
  { path: 'resultado-consulta-pcc', component: SearchCustomerResultComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [SearchCustomerComponent,
    SearchCustomerResultComponent,
    ItauCurrencyCust360Pipe,
    DateFormatPipe,
    CelphoneMaskPipe
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    SharedModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule
  ],
  providers: [
    ODSSearchService,
    CreatePdfService,
    DataInjectProvider,
    AutoflowService,
    SolicitudesServiceService
  ]
})

export class Cliente360Module { }
