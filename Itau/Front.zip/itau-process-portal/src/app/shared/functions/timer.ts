import { Observable } from "rxjs/Rx";
import "rxjs/add/observable/interval";
import "rxjs/add/operator/take";
import "rxjs/add/operator/map";
import "rxjs/add/operator/bufferCount";
import { Subscription } from "rxjs";

export class TimerClass {
    private myObservable = Observable;
    private suscription: Subscription;

    constructor() {}

    public getMyObservable() {
        return this.myObservable;
    }

    public setMyObservable(observable) {
        this.myObservable = observable;
    }

    public getSuscription() {
        return this.suscription;
    }

    public setSuscription(suscription) {
        this.suscription = suscription;
    }
}

