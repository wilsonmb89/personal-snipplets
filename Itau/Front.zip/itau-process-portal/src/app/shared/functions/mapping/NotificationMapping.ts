import { SendEmailNotificationRqWrapper } from '../../models/services/notification/sendEmailNotification/SendEmailNotificationRqWrapper';
import { SendEMailNotificationRqType } from '../../models/services/notification/sendEmailNotification/SendEMailNotificationRqType';
import { HeaderRequestType } from '../../models/services/notification/commons/HeaderRequestType';
import { MessageHeaderType } from '../../models/services/notification/commons/MessageHeaderType';
import { MessageInfoType } from '../../models/services/notification/commons/MessageInfoType';
import { REQUEST_SEND_EMAIL_NOTIFICATION } from '../../constants/codigosServicios.constant';
import { NotificationInfoType } from '../../models/services/notification/commons/NotificationInfoType';
import { MessageType } from '../../models/services/notification/commons/MessageType';
import { DeliveryInstructionType } from '../../models/services/notification/commons/DeliveryInstructionType';
import { EmailType } from '../../models/services/notification/commons/EmailType';
import { SendMessageNotificationRqWrapper } from '../../models/services/notification/sendMessageNotification/SendMessageNotificationRqWrapper';
import { SendMessageNotificationRqType } from '../../models/services/notification/sendMessageNotification/SendMessageNotificationRqType';
import { PhoneNumType } from '../../models/services/notification/commons/PhoneNumType';


export class NotificationMapping {

    public requestSendEmail: SendEmailNotificationRqWrapper;
    public requestSendSMS: SendMessageNotificationRqWrapper;

    constructor() {
    }

    mappingSendEmailNotification(codigoNotificacion: string, subject: string, emailAddress: string, datosEmail: any): SendEmailNotificationRqWrapper {
        this.requestSendEmail = new SendEmailNotificationRqWrapper();
        this.requestSendEmail.sendEmailNotificationRqType = new SendEMailNotificationRqType();
        this.requestSendEmail.sendEmailNotificationRqType.headerRequest = new HeaderRequestType();
        this.requestSendEmail.sendEmailNotificationRqType.headerRequest.messageHeader = new MessageHeaderType();
        this.requestSendEmail.sendEmailNotificationRqType.headerRequest.messageHeader.messageInfo = new MessageInfoType();
        this.requestSendEmail.codigoNotificacion = codigoNotificacion;
        this.requestSendEmail.datosEmail = datosEmail;
        this.requestSendEmail.sendEmailNotificationRqType.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_SEND_EMAIL_NOTIFICATION.BPM_AUTHOR;
        this.requestSendEmail.sendEmailNotificationRqType.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_SEND_EMAIL_NOTIFICATION.ORIGINATOR_TYPE;
        this.requestSendEmail.sendEmailNotificationRqType.headerRequest.messageHeader.messageInfo.systemId = REQUEST_SEND_EMAIL_NOTIFICATION.BPM_AUTHOR;
        this.requestSendEmail.sendEmailNotificationRqType.headerRequest.messageHeader.messageInfo.terminalId = REQUEST_SEND_EMAIL_NOTIFICATION.TERMINAL_ID;
        this.requestSendEmail.sendEmailNotificationRqType.notificationInfo = new NotificationInfoType();
        this.requestSendEmail.sendEmailNotificationRqType.notificationInfo.message = new MessageType();
        this.requestSendEmail.sendEmailNotificationRqType.notificationInfo.message.from = REQUEST_SEND_EMAIL_NOTIFICATION.GENERIC_FROM;
        this.requestSendEmail.sendEmailNotificationRqType.notificationInfo.message.subject = subject;
        this.requestSendEmail.sendEmailNotificationRqType.notificationInfo.deliveryInstruction = new DeliveryInstructionType();
        this.requestSendEmail.sendEmailNotificationRqType.notificationInfo.deliveryInstruction.email = new EmailType();
        this.requestSendEmail.sendEmailNotificationRqType.notificationInfo.deliveryInstruction.email.emailAddr = emailAddress;

        return this.requestSendEmail;
    }

    mappingSendMessageNotification(codigoNotificacion: string, numeroTelefono: string, datosSMS: any): SendMessageNotificationRqWrapper {
        this.requestSendSMS = new SendMessageNotificationRqWrapper();
        this.requestSendSMS.codigoNotificacion = codigoNotificacion;
        this.requestSendSMS.datosSMS = datosSMS;
        this.requestSendSMS.sendMessageNotificationRqType = new SendMessageNotificationRqType();
        this.requestSendSMS.sendMessageNotificationRqType.headerRequest = new HeaderRequestType();
        this.requestSendSMS.sendMessageNotificationRqType.headerRequest.messageHeader = new MessageHeaderType();
        this.requestSendSMS.sendMessageNotificationRqType.headerRequest.messageHeader.messageInfo = new MessageInfoType();
        this.requestSendSMS.sendMessageNotificationRqType.headerRequest.messageHeader.messageInfo.originatorName = REQUEST_SEND_EMAIL_NOTIFICATION.BPM_AUTHOR;
        this.requestSendSMS.sendMessageNotificationRqType.headerRequest.messageHeader.messageInfo.originatorType = REQUEST_SEND_EMAIL_NOTIFICATION.ORIGINATOR_TYPE;
        this.requestSendSMS.sendMessageNotificationRqType.headerRequest.messageHeader.messageInfo.systemId = REQUEST_SEND_EMAIL_NOTIFICATION.BPM_AUTHOR;
        this.requestSendSMS.sendMessageNotificationRqType.headerRequest.messageHeader.messageInfo.terminalId = REQUEST_SEND_EMAIL_NOTIFICATION.TERMINAL_ID;
        this.requestSendSMS.sendMessageNotificationRqType.notificationInfo = new NotificationInfoType();
        this.requestSendSMS.sendMessageNotificationRqType.notificationInfo.deliveryInstruction = new DeliveryInstructionType();
        this.requestSendSMS.sendMessageNotificationRqType.notificationInfo.deliveryInstruction.deliveryMethod = REQUEST_SEND_EMAIL_NOTIFICATION.DELIVERY_METHOD;
        this.requestSendSMS.sendMessageNotificationRqType.notificationInfo.deliveryInstruction.phoneNum = new PhoneNumType();
        this.requestSendSMS.sendMessageNotificationRqType.notificationInfo.deliveryInstruction.phoneNum.phone = numeroTelefono;

        return this.requestSendSMS;
    }
}
