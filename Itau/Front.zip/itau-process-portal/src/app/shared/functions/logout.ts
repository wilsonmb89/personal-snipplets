export class LogOutUtil {

    public global = {
        showHeader: false,
        nombre: '',
        id: '',
        showId: false,
        profileImage: '',
        showLogOut: false
    };

    removeSessionData() {
        sessionStorage.removeItem("token");
        sessionStorage.removeItem("instanceId");
        sessionStorage.removeItem("taskId");
        sessionStorage.removeItem("datosFlujo");
        sessionStorage.removeItem("fullname");
        sessionStorage.removeItem("user");
        sessionStorage.removeItem("privateKey");
        sessionStorage.removeItem("publicKeyBack");
        sessionStorage.removeItem("loginRed");
        sessionStorage.clear();
    }

    clearGlobalData() {
        this.global.showHeader = false;
        this.global.showId = false;
        this.global.showLogOut = false;
        this.global.nombre = "";
        this.global.id = "";
        this.global.profileImage = "";
    }
}
