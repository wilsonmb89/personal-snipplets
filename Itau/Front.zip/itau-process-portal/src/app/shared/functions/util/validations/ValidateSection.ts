export class ValidateSection {

    constructor () {}

    validateSection(domSection) {
        let errors = 0;
        if (!!domSection) {
            // Validacion de los elementos <input type="text"> de la seccion que tengan el atributo requerido
            const sectionInputs = domSection.getElementsByTagName('input');
            for (let index = 0; index < sectionInputs.length; index++) {
                const input = sectionInputs[index];
                if (!!input
                     && input.required
                     && (input.type === "text" || input.type === "email")
                     && input.classList.contains("ng-invalid")) {
                    errors++;
                }
            }
            // Validacion de los toggle butons
            const sectionToggleBtns = domSection.getElementsByTagName('mat-button-toggle-group');
            for (let index = 0; index < sectionToggleBtns.length; index++) {
                const toggleBtn = sectionToggleBtns[index];
                if (!!toggleBtn) {
                    let isCheckedButtons = false;
                    const btnOptions = toggleBtn.getElementsByTagName('mat-button-toggle');
                    if (!!btnOptions) {
                        for (let y = 0 ; y < btnOptions.length; y++) {
                            if (!!btnOptions[y] && btnOptions[y].classList.contains('mat-button-toggle-checked')) {
                                isCheckedButtons = true;
                                break;
                            }
                        }
                    }
                    if (isCheckedButtons === false) {
                        errors = errors + 1;
                    }
                }
            }
            // Validacion mat-slide-toggle
            const sectionSlideToggleBtns = domSection.getElementsByTagName('mat-slide-toggle');
            if (!!sectionSlideToggleBtns && sectionSlideToggleBtns.length > 0) {
                let contToggleSelect = 0;
                for (let index = 0; index < sectionSlideToggleBtns.length; index++) {
                    const element = sectionSlideToggleBtns[index].getElementsByTagName("input")[0].checked;
                    if (element) {
                        contToggleSelect = contToggleSelect + 1;
                    }
                }
                if (contToggleSelect === 0) {
                    errors = errors + 1;
                }
            }

            return (errors > 0);
        }
    }
}
