import { NG_VALIDATORS, FormControl, ValidatorFn, Validator } from '@angular/forms';
import { Directive } from '@angular/core';

@Directive({
    selector: '[addressComparison][ngModel]',
    providers: [
        {
            provide: NG_VALIDATORS,
            useExisting: AddressValidator,
            multi: true
        }
    ]
})

export class AddressValidator implements Validator {
    validator: ValidatorFn;

    constructor() { this.validator = this.addressComparison(); }

    validate(c: FormControl) { return this.validator(c); }

    addressComparison(): ValidatorFn {
        return (c: FormControl) => {
            if (c.value !== undefined && c.value !== '' && c.value != null) {
                const arrayAddress = c.value.split(" ");
                const comparacion: string[] = ['AGRUPACION', 'APARTADO AEREO', 'APARTAMENTO', 'AUTOPISTA', 'AVENIDA', 'AVENIDA CALLE', 'AVENIDA CARRERA', 'BARRIO', 'BLOQUE', 'BODEGA', 'CALE', 'CALLE', 'CAMINO', 'CARRERA', 'CARRETERA', 'CASA', 'CELULA', 'CENTRO', 'CENTRO ADMINISTRATIVO NACIONAL', 'CENTRO COMERCIAL', 'CIRCULAR', 'CONJUNTO', 'CONSULTORIO', 'DEPOSITO', 'DIAGONAL', 'EDIFICIO', 'ENTRADA', 'ESQUINA', 'ESTE', 'ETAPA', 'GARAGE SOTANO', 'GARAJE', 'INTERIOR', 'KILOMETRO', 'LOCAL', 'LOTE', 'MANZANA', 'MEZZANINE', 'MODULO', 'MUNICIPIO', 'No', 'No.', 'NORTE', 'OCCIDENTE', 'OESTE', 'OFICINA', 'PARCELA', 'PASEO', 'PENTHOUSE', 'PISO', 'PREDIO', 'PUENTE', 'PUESTO', 'SALON COMUNAL', 'SECTOR', 'SEMISOTANO', 'SOLAR', 'SOTANO', 'SUPERMANZANA', 'SUR', 'TORRE', 'TRANSVERSAL', 'UNIDAD', 'UNIDAD RESIDENCIAL', 'URBANIZACION', 'VEREDA', 'VIA', 'ZONA', 'AG', 'A.A.', 'AP', 'AUTOP', 'AV', 'AV CL', 'AV KR', 'BRR', 'BL', 'BG', 'CL', 'CL', 'CAMINO', 'KR', 'CT', 'CS', 'CEL', 'CEN', 'CAN', 'CCO', 'CIRCULAR', 'CONJ', 'CONS', 'DP', 'DG', 'ED', 'ENT', 'ESQ', 'EST', 'ET', 'GS', 'GJ', 'INT', 'KM', 'LC', 'LT', 'MZ', 'MEZZ', 'MOD', 'MCP', 'NTE', 'OCC', 'OE', 'OF', 'PA', 'PASEO', 'PH', 'PI', 'PD', 'PTE', 'PTO', 'SC', 'SECT', 'SS', 'SL', 'ST', 'SPMZ', 'SUR', 'TRR', 'TV', 'UN', 'UR', 'URB', 'VEREDA', 'VIA', 'ZN', 'CLL', 'KRA', 'CR', 'CRA', 'APTO', 'APT', 'DIAG'];

                for (let i = 0; i < arrayAddress.length; i++) {
                    const element = arrayAddress[0].toUpperCase();
                    if (comparacion.indexOf(element) !== -1) {
                        const onlyLettersNumbers = new RegExp(/^[A-Za-z0-9\s]+$/g);
                        if (onlyLettersNumbers.test(c.value)) {
                            return null;
                        }

                    } else {
                        return {
                            addressComparison: {
                                valid: false
                            }
                        };
                    }
                }
            }
        };
    }
}
