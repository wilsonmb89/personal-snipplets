import { ValidatorFn, AbstractControl } from "@angular/forms";

export function nombreValorCatalogValidator(catalogo): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
        if (!!catalogo) {
            const validData = catalogo.find(function (obj) { return (obj.nombre + " - " + obj.valor).toUpperCase() === control.value.toUpperCase(); });
            return (!!validData) ? null : {value: false};
        } else {
            return null;
        }
    };
}

export function valorNombreCatalogValidator(catalogo): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
        if (!!catalogo) {
            const validData = catalogo.find(function (obj) { return (obj.valor + " - " + obj.nombre + " - " + obj.valorSector + " - " + obj.nombreSector).toUpperCase() === control.value.toUpperCase(); });
            return (!!validData) ? null : {value: false};
        } else {
            return null;
        }
    };
}

export function ciudadCatalogValidator(catalogo): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
        if (!!catalogo) {
            const validData = catalogo.find(function (obj) { return (obj.nombre + " - " + obj.valor + " - " + obj.nombreDpto + " - " + obj.valorPadre).toUpperCase() === control.value.toUpperCase(); });
            return (!!validData) ? null : {value: false};
        } else {
            return null;
        }
    };
}

export function exactLengthValidator(): ValidatorFn {
  console.log('Entro al validador customizado');
  return (control: AbstractControl): {[key: string]: any} | null => {
    if (!!control.value) {
      let validData = false;
      if (control.value.length === 7 || control.value.length === 10) {
        validData = true;
      }
      return (!!validData) ? null : {value: false};
    } else {
      return null;
    }
  };
}


export function oficinaCatalogValidator(catalogo): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
        if (!!catalogo) {
            const validData = catalogo.find(function (obj) { return (obj.valor).toUpperCase() === control.value.toUpperCase(); });
            return (!!validData) ? null : {value: false};
        } else {
            return null;
        }
    };
}
