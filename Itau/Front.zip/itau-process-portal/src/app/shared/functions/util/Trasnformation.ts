export class Transformation {

  GenerateDateFormatYearMonthDay() {
    const d = new Date();
    const year = d.getFullYear();
    let month = d.getMonth() + 1 + '';
    let day = d.getDate() + '';

    month = month.length < 2 ? '0' + month : month;
    day = day.length < 2 ? '0' + day : day;

    const result = year + "/" + month + "/" + day;

    return result;
  }

  formatDateYearMonthDay(date: Date) {
    const d = new Date(date);
    const year = d.getFullYear();
    let month = d.getMonth() + 1 + '';
    let day = d.getDate() + '';

    month = month.length < 2 ? '0' + month : month;
    day = day.length < 2 ? '0' + day : day;

    const result = year + "/" + month + "/" + day;

    return result;
  }

  formatDateYearMonthDay2(date: Date) {
    const d = new Date(date);
    const year = d.getFullYear();
    let month = d.getMonth() + 1 + '';
    let day = d.getDate() + '';

    month = month.length < 2 ? '0' + month : month;
    day = day.length < 2 ? '0' + day : day;

    const result = year + "-" + month + "-" + day;

    return result;
  }

  formatDate(valor: any): any {
    const dia = valor.substring(0, 2);
    const mes = valor.substring(2, 4) - 1;
    const año = valor.substring(4, 8);

    const d = new Date();
    d.setFullYear(año);
    d.setMonth(mes);
    d.setDate(dia);
    const result = new Date(d).toISOString();
    return result;
  }

  splitText(value: any): any[] {
    let result: any[];
    result = value.split(" - ");
    return result;
  }

  getOcupation(value) {
    switch (value) {
      case "40":
        return value = "Hogar";
      case "36":
        return value = "Empleado";
      case "37":
        return value = "Independiente";
      case "41":
        return value = "Pensionado";
      case "39":
        return value = "Estudiante";
    }
  }

  changeYesNo(value) {
    if (value === "S") {
      value = "Si";
    } else if (value === "N") {
      value = "No";
    }
    return value;
  }

  changeTrueFalse(value: string): boolean {
    if (value === "S") {
      return true;
    } else {
      return false;
    }
  }

  changeTipoIdentificacion(value: string): string {
    if (value === "1") {
      value = "C.C.";
    } else if (value === "2") {
      value = "CE";
    } else if (value === "3") {
      value = "Número de Identificación Tributario";
    } else if (value === "4") {
      value = "TI";
    } else if (value === "5") {
      value = "Pasaporte";
    } else if (value === "7") {
      value = "Soc.Ext.Sin Nit en Colombia";
    } else if (value === "9") {
      value = "Código de Empleado";
    } else if (value === "10") {
      value = "Grupo economico";
    } else if (value === "11") {
      value = "Nit Persona Natural";
    } else if (value === "15") {
      value = "Sucursal";
    } else if (value === "17") {
      value = "Pase Diplomático";
    } else if (value === "24") {
      value = "Registro Civil";
    }
    return value;
  }

  onlyNumbers(value) {
    if (value) {
      return value.replace(/\D/g, "");
    } else {
      return "0";
    }
  }

  changeMaleFemale(value) {
    if (value === "M") {
      value = "Masculino";
    } else {
      value = "Femenino";
    }
    return value;
  }

  changeCurrencyStrValue(value) {
    if (!!value) {
      let transform = value.toString().replace(/[.]/g, ",");
      transform = transform.replace(/[a-zA-Z.$'\s]/g, "");
      let decimalVal = "";
      if (transform.lastIndexOf(",") !== -1) {
        decimalVal = transform.substring(transform.lastIndexOf(","), transform.length);
        decimalVal = decimalVal.length > 3 ? decimalVal.substring(0, 3) : decimalVal;
        transform = transform.substring(0, transform.lastIndexOf(","));
      }
      if (!!transform && transform.length > 1) {
        transform = transform.toString().replace(/(\d)(?=(\d{3})+\b)/g, "$1.");
        transform = (transform.split(".").length >= 3 ? transform.replace(".", "'") : transform);
        return "$ " + transform + decimalVal;
      } else {
        return "-";
      }
    } else {
      return "-";
    }
  }

  /**
   * Metodo para generar fecha actual con formato dd de mm yyyy
   * @return string
   */
  GenerateFormatDateEsp(): string {
    const date = new Date();
    const monthNames = [
      "Enero", "Febrero", "Marzo",
      "Abril", "Mayo", "Junio", "Julio",
      "Agosto", "Septiembre", "Octubre",
      "Noviembre", "Diciembre"
    ];

    const day = date.getDate();
    const monthIndex = date.getMonth();
    const year = date.getFullYear();

    return day + ' de ' + monthNames[monthIndex] + ' ' + year;
  }

  /**
   * Metodo para ordernar las tareas activas del BPM y dar formato a las fechas del subject
   * @param taskList
   * @return any[]
   */
  orderActiveTaskByDate(taskList: any[]): any[] {
    if (!!taskList && taskList.length > 0) {
      for (let idx = 0; idx < taskList.length; idx++) {
        const description = !!taskList[idx].TAD_DESCRIPTION ? taskList[idx].TAD_DESCRIPTION : taskList[idx].description;
        taskList[idx].START_DATE = this.fixFormatDateTaskList(description);
        taskList[idx].TAD_DESCRIPTION = this.formatDateTaskList(description);
        taskList[idx].description = taskList[idx].TAD_DESCRIPTION;
      }
      taskList.sort((a: any, b: any) => {
        return new Date(b.START_DATE).getTime() - new Date(a.START_DATE).getTime();
      });
      return taskList;
    }
    return [];
  }

  /**
  * Metodo para dar formato correcto a la fecha que viene del subject de BPM
  * @param tadDescription
  * @return string
  */
  fixFormatDateTaskList(tadDescription: any): string {
    try {
      const result = tadDescription.split("-");
      let dateBPM = result[4];
      dateBPM = dateBPM.replace("COT", "");
      const fixDate = new Date(dateBPM);
      return fixDate.toString();
    } catch (error) {
      return tadDescription;
    }
  }

  /**
   * Metodo para dar formato a la fecha segun el inbox
   * @param tadDescription
   * @return string
   */
  formatDateTaskList(tadDescription: any) {

    const monthNames = [
      "ene", "feb", "mar",
      "abr", "may", "jun", "jul",
      "ago", "sep", "oct",
      "nov", "dic"
    ];

    const weekDays = [
      "Dom", "Lun", "Mar",
      "Mie", "Jue", "Vie", "Sab"
    ];

    let result = tadDescription.split("-");
    const formatDate = new Date(this.fixFormatDateTaskList(tadDescription));
    const todayDate = new Date();
    let resultDate = "";

    const hour = formatDate.getHours();
    let minutes = formatDate.getMinutes() + '';
    minutes = minutes.length < 2 ? '0' + minutes : minutes;

    if (formatDate.getFullYear() === todayDate.getFullYear() &&
      formatDate.getMonth() === todayDate.getMonth() &&
      formatDate.getDate() === todayDate.getDate()) {
      resultDate = hour + ":" + minutes;
    } else if (formatDate.getFullYear() === todayDate.getFullYear()) {
      const monthIndex = formatDate.getMonth();
      const dayIndex = formatDate.getDay();
      let day = formatDate.getDate() + '';
      day = day.length < 2 ? '0' + day : day;
      resultDate = weekDays[dayIndex] + " " + day + " " + monthNames[monthIndex];
    } else if (formatDate.getFullYear() !== todayDate.getFullYear()) {
      const monthIndex = formatDate.getMonth();
      const dayIndex = formatDate.getDay();
      let day = formatDate.getDate() + '';
      day = day.length < 2 ? '0' + day : day;
      resultDate = weekDays[dayIndex] + " " + day + " " + monthNames[monthIndex] + " " + formatDate.getFullYear();
    }
    result = result[0] + "-" + result[1] + "-" + result[2] + "-" + result[3] + "-" + resultDate;
    return result;
  }

  /**
   * Convierte un tipo de dato con formato AAAAmmDD a AAAA/mm/DD
   * @param value
   */
  formatDateFromInt(value) {
    value = String(value);
    const onlyNumbersRegex = /^\d+$/;
    if (!!value
      && onlyNumbersRegex.test(value)
      && value.length === 8) {
      const formatFechaNacimiento = value.substring(0, 4) + "/" + value.substring(4, 6) + "/" + value.substring(6, 8);
      value = formatFechaNacimiento;
    } else {
      value = this.formatDateYearMonthDay(new Date());
    }
    return value;
  }


  /**
   * Metodo para quitar formato de numero
   * @param value
   * @return number
   */
  deFormatMoney(value) {
    const newValue = value.replace(/[`~!@#$%^&*()_|+\-=?;:'",<>\{\}\[\]\\\/]/gi, '');
    return Number(Math.trunc(newValue));
  }

  /**
   * Metodo para obtener el codigo de la ocupacion
   * @param value
   * @return string
   */
  getCodOcupation(value) {
    switch (value) {
      case "Empleado":
        return "36";
      case "Independiente":
        return "37";
      case "Hogar":
        return "40";
      case "Pensionado":
        return "41";
      case "Estudiante":
        return "39";
    }
  }

  getOtrosIngresos(value) {
    switch (value) {
      case "arrendamientos":
        return "3 - Arrendamientos";
      case "bonificaciones":
        return "6 - Bonificaciones";
      case "comisiones":
        return "1 - Comisiones";
      case "consultoria":
        return "14 - Consultoría";
      case "contratos":
        return "7 - Contratos";
      case "dividendos y participaciones":
        return "4 - Dividendos y Participaciones";
      case "gastos representacion":
        return "12 - Gastos Representación";
      case "honorarios":
        return "2 - Honorarios";
      case "intereses":
        return "10 - Intereses";
      case "mesada":
        return "5 - Mesada";
      case "otros":
        return "17 - Otros";
      case "pension":
        return "16 - Pensión";
      case "rendimientos financieros":
        return "8 - Rendimientos Financieros";
      case "renta":
        return "11 - Renta";
      case "subsidio":
        return "15 - Subsidio";
      case "utilidades":
        return "9 - Utilidades";
      case "viaticos":
        return "13 - Viáticos";
      default:
        return value;
    }
  }

  deleteAccent(value) {
    let newValue = value.toLowerCase();
    newValue = newValue.replace(new RegExp(/\s/g), "");
    newValue = newValue.replace(new RegExp(/[àáâãäå]/g), "a");
    newValue = newValue.replace(new RegExp(/[èéêë]/g), "e");
    newValue = newValue.replace(new RegExp(/[ìíîï]/g), "i");
    newValue = newValue.replace(new RegExp(/[òóôõö]/g), "o");
    newValue = newValue.replace(new RegExp(/[ùúûü]/g), "u");

    return newValue;
  }

  /**
   * Metodo que retorna los ultimos 4 numeros de una cuenta pasada por parametro
   * @param accountNum
   */
  getLastFourNumbersAccount(accountNum) {
    const newValue = !!accountNum ? accountNum.replace(/\D/g, '') : "";
    if (!!newValue && newValue.length > 4) {
      return newValue.substring((newValue.length - 4), newValue.length);
    } else {
      return "";
    }
  }

  captitalizeText(text) {
    let result = "";
    if (!!text) {
      text = '' + text;
      const splitText = text.split(" ");
      splitText.forEach(element => {
        result = element.charAt(0).toUpperCase() + element.slice(1) + " ";
      });
      result = splitText.length > 1 ? result.substring(0, (result.length - 1)) : result;
    }
    return result;
  }

  base64ToBlob(b64Data, contentType = 'application/octet-stream', sliceSize = 512) {
    const byteCharacters = atob(b64Data);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      const slice = byteCharacters.slice(offset, offset + sliceSize);

      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }

    const blob = new Blob(byteArrays, { type: contentType });
    return blob;
  }

  addressComparison(value) {
    if (value !== undefined && value !== '' && value != null) {
      const arrayAddress = value.split(" ");
      const comparacion: string[] = ['AGRUPACION', 'APARTADO AEREO', 'APARTAMENTO', 'AUTOPISTA', 'AVENIDA', 'AVENIDA CALLE', 'AVENIDA CARRERA', 'BARRIO', 'BLOQUE', 'BODEGA', 'CALE', 'CALLE', 'CAMINO', 'CARRERA', 'CARRETERA', 'CASA', 'CELULA', 'CENTRO', 'CENTRO ADMINISTRATIVO NACIONAL', 'CENTRO COMERCIAL', 'CIRCULAR', 'CONJUNTO', 'CONSULTORIO', 'DEPOSITO', 'DIAGONAL', 'EDIFICIO', 'ENTRADA', 'ESQUINA', 'ESTE', 'ETAPA', 'GARAGE SOTANO', 'GARAJE', 'INTERIOR', 'KILOMETRO', 'LOCAL', 'LOTE', 'MANZANA', 'MEZZANINE', 'MODULO', 'MUNICIPIO', 'No', 'No.', 'NORTE', 'OCCIDENTE', 'OESTE', 'OFICINA', 'PARCELA', 'PASEO', 'PENTHOUSE', 'PISO', 'PREDIO', 'PUENTE', 'PUESTO', 'SALON COMUNAL', 'SECTOR', 'SEMISOTANO', 'SOLAR', 'SOTANO', 'SUPERMANZANA', 'SUR', 'TORRE', 'TRANSVERSAL', 'UNIDAD', 'UNIDAD RESIDENCIAL', 'URBANIZACION', 'VEREDA', 'VIA', 'ZONA', 'AG', 'A.A.', 'AP', 'AUTOP', 'AV', 'AV CL', 'AV KR', 'BRR', 'BL', 'BG', 'CL', 'CL', 'CAMINO', 'KR', 'CT', 'CS', 'CEL', 'CEN', 'CAN', 'CCO', 'CIRCULAR', 'CONJ', 'CONS', 'DP', 'DG', 'ED', 'ENT', 'ESQ', 'EST', 'ET', 'GS', 'GJ', 'INT', 'KM', 'LC', 'LT', 'MZ', 'MEZZ', 'MOD', 'MCP', 'NTE', 'OCC', 'OE', 'OF', 'PA', 'PASEO', 'PH', 'PI', 'PD', 'PTE', 'PTO', 'SC', 'SECT', 'SS', 'SL', 'ST', 'SPMZ', 'SUR', 'TRR', 'TV', 'UN', 'UR', 'URB', 'VEREDA', 'VIA', 'ZN', 'CLL', 'KRA', 'CR', 'CRA', 'APTO', 'APT', 'DIAG'];
      for (let i = 0; i < arrayAddress.length; i++) {
        const element = arrayAddress[0].toUpperCase();
        if (comparacion.indexOf(element) !== -1) {
          const onlyLettersNumbers = new RegExp(/^[A-Za-z0-9\s]+$/g);
          if (onlyLettersNumbers.test(value)) {
            return value;
          }
        } else {
          return "";
        }
      }
    }
  }

  formatCodeZero(value, width) {
    const length = value.toString().length; /* Largo del número */
    const zero = "0"; /* String de cero */

    if (width <= length) {
      return value.toString();
    } else {
      return ((zero.repeat(width - length)) + value.toString());
    }
  }

  /**
   * Metodo para descargar el PDF
   * @param body
   * @param filename
   * @param extension
   */
  createAndDownloadBlobFile(body, filename, extension = 'pdf') {
    const fileName = `${filename}.${extension}`;
    if (navigator.msSaveBlob) {
      // IE 10+
      navigator.msSaveBlob(body, fileName);
    } else {
      const link = document.createElement('a');
      // Browsers that support HTML5 download attribute
      if (link.download !== undefined) {
        const url = URL.createObjectURL(body);
        link.setAttribute('href', url);
        link.setAttribute('download', fileName);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

}
