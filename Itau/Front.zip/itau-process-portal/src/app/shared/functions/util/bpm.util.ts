export class BpmUtils {

    getObjectByCollection(collection: Array<any>, processAccronym: string): any {
        const pccObject = collection.find(function (obj) { return obj.processAppAcronym === processAccronym; });
        const procesObject = {
            idBpd: pccObject.itemID,
            idSnapshot: pccObject.snapshotID,
            idBranch: pccObject.branchID,
            idAppProcess: pccObject.processAppID
        };
        return procesObject;
    }

    getTaskReceived(collection: Array<any>): any {
        return collection.find(function (obj) { return obj.status === "Received"; });
    }
}
