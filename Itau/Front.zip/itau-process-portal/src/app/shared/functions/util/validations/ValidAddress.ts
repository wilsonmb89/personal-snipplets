export class ValidAddress {

  constructor() { }

  validacionDireccion(direccion) {
    let dirNormalice;
    let nuevaDireccion;
    let dirTrim: string;
    const maxlength: number = (direccion.length);

    if (maxlength > 0) {
      dirTrim = direccion.trim();
      dirNormalice = this.addressNormalize(dirTrim);

      // Eliminar espacios extras
      nuevaDireccion = dirNormalice.replace(/\s+/gi, ' ').trim();

      return nuevaDireccion;
    }

    return "";
  }

  addressNormalize(text) {
    let txt = text.toUpperCase();

    txt = txt.replace(/\./g, ' ');
    txt = txt.replace(/\!/g, ' ');
    txt = txt.replace(/\#/g, ' ');
    txt = txt.replace(/\$/g, ' ');
    txt = txt.replace(/\%/g, ' ');
    txt = txt.replace(/\&/g, ' ');
    txt = txt.replace(/\(/g, ' ');
    txt = txt.replace(/\)/g, ' ');
    txt = txt.replace(/\*/g, ' ');
    txt = txt.replace(/\+/g, ' ');
    txt = txt.replace(/\,/g, ' ');
    txt = txt.replace(/\-/g, ' ');
    txt = txt.replace(/\//g, ' ');
    txt = txt.replace(/\:/g, ' ');
    txt = txt.replace(/\;/g, ' ');
    txt = txt.replace(/\=/g, ' ');
    txt = txt.replace(/\?/g, ' ');
    txt = txt.replace(/\[/g, ' ');
    txt = txt.replace(/\]/g, ' ');
    txt = txt.replace(/\_/g, ' ');
    txt = txt.replace(/\{/g, ' ');
    txt = txt.replace(/\|/g, ' ');
    txt = txt.replace(/\}/g, ' ');
    txt = txt.replace(/\¡/g, ' ');
    txt = txt.replace(/\¨/g, ' ');
    txt = txt.replace(/\¬/g, ' ');

    txt = txt.replace(/(^|\W)AGRUPACION($|\W)/, ' AG ');
    txt = txt.replace(/(^|\W)APARTADO AEREO($|\W)/, ' A.A. ');
    txt = txt.replace(/(^|\W)APARTAMENTO($|\W)/, ' AP ');
    txt = txt.replace(/(^|\W)APTO($|\W)/, ' AP ');
    txt = txt.replace(/(^|\W)APT($|\W)/, ' AP ');
    txt = txt.replace(/(^|\W)AUTOPISTA($|\W)/, ' AUTOP ');
    txt = txt.replace(/(^|\W)AVENIDA($|\W)/, ' AV ');
    txt = txt.replace(/(^|\W)AVENIDA CALLE($|\W)/, ' AV CL ');
    txt = txt.replace(/(^|\W)AVENIDA CARRERA($|\W)/, ' AV KR ');
    txt = txt.replace(/(^|\W)BARRIO($|\W)/, ' BRR ');
    txt = txt.replace(/(^|\W)BLOQUE($|\W)/, ' BL ');
    txt = txt.replace(/(^|\W)BODEGA($|\W)/, ' BG ');
    txt = txt.replace(/(^|\W)CALE($|\W)/, ' CL ');
    txt = txt.replace(/(^|\W)CLL($|\W)/, ' CL ');
    txt = txt.replace(/(^|\W)Cl($|\W)/, ' CL ');
    txt = txt.replace(/(^|\W)CALLE($|\W)/, ' CL ');
    txt = txt.replace(/(^|\W)CAMINO($|\W)/, ' CAMINO ');
    txt = txt.replace(/(^|\W)CARRERA($|\W)/, ' KR ');
    txt = txt.replace(/(^|\W)CR($|\W)/, ' KR ');
    txt = txt.replace(/(^|\W)KRA($|\W)/, ' KR ');
    txt = txt.replace(/(^|\W)CRA($|\W)/, ' KR ');
    txt = txt.replace(/(^|\W)CARRETERA($|\W)/, ' CT ');
    txt = txt.replace(/(^|\W)CASA($|\W)/, ' CS ');
    txt = txt.replace(/(^|\W)CELULA($|\W)/, ' CEL ');
    txt = txt.replace(/(^|\W)CENTRO($|\W)/, ' CEN ');
    txt = txt.replace(/(^|\W)CENTRO ADMINISTRATIVO NACIONAL($|\W)/, ' CAN ');
    txt = txt.replace(/(^|\W)CENTRO COMERCIAL($|\W)/, ' CCO ');
    txt = txt.replace(/(^|\W)CIRCULAR($|\W)/, ' CIRCULAR ');
    txt = txt.replace(/(^|\W)CONJUNTO($|\W)/, ' CONJ ');
    txt = txt.replace(/(^|\W)CONSULTORIO($|\W)/, ' CONS ');
    txt = txt.replace(/(^|\W)DEPOSITO($|\W)/, ' DP ');
    txt = txt.replace(/(^|\W)DIAGONAL($|\W)/, ' DG ');
    txt = txt.replace(/(^|\W)DIAG($|\W)/, ' DG ');
    txt = txt.replace(/(^|\W)EDIFICIO($|\W)/, ' ED ');
    txt = txt.replace(/(^|\W)ENTRADA($|\W)/, ' ENT ');
    txt = txt.replace(/(^|\W)ESQUINA($|\W)/, ' ESQ ');
    txt = txt.replace(/(^|\W)ESTE($|\W)/, ' EST ');
    txt = txt.replace(/(^|\W)ETAPA($|\W)/, ' ET ');
    txt = txt.replace(/(^|\W)GARAGE SOTANO($|\W)/, ' GS ');
    txt = txt.replace(/(^|\W)GARAJE($|\W)/, ' GJ ');
    txt = txt.replace(/(^|\W)INTERIOR($|\W)/, ' INT ');
    txt = txt.replace(/(^|\W)KILOMETRO($|\W)/, ' KM ');
    txt = txt.replace(/(^|\W)LOCAL($|\W)/, ' LC ');
    txt = txt.replace(/(^|\W)LOTE($|\W)/, ' LT ');
    txt = txt.replace(/(^|\W)MANZANA($|\W)/, ' MZ ');
    txt = txt.replace(/(^|\W)MEZZANINE($|\W)/, ' MEZZ ');
    txt = txt.replace(/(^|\W)MODULO($|\W)/, ' MOD ');
    txt = txt.replace(/(^|\W)MUNICIPIO($|\W)/, ' MCP ');
    txt = txt.replace(/(^|\W)NO($|\W)/, ' ');
    txt = txt.replace(/(^|\W)NO.($|\W)/, ' ');
    txt = txt.replace(/(^|\W)NORTE($|\W)/, ' NTE ');
    txt = txt.replace(/(^|\W)OCCIDENTE($|\W)/, ' OCC ');
    txt = txt.replace(/(^|\W)OESTE($|\W)/, ' OE ');
    txt = txt.replace(/(^|\W)OFICINA($|\W)/, ' OF ');
    txt = txt.replace(/(^|\W)PARCELA($|\W)/, ' PA ');
    txt = txt.replace(/(^|\W)PASEO($|\W)/, ' PASEO ');
    txt = txt.replace(/(^|\W)PENTHOUSE($|\W)/, ' PH ');
    txt = txt.replace(/(^|\W)PISO($|\W)/, ' PI ');
    txt = txt.replace(/(^|\W)PREDIO($|\W)/, ' PD ');
    txt = txt.replace(/(^|\W)PUENTE($|\W)/, ' PTE ');
    txt = txt.replace(/(^|\W)PUESTO($|\W)/, ' PTO ');
    txt = txt.replace(/(^|\W)SALON COMUNAL($|\W)/, ' SC ');
    txt = txt.replace(/(^|\W)SECTOR($|\W)/, ' SECT ');
    txt = txt.replace(/(^|\W)SEMISOTANO($|\W)/, ' SS ');
    txt = txt.replace(/(^|\W)SOLAR($|\W)/, ' SL ');
    txt = txt.replace(/(^|\W)SOTANO($|\W)/, ' ST ');
    txt = txt.replace(/(^|\W)SUPERMANZANA($|\W)/, ' SPMZ ');
    txt = txt.replace(/(^|\W)SUR($|\W)/, ' SUR ');
    txt = txt.replace(/(^|\W)TORRE($|\W)/, ' TRR ');
    txt = txt.replace(/(^|\W)TRANSVERSAL($|\W)/, ' TV ');
    txt = txt.replace(/(^|\W)UNIDAD($|\W)/, ' UN ');
    txt = txt.replace(/(^|\W)UNIDAD RESIDENCIAL($|\W)/, ' UR ');
    txt = txt.replace(/(^|\W)URBANIZACION($|\W)/, ' URB ');
    txt = txt.replace(/(^|\W)VEREDA($|\W)/, ' VEREDA ');
    txt = txt.replace(/(^|\W)VIA($|\W)/, ' VIA ');
    txt = txt.replace(/(^|\W)ZONA($|\W)/, ' ZN ');

    return txt;
  }
}
