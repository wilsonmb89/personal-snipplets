export function filtrarCatalogo(value: string, lista: any[], campoBusqueda: string, numberOfSearch: number = 0) {
    if (value) {
        const filterValue = value.toLowerCase();
        if (value.length > numberOfSearch && !!lista) {
            return lista.filter(option => {
                const arregloBusqueda = campoBusqueda.split('|');
                for (const entry of arregloBusqueda) {
                    if (option[entry].toLowerCase().includes(filterValue)) {
                        return true;
                    }
                }
                return false;
            });
        }
        return [];
    }
}

export function filtrarCatalogoCiiu(value: string, lista: any[], campoBusqueda: string, numberOfSearch: number = 0) {
    if (value) {
        const filterValue = value.toLowerCase();
        if (value.length > numberOfSearch && !!lista) {
            return lista.filter(option => {
                const arregloBusqueda = campoBusqueda.split('|');
                for (const entry of arregloBusqueda) {
                    if (option[entry].toLowerCase() === filterValue) {
                        return true;
                    }
                }
                return false;
            });
        }
        return [];
    }
}