import * as forge from "node-forge";

export class Encryption {
  private iv: any;
  private publicBackKey: any;
  private key: any;
  private cipher;
  private decipher;
  private decrypted;
  private encrypted: any;

  generateKeys() {
    this.key = forge.util.encode64(forge.random.getBytesSync(16));
    sessionStorage.setItem("privateKey", this.key);
    console.log("LLAVE PRIVADA");
    console.log(sessionStorage.getItem("privateKey"));
    forge.options.usePureJavaScript = true;
    this.publicBackKey = forge.pki.publicKeyFromPem(
      "-----BEGIN RSA PUBLIC KEY-----" +
        sessionStorage.getItem("publicKeyBack") +
        "-----END RSA PUBLIC KEY-----"
    );
    this.encrypted = this.publicBackKey.encrypt(this.key);
    console.log("LLAVE ENCRIPTADA AES");
    console.log(forge.util.encode64(this.encrypted));
    sessionStorage.setItem("frontKey", forge.util.encode64(this.encrypted));
  }

  encrypt(value) {
    console.log("LLAVE METODO");
    console.log(sessionStorage.getItem("privateKey"));
    this.cipher = forge.cipher.createCipher(
      "AES-ECB",
      sessionStorage.getItem("privateKey")
    );
    this.cipher.start();
    this.cipher.update(forge.util.createBuffer(value, 'utf8'));
    this.cipher.finish();
    this.encrypted = this.cipher.output;
    console.log("BODY SIN ENCRIPTAR");
    console.log(this.encrypted.data);
    console.log("BODY ENCRIPTADO");
    console.log(forge.util.encode64(this.encrypted.data));
    this.encrypted = forge.util.encode64(this.encrypted.data);
    return this.encrypted;
  }

  desencrypt(value) {
    value = forge.util.decode64(value);
    console.log("PRIVATE KEY");
    console.log(sessionStorage.getItem("privateKey"));
    this.decipher = forge.cipher.createDecipher(
      "AES-ECB",
      sessionStorage.getItem("privateKey")
    );
    this.decipher.start();
    this.decipher.update(forge.util.createBuffer(value));
    this.decipher.finish();
    this.decrypted = this.decipher.output.data;
    console.log("DESENCRIPCION");
    const str = forge.util.decodeUtf8(this.decrypted.toString());
    try {
      return JSON.parse(str);
    } catch (error) {
      console.error(error);
      return str;
    }
  }

  storePublickKey(publickKey) {
    console.log("LLAVE PUBLICA");
    console.log(publickKey);
    sessionStorage.setItem("publicKeyBack", publickKey);
    console.log(sessionStorage.getItem("publicKeyBack"));
  }
}

