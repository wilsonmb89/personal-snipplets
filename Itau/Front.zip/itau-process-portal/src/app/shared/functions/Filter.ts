export function filtrarCatalogo(value: string, lista: any[], campoBusqueda: string) {
    if (value) {
        const filterValue = value.toLowerCase();
        if (value.length > 0 && !!lista) {
            return lista.filter(option => {
                const arregloBusqueda = campoBusqueda.split('|');
                for (const entry of arregloBusqueda) {
                    if (option[entry].toLowerCase().includes(filterValue)) {
                        return true;
                    }
                }
                return false;
            });
        }
        return [];
    }
}
