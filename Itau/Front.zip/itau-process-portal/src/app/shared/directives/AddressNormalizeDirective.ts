import { ValidAddress } from './../functions/util/validations/ValidAddress';
import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[addressNormalize]'
})
export class AddressNormalizeDirective {
    public validAddress = new ValidAddress();

    constructor(private _el: ElementRef) { }

    @HostListener('blur', ['$event']) onblur(event) {
        const initalValue = this._el.nativeElement.value;

        this._el.nativeElement.value = this.validAddress.validacionDireccion(initalValue);

        if (initalValue !== this._el.nativeElement.value) {
            event.stopPropagation();
        }
    }
}
