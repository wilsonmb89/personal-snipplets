import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[capitalizeOnlyFirstLetter]'
})
export class CapitalizeOnlyFirstLetterDirective {

    constructor(private _el: ElementRef) { }

    @HostListener('blur', ['$event']) onblur(event) {
        const initalValue = this._el.nativeElement.value;
        this._el.nativeElement.value = initalValue.charAt(0).toUpperCase() + initalValue.slice(1);
    }
}
