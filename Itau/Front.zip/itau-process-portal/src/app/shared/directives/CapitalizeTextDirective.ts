import { Directive, ElementRef, HostListener } from '@angular/core';
import { CapitalizeTextPipe } from '../pipes/capitalize-text.pipe';

@Directive({
    selector: '[capitalizeText]'
})
export class CapitalizeTextDirective {
    public _titlecasePipe = new CapitalizeTextPipe();

    constructor(private _el: ElementRef) { }

    @HostListener('blur', ['$event']) onblur(event) {
        const initalValue = this._el.nativeElement.value;

        this._el.nativeElement.value = this._titlecasePipe.transform(initalValue);

        if (initalValue !== this._el.nativeElement.value) {
            event.stopPropagation();
        }
    }
}
