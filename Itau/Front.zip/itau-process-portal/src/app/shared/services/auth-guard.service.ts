import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

@Injectable()

export class AuthGuardService implements CanActivate {

    constructor(
        public router: Router
    ) {}

    canActivate(): boolean {
        let activateResponse = false;
        if (!!sessionStorage.getItem("token")) {
            activateResponse = true;
        } else {
            this.router.navigate(["portal/login"]);
        }
        return activateResponse;
    }
}
