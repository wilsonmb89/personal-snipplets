import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse
} from '@angular/common/http';
import { Encryption } from '../functions/encryption';
import { map } from 'rxjs/operators';

@Injectable()
export class EncryptInterceptorService implements HttpInterceptor {

    constructor(private _encryption: Encryption) {
    }

    intercept(req: HttpRequest<any>, next: HttpHandler) {

        if (!sessionStorage.getItem("frontKey")) {
            return next.handle(req);
        }
        req = req.clone({ headers: req.headers.set('FrontKey', `${sessionStorage.getItem("frontKey")}`) });
        req = req.clone({ body: this._encryption.encrypt(JSON.stringify(req.body)) });
        console.log(req);

        return next.handle(req).pipe(map((event: HttpEvent<any>) => {
            try {
                if (event instanceof HttpResponse) {
                    console.log(event);
                    let copyBody;
                    let decriptedBody;
                    const body = !!event.body.body ? event.body.body : event.body;

                    decriptedBody = this._encryption.desencrypt(body);
                    copyBody = event.clone().body;
                    copyBody.body = decriptedBody;
                    event = event.clone({body: copyBody});
                    console.log(event);
                }
                return event;
            } catch (error) {
                console.error("Error en " + req.url);
                console.error(error);
                return event;
            }
        }));
  }
}
