import { Injectable } from "@angular/core";

@Injectable()
export class IndexedDBService {

    private db: IDBDatabase;
    private DATABASE_NAME = "BPM_DB";
    private OBJECT_STORE_NAME = "bpmData";

    constructor() {}

    /**
     * Metodo para crear la base de datos en el navegador con un object store
     * que almacena la data entre proyectos de angular
     */
    createDatabase(): Promise<any> {
        const result = new Promise((resolve, reject) => {
            const req = window.indexedDB.open(this.DATABASE_NAME, 1);
            req.onsuccess = evt => {
                this.db = req.result;
                if (!!this.db) {
                    this.db.onerror = (event: any) => {
                        reject("Database error: " + event.target.error.message);
                    };
                    resolve(req.result);
                }
            };
            req.onerror = ext => {
                reject("Error creando DB");
            };
            req.onupgradeneeded = (event: any) => {
                const db = event.target.result;
                const objectStore = db.createObjectStore(this.OBJECT_STORE_NAME);
                objectStore.createIndex(this.OBJECT_STORE_NAME, this.OBJECT_STORE_NAME, { unique: false });
            };
        });
        return result;
    }

    /**
     * Metodo que obtiene una transaccion que permite realiza una operacion CRUD
     */
    getTransaction() {
        return this.db.transaction([this.OBJECT_STORE_NAME], "readwrite").objectStore(this.OBJECT_STORE_NAME);
    }

    /**
     * Metodo que inserta un registro en la base de datos
     * @param data
     * @param dataKey
     */
    addData(data: string, dataKey?): Promise<any> {
        const result = new Promise(async (resolve, reject) => {
            try {
                if (!(!!this.db)) {
                    await this.createDatabase();
                }
                dataKey = !!dataKey ? dataKey : this.getDateKey();
                const reqAdd = await this.getTransaction().add({bpmData: data}, dataKey);
                reqAdd.onsuccess = (evt) => {
                    resolve(reqAdd.result);
                };
                reqAdd.onerror = (evt: any) => {
                    reject(evt.target.error.message);
                };
            } catch (e) {
                reject("Error in addData: " + e);
            }
        });
        return result;
    }

    /**
     * Metodo que obtiene un registro de acuerdo a una llave
     * @param dataKey
     */
    getKey(dataKey): Promise<any> {
        const result = new Promise(async (resolve, reject) => {
            try {
                if (!(!!this.db)) {
                    await this.createDatabase();
                }
                const reqGetKey = this.getTransaction().get(dataKey);
                reqGetKey.onsuccess = (evt) => {
                    resolve(reqGetKey.result);
                };
                reqGetKey.onerror = (evt: any) => {
                    reject(evt.target.error.message);
                };
            } catch (e) {
                reject("Error in getKey: " + e);
            }
        });
        return result;
    }

    /**
     * Metodo que elimina un registro de acuerdo a una llave
     * @param dataKey
     */
    deleteKey(dataKey): Promise<any> {
        const result = new Promise(async (resolve, reject) => {
            try {
                if (!(!!this.db)) {
                    await this.createDatabase();
                }
                const reqDelete = this.getTransaction().delete(dataKey);
                reqDelete.onsuccess = (evt) => {
                    resolve(reqDelete.result);
                };
                reqDelete.onerror = (evt: any) => {
                    reject(evt.target.error.message);
                };
            } catch (e) {
                reject("Error in deleteKey: " + e);
            }
        });
        return result;
    }

    /**
     * Metodo que limpia los registros de la base de datos
     */
    clearBD(): Promise<any> {
        const result = new Promise(async (resolve, reject) => {
            try {
                if (!(!!this.db)) {
                    await this.createDatabase();
                }
                const reqClear = this.getTransaction().clear();
                reqClear.onsuccess = (evt) => {
                    resolve(reqClear.result);
                };
                reqClear.onerror = (evt: any) => {
                    reject(evt.target.error.message);
                };
            } catch (e) {
                reject("Error in deleteKey: " + e);
            }
        });
        return result;
    }

    /**
     * Metodo que actualiza un registro en la base de datos
     * @param dataKey
     * @param dataUpdate
     */
    updateKey(dataKey, dataUpdate: string): Promise<any> {
        const result = new Promise(async (resolve, reject) => {
            try {
                if (!(!!this.db)) {
                    await this.createDatabase();
                }
                const objectStore = this.getTransaction();
                const reqFind = objectStore.get(dataKey);
                reqFind.onsuccess = (evt) => {
                    const data = reqFind.result;
                    data.bpmData = dataUpdate;
                    const reqUpdate = objectStore.put(data, dataKey);
                    reqUpdate.onsuccess = (evt) => {
                        resolve(reqUpdate.result);
                    };
                    reqUpdate.onerror = (evt: any) => {
                        reject(evt.target.error.message);
                    };
                };
                reqFind.onerror = (evt: any) => {
                    reject(evt.target.error.message);
                };
            } catch (e) {
                reject("Error in updateKey: " + e);
            }
        });
        return result;
    }

    /**
     * Metodo para retornar una llave segun la fecha
     */
    getDateKey(): number {
        return new Date().valueOf();
    }

    /**
     * Metodo que obtiene todos los registros almacenados en la base de datos
     */
    getAll(): Promise<any> {
        const result = new Promise(async (resolve, reject) => {
            try {
                if (!(!!this.db)) {
                    await this.createDatabase();
                }
                const reqGetAll = this.getTransaction().getAll();
                reqGetAll.onsuccess = (evt) => {
                    resolve(reqGetAll.result);
                };
                reqGetAll.onerror = (evt: any) => {
                    reject(evt.target.error.message);
                };
            } catch (e) {
                reject("Error in getAll: " + e);
            }
        });
        return result;
    }
}
