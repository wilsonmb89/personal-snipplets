import { BpmService } from "./bpm.service";
import { Injectable } from "@angular/core";
import { Task } from "../models/bpm/Task";

import { Router } from "@angular/router";

@Injectable()
export class AutoflowService {
  public TIME_TASK_AUTOFLOW = 15000;
  tasksList: Task[] = [];
  dataTask: any;
  private nameUrl: any;
  stop: boolean;

  constructor(private bpmService: BpmService, public router: Router) {}

  nextPage(instaceId) {
    console.log("Entra al autoflow");
    const promise = new Promise(this.promesaAutoflow.bind(this, instaceId));
    this.stop = false;
    promise.then(
      this.saveReclaimTaksInfo.bind(this),
      this.timeOutAutoflow.bind(this)
    );
  }

  promesaAutoflow(instanceId, resolve, reject) {
    console.log("Entra a la promesa");
    console.log(this.router);

    setTimeout(() => {
      console.log("Entra al timeout");
      console.log(this.router);
      reject("rechazado timeout");
    }, this.TIME_TASK_AUTOFLOW);

    setTimeout(() => {
      console.log("reintenta la funcion de buscar tarea");
      this.buscarSiguienteTarea(instanceId, resolve);
    }, 300);
  }

  timeOutAutoflow(error) {
    this.router.navigate(["portal/bandeja-tareas"]);
  }

  buscarSiguienteTarea(instanceId, resolve) {
    console.log("Entra a buscar tarea");
    this.bpmService.getActiveTasks().then(
      response => {
        const res = response.body.data.items;
        this.tasksList = res;
        console.log(this.tasksList);
        console.log("Va ejecutar el find");
        // Ajustar siempre que se hagan mas cosas sobre las actividades // prioridades, duedates etc.
        this.dataTask = this.tasksList.find(task => task.PI_PIID === instanceId && !!task.TAD_DESCRIPTION);
        if (this.dataTask) {
          console.log("DATA TASK");
          console.log(this.dataTask);
          resolve(instanceId);
        } else {
          setTimeout(() => {
            this.buscarSiguienteTarea(instanceId, resolve);
          }, 300);
        }
      },
      err => {
        setTimeout(() => {
          this.buscarSiguienteTarea(instanceId, resolve);
        }, 300);
      }
    );
  }

  saveReclaimTaksInfo(instaceId) {
    this.nameUrl = this.dataTask.TAD_DISPLAY_NAME;
    sessionStorage.setItem("taskId", this.dataTask.TKIID);
    this.reclaimTask(sessionStorage.getItem("taskId"), instaceId, this.nameUrl);
  }

  reclaimTask(taskId: string, instanceId: string, nameUrl: string) {
    sessionStorage.setItem("taskId", taskId);
    sessionStorage.setItem("instanceId", instanceId);
    this.bpmService.reclaimTask(taskId).then(result => {
      console.log("Inbox: Respuesta Asignar Tarea");
      console.log(result);
      const datosFlujo = result.body.body.data.data.variables.datosFlujo;
      if (!!datosFlujo) {
        delete datosFlujo["@metadata"];
      }
      sessionStorage.setItem("datosFlujo", JSON.stringify(datosFlujo));

      switch (nameUrl) {
        case "Asignar Venta":
          this.router.navigate(["crearProductos/asignar-venta"]);
          break;
        case "Consultar Cliente":
          this.router.navigate(["crearProductos/consultar-cliente"]);
          break;
        case "Validar Concepto Cumplimiento":
          this.router.navigate(["crearProductos/listas-restrictivas"]);
          break;
        case "Vincular Actualizar Cliente":
          this.router.navigate(["crearProductos/vincular-actualizar-cliente"]);
          break;
        case "Notificar Rechazo Cliente":
          this.router.navigate(["crearProductos/notificar-cliente"]);
          break;
        case "Emitir Concepto Comercial":
          this.router.navigate(["crearProductos/emitir-concepto-comercial"]);
          break;
        case "Notificar Concepto Comercial":
          this.router.navigate(["crearProductos/notificar-concepto-comercial"]);
          break;
        case "Iniciar Negociacion Cliente":
          this.router.navigate(["cliente360/iniciar-negociacion-cliente"]);
          break;
        case "Caracterizar producto":
          this.router.navigate(["crearProductos/crear-productos"]);
          break;
        case "Verificar Operacion":
            this.router.navigate(["crearProductos/verificar-documentos"]);
            break;
        case "Corregir Operacion":
            this.router.navigate(["crearProductos/documentos-rechazados"]);
            break;
        default:
          break;
      }
    });
  }
}
