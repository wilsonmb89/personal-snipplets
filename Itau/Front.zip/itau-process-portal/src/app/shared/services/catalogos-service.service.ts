import { Injectable } from '@angular/core';
import { HttpClientService } from './HttpClient.service';
import { PATH_DB } from '../../shared/constants/servicePath.constant';
import { Catalogo } from '../../shared/models/catalogo/catalogo';

@Injectable()
export class CatalogosServiceService {

  constructor(
    public _httpClientService: HttpClientService
    ) {
  }

  loadCatalog( catalogType: string ) {
    return this._httpClientService.invokeGetRequest(PATH_DB.CATALOGOS.concat('params?tipoCatalogo=').concat(catalogType));
  }

  loadCatalogOffice( catalogType: string ) {
    return this._httpClientService.invokeGetRequest(PATH_DB.CATALOGOS.concat('params?tipoCatalogo=').concat(catalogType));
  }

  clearCatalogo( catalogType: string ) {
    return this._httpClientService.invokeGetRequest(PATH_DB.CATALOGOS.concat('deleteCatalogo?tipoCatalogo=').concat(catalogType));
  }

  insertCatalogo(catalogoBody) {
    return this._httpClientService.invokePostRequest(PATH_DB.CATALOGOS.concat('insertCatalogo'), catalogoBody);
  }

}
