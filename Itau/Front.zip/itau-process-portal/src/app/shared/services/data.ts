import { Injectable } from '@angular/core';

@Injectable()
export class DataInjectProvider {
    public storage: any;
    public constructor() {}
}
