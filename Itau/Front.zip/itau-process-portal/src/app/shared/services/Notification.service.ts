import { Injectable } from "@angular/core";
import { HttpClientService } from './HttpClient.service';
import { PATH_SERVICIOS_LEGADOS } from "../constants/servicePath.constant";

@Injectable()
export class NotificationService {

  constructor(public _httpClientService: HttpClientService) {}

  sendEmailNotification(body) {
    return this._httpClientService.invokePostRequest(PATH_SERVICIOS_LEGADOS.NOTIFICATION_SEND_EMAIL, body);
  }

  sendMessageNotification(body) {
    return this._httpClientService.invokePostRequest(PATH_SERVICIOS_LEGADOS.NOTIFICATION_SEND_SMS, body);
  }
}

