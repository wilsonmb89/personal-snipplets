import { Injectable } from "@angular/core";
import { HttpClientService } from './HttpClient.service';
import { PATH_API } from "../constants/servicePath.constant";

@Injectable()
export class EventService {

  constructor(public _httpClientService: HttpClientService) {}

  sendEvent(body) {
    return this._httpClientService.invokePostRequest(PATH_API.EVENTOS, body);
  }
}
