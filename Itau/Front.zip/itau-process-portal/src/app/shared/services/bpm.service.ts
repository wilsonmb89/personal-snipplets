import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { IniciarProceso } from '../models/request/IniciarProceso';
import { FinalizarTarea } from '../models/request/FinalizarTarea';
import { HttpClientService } from './HttpClient.service';
import { PATH_BPM_REST } from '../constants/servicePath.constant';
import { IniciarServicio } from '../models/bpm/iniciarServicio';

@Injectable()
export class BpmService {
  public iniciarProceso: IniciarProceso;
  public tkiid: string;
  public finalizarTarea: FinalizarTarea;
  constructor(
    public _httpClientService: HttpClientService
    ) {
  }

  getAllExposed() {
    return this._httpClientService.invokeGetRequest(PATH_BPM_REST.GET_ALL_EXPOSED);
  }
  createProcessByObj(metaData: any) {
    if (!!metaData) {
      // const body = JSON.stringify(metaData);
      return this._httpClientService.invokePostRequest(PATH_BPM_REST.CREATE_INSTANCE, metaData);
    } else {
      return null;
    }
  }

  reclaimTask(tkiid: string) {
    return this._httpClientService.invokePutRequest(PATH_BPM_REST.RECLAIM_TASK, tkiid);
  }

  endTask(finalizarTarea: FinalizarTarea) {
    return this._httpClientService.invokePutRequest(PATH_BPM_REST.FINISH_TASK, finalizarTarea);
  }

  endTaskWaitNextTask(finalizarTarea: FinalizarTarea) {
    return this._httpClientService.invokePutRequest(PATH_BPM_REST.FINISH_TASK, finalizarTarea);
  }

  getBulkInstance(piid: string) {
    return this._httpClientService.invokeGetRequest(PATH_BPM_REST.BULK_INSTANCE_ID + piid);
  }

  getActiveTasks() {
    return this._httpClientService.invokeGetRequest(PATH_BPM_REST.GET_ACTIVE_TASKS, {}, true);
  }

  getOwnerTask() {
    return this._httpClientService.invokeGetRequest(PATH_BPM_REST.GET_OWNER_TASK, {}, true);
  }

  getTaskSummary(piid: string) {
    return this._httpClientService.invokeGetRequest(PATH_BPM_REST.GET_TASK_SUMMARY + piid);
  }

  getUserDetails(userName: string) {
    return this._httpClientService.invokeGetRequest(PATH_BPM_REST.GET_USER_DETAILS + userName);
  }

  startService(iniciarServicio: IniciarServicio) {
    return this._httpClientService.invokePostRequest(PATH_BPM_REST.START_SERVICE, iniciarServicio);
  }

}
