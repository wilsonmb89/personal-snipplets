import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';

@Injectable()
export class InterceptorService implements HttpInterceptor {

    intercept(req: HttpRequest<any>, next: HttpHandler) {
      if (!!sessionStorage.getItem("token")) {
        req = req.clone({ headers: req.headers.set('Authorization', `Bearer ${sessionStorage.getItem("token")}`) });
      }

      if (!req.headers.has('Content-Type')) {
        req = req.clone({ headers: req.headers.set('Content-Type', 'application/json') });
      }

      return next.handle(req);
  }
}
