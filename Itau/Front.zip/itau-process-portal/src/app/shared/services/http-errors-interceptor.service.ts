import { Injectable } from "@angular/core";
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
} from "@angular/common/http";
import { TimerClass } from "../functions/timer";
import { LogOutUtil } from "../functions/logout";
import { Router } from "@angular/router";
import { Observable } from 'rxjs/Rx';
import { tap } from 'rxjs/operators';
import { IndexedDBService } from './indexedDB.service';

@Injectable()
export class HttpErrorInterceptorService implements HttpInterceptor {
  constructor(
    public router: Router,
    public timer: TimerClass,
    private logOutUtil: LogOutUtil,
    private _indexedDBService: IndexedDBService
  ) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(tap(
        (event: any) => {},
        (err: any) => {
        if (err instanceof HttpErrorResponse) {
          if (Number(err.status) === 401) {
            this.logOut();
          }
        }
      })
    );
  }

  private logOut() {
    console.log("Usuario no autorizado. Redirigiendo a login ...");
    if (!!this.timer.getSuscription()) {
      this.timer.getSuscription().unsubscribe();
      this.timer.setSuscription(null);
    }

    if (this.router.url !== "/portal/login") {
      this._indexedDBService.clearBD();
      this.logOutUtil.clearGlobalData();
      this.logOutUtil.removeSessionData();
      this.router.navigate(["portal/login"]);
    }
  }
}
