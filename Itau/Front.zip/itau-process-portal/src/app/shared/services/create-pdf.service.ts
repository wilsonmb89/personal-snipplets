import { Injectable } from "@angular/core";
import { HttpClientService } from './HttpClient.service';
import { PATH_API } from "../../shared/constants/servicePath.constant";

@Injectable()
export class CreatePdfService {

  constructor(
    public _httpClientService: HttpClientService
  ) {
  }

  createPDF(body) {
    return this._httpClientService.invokePostRequest(PATH_API.GENERAR_FORMATO_VENTA, body);
  }

  createXLS(body) {
    return this._httpClientService.invokePostRequest(PATH_API.GENERAR_FORMATO_EXCEL, body);
  }
}
