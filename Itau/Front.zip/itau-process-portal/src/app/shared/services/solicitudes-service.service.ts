import { Injectable } from '@angular/core';
import { HttpClientService } from './HttpClient.service';
import { PATH_DB } from '../../shared/constants/servicePath.constant';

@Injectable()
export class SolicitudesServiceService {

  constructor(
    public _httpClientService: HttpClientService
  ) {
  }

  createOrUpdate(body: any) {
    const repos = this._httpClientService.invokePostRequest(PATH_DB.SOR, body);
    return repos;
  }

  update(body: any) {
    const repos = this._httpClientService.invokePutRequest(PATH_DB.SOR, body);
    return repos;
  }

  getByInstanceId(instanceId) {
    return this._httpClientService.invokeGetRequest(PATH_DB.SOR.concat(instanceId));
  }
}
