import { environment } from "../../../environments/environment";

export const PATH_SERVICIOS_LEGADOS = {
    RESTRICTIVE_LIST_GET_LIST : environment.API_GATEWAY.concat('/cliente/restrictiveLists/getLists'),
    CUSTOMER_ADD_CUSTOMER : environment.API_GATEWAY.concat('/cliente/customer/addCustomer'),
    CUSTOMER_INFORMATION_GET_CUSTOMER_ORQ : environment.API_GATEWAY.concat('/cliente/customerInformation/getCustomerDataOrquestation'),
    EXPERIAN : environment.API_GATEWAY.concat('/scoring/customerIncomeEstimatedV2/getCustomerIncomeEstimated'),
    PRODUCT_ADD_ACCOUNT : environment.API_GATEWAY.concat('/producto/account/addAccount'),
    PRODUCT_GET_ACCOUNT_LIST : environment.API_GATEWAY.concat('/producto/account/getAccountList'),
    NOTIFICATION_SEND_EMAIL : environment.API_GATEWAY.concat('/notification/sendEmailNotification'),
    NOTIFICATION_SEND_SMS : environment.API_GATEWAY.concat('/notification/sendMessageNotification'),
    OBTENER_ESTRUCTURA_COMERCIAL : environment.API_GATEWAY.concat('/orgStructureByUser/getOrgStructure'),
    CUSTOMER_DEBIT_CARD : environment.API_GATEWAY.concat('/producto/customerDebitCardRel/addCustomerDebitCardRel')
};

export const PATH_API = {
    GENERAR_FORMATO_VENTA : environment.API_GATEWAY.concat('/reports/getPDF'),
    GENERAR_FORMATO_EXCEL : environment.API_GATEWAY.concat('/reports/getXLS'),
    EVENTOS : environment.API_GATEWAY.concat('/auditoria/sendMessage'),
    LOGIN : environment.API_GATEWAY.concat('/security/login/loginUser'),
    GETKEY : environment.API_GATEWAY.concat('/security/key/getPublicKey')
};

export const PATH_DB = {
    CATALOGOS : environment.API_GATEWAY.concat('/catalogos/'),
    ODS : environment.API_GATEWAY.concat('/endeudamientoOds/getDataClienteODS/'),
    SOR : environment.API_GATEWAY.concat('/solicitudes/')
};

export const PATH_BPM_REST = {
    GET_ALL_EXPOSED: environment.API_GATEWAY.concat("/bpm/process/getAllExposed"),
    CREATE_INSTANCE: environment.API_GATEWAY.concat("/bpm/process/createInstance"),
    FINISH_TASK: environment.API_GATEWAY.concat("/bpm/task/finishTask"),
    RECLAIM_TASK: environment.API_GATEWAY.concat("/bpm/task/reclaimTask"),
    BULK_INSTANCE_ID: environment.API_GATEWAY.concat("/bpm/process/getBulkInstanceDetails/"),
    GET_ACTIVE_TASKS: environment.API_GATEWAY.concat("/bpm/task/getActiveTasks"),
    GET_OWNER_TASK: environment.API_GATEWAY.concat("/bpm/process/getMyClientProcesses"),
    GET_TASK_SUMMARY: environment.API_GATEWAY.concat("/bpm/process/getTaskSummary/"),
    GET_USER_DETAILS: environment.API_GATEWAY.concat("/bpm/user/getUserDetails/"),
    START_SERVICE : environment.API_GATEWAY.concat("/bpm/service/startService")
};

export const EXTERNAL_PAGES = {
    URL_ADMINFO: "https://201.220.45.182/vsmart/"
};

export const AMBIENTE = {
    version: "V0.1.22"
};

