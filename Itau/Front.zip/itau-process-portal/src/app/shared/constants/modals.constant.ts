export const SERVICE_RESPONSE = {
    imagen: "/crear-producto/assets/images/cliente.svg",
    principalText: "Este cliente requiere validación de cumplimiento",
    button: true,
    buttonText1: "Ok, esperar",
    class: false
};

export const REJECT_AGREEMENT = {
    imagen: "/crear-producto/assets/images/cliente.svg",
    principalText: "Recuerda modificar el convenio de nómina a nivel de cliente",
    buttonAgreement: true,
    buttonText1: "Ok",
    class: false
};

export const ERROR_OPENCARD = {
    imagen: "/crear-producto/assets/images/cliente.svg",
    principalText: "Realice la asociación de la TD directamente en Open Card",
    buttonAgreement: true,
    buttonText1: "Ok",
    class: false
};

export const REJECT_USER = {
    imagen: "/crear-producto/assets/images/no-apto.svg",
    principalText: "Notificación de rechazo",
    secondaryText: "Cristina Montoya C.C. 46789012",
    otherText: "No es un cliente apto para vincular.",
    buttonPdf: false,
    button: false,
    buttonCloseProcess: true,
    buttonText1: "Cerrar proceso",
    class: true
};

export const GENERATE_PDF = {
    imagen: "/crear-producto/assets/images/cliente-verde.svg",
    principalText: "Adriana Rodríguez C.C. 12345679",
    secondaryText: "Se ha creado como cliente",
    button: false,
    buttonPdf: true,
    buttonText1: "Generar PDF",
    buttonText2: "¡Listo!",
    class: false
};

export const NOTIFICAR_CONCEPTO = {
    imagen: "/crear-producto/assets/images/cliente-verde.svg",
    secondaryText: "Adriana Rodríguez C.C. 12345679",
    otherText: "Fue Validado por Director Comercial. PEP PRP MRP",
    buttonText1: "¡Listo!",
    buttonClose: true,
    genericEndTaskButton: true,
    button: false,
    buttonPdf: false,
    buttonCloseProcess: false,
    class: false
};

export const CREATE_PROCESS = {
    imagen: "/crear-producto/assets/images/seleccion_prod.svg",
    buttonText1: "Crear productos",
    selectProduct: true,
    class: false
};

export const SUPPORT = {
    imagen: "/crear-producto/assets/images/telefono.svg",
    principalText: "Comunícate con la mesa de ayuda operativa, no se ha podido realizar la vinculación",
    buttonText1: "¡Listo!",
    support: true,
    class: false
};
