import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-loading-modal',
  templateUrl: './loading-modal.component.html',
  styleUrls: ['./loading-modal.component.scss']
})
export class LoadingModalComponent implements OnInit {

  @Input() dataLoading: any;

  constructor() { }

  ngOnInit() {
  }

}
