import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Router } from "@angular/router";
import { TimerClass } from "../../functions/timer";
import { LogOutUtil } from '../../functions/logout';
import { IndexedDBService } from '../../services/indexedDB.service';
import { AppComponent } from '../../../app.component';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss']
})
export class LogoutComponent implements OnInit, OnDestroy {

  public OPERACION_EXITOSA_LOGOUT = 200;
  public isLoadingActive = false;
  isSticky = false;

  constructor(
    private router: Router,
    private timer: TimerClass,
    private logOutUtil: LogOutUtil,
    private _indexedDBService: IndexedDBService,
    private app: AppComponent,
  ) { }

  public global = {

    showHeader: false,
    nombre: '',
    id: '',
    showId: false,
    profileImage: '',
    showLogOut: false
  };

  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    if (this.app.global.scrollHide) {
      this.isSticky = window.pageYOffset >= 20;
    } else {
      this.isSticky = false;
    }
  }
  ngOnInit() {
  }

  ngOnDestroy() {
    this.logOutUtil.removeSessionData();
    this._indexedDBService.clearBD();
  }

  cerrarSesion(): void {
    if (!!this.timer.getSuscription()) {
      this.timer.getSuscription().unsubscribe();
      this.timer.setSuscription(null);
    }

    this.isLoadingActive = true;
    this._indexedDBService.clearBD();

    this.logOutUtil.clearGlobalData();
    this.logOutUtil.removeSessionData();
    this.router.navigate(["/portal/login"]);

    this.isLoadingActive = false;

  }

}
