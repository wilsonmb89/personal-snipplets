import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { Task } from "../../../shared/models/bpm/Task";
import { Router } from "@angular/router";
import { BpmService } from "../../services/bpm.service";
import { TimerClass } from "../../../shared/functions/timer";
import { Observable } from "rxjs/Rx";
import { FormControl, FormGroup } from "@angular/forms";
import { filtrarCatalogo } from "../../../shared/functions/util/Filter";
import { PaginationService } from "../../services/pagination.service";
import { Transformation } from "../../../shared/functions/util/Trasnformation";

@Component({
  selector: "app-search-container",
  templateUrl: "./search-container.component.html",
  styleUrls: ["./search-container.component.scss"]
})
export class SearchContainerComponent implements OnInit {
  /* variales para la mostrar las tareas activas */
  tasksList: any[] = [];
  taskItemsShow: any = 5;
  tasksListOrigin: Task[] = [];
  taskListDuplicate: Array<any> = [];
  @Input() instaceId: string;
  @Input() taskId: string;
  @Output() activeLoading: EventEmitter<boolean> = new EventEmitter<boolean>();
  filterTaskList: Observable<any[]>;
  public searchForm: FormGroup;
  resultList: Task[] = [];
  showOriginTaskList = false;
  oldestInitial = false;
  oldestSearch = false;
  pageSelected = 1;

  // pager object
  pager: any = {};
  pagerSearch: any = {};

  // paged items
  pagedItemsInitial: any[];
  pagedItemsSearch: any[];
  collapseContainerTask = false;

  // util functions
  public transformation: Transformation;

  constructor(
    private bpmService: BpmService,
    private router: Router,
    private timer: TimerClass,
    private _pagination: PaginationService
  ) {}

  ngOnInit() {
    /* Contador para refrescar automáticamente a lista*/
    if (this.timer.getSuscription()) {
      this.timer.getSuscription().unsubscribe();
      this.timer.setSuscription(null);
    }
    const subcriptor = this.timer
      .getMyObservable()
      .timer(0, 30000)
      .subscribe(x => {
        console.log(x);
        this.consultProcess();
      });
    this.timer.setSuscription(subcriptor);

    /* Se inician variables para la busqueda */
    this.searchForm = new FormGroup({
      termino: new FormControl("")
    });
    this.showOriginTaskList = true;

    this.transformation = new Transformation();
  }

  /* Metodo para cargar y refrescar la lista de tareas activas */
  async consultProcess() {
    this.bpmService.getActiveTasks().then(response => {
      const res = response.body.data.items;
      this.tasksList = res;
      this.tasksList = this.transformation.orderActiveTaskByDate(
        this.tasksList
      );
      if (this.oldestInitial) {
        this.tasksList.reverse();
      }
      this.setPageInitial(this.pageSelected);
      this.refreshList(res);
    });
  }

  /* Metodo para realizar la busqueda de las tareas activas */
  searchTask(value: string) {
    /* this.resultList = []; */
    if (this.tasksList.length !== 0 && value.length > 1) {
      console.log("array filtrado");
      console.log(this.tasksList);
      this.resultList = filtrarCatalogo(
        value,
        this.tasksList,
        "PROCESS_INSTANCE.PIID|TAD_DESCRIPTION", 0
      );
      this.setPageSearch(this.pageSelected);
      console.log(this.resultList);
      this.showOriginTaskList = false;
    } else {
      this.showOriginTaskList = true;
    }
  }

  /* Método para reclamar una tarea */
  reclaimTask(taskId: string, instanceId: string, nameUrl: string, startDate: string) {
    sessionStorage.setItem("startDate", startDate);
    sessionStorage.setItem("taskId", taskId);
    sessionStorage.setItem("instanceId", instanceId);
    this.activeLoading.emit(true);
    this.bpmService.reclaimTask(taskId).then(
      result => {
        console.log("Inbox: Respuesta Asignar Tarea");
        console.log(result);
        const datosFlujo = result.body.body.data.data.variables.datosFlujo;
        if (!!datosFlujo) {
          delete datosFlujo["@metadata"];
        }
        sessionStorage.setItem("datosFlujo", JSON.stringify(datosFlujo));
        if (!!nameUrl) {
          this.timer.getSuscription().unsubscribe();
        }
        switch (nameUrl) {
          case "Asignar Venta":
            this.router.navigate(["crearProductos/asignar-venta"]);
            break;
          case "Consultar Cliente":
            this.router.navigate(["crearProductos/consultar-cliente"]);
            break;
          case "Validar Concepto Cumplimiento":
            this.router.navigate(["crearProductos/listas-restrictivas"]);
            break;
          case "Vincular Actualizar Cliente":
            this.router.navigate(["crearProductos/vincular-actualizar-cliente"]);
            break;
          case "Notificar Rechazo Cliente":
            this.router.navigate(["crearProductos/notificar-cliente"]);
            break;
          case "Emitir Concepto Comercial":
            this.router.navigate(["crearProductos/emitir-concepto-comercial"]);
            break;
          case "Notificar Concepto Comercial":
            this.router.navigate(["crearProductos/notificar-concepto-comercial"]);
            break;
          case "Caracterizar producto":
            this.router.navigate(["crearProductos/crear-productos"]);
            break;
          case "Verificar Operacion":
            this.router.navigate(["crearProductos/verificar-documentos"]);
            break;
          case "Corregir Operacion":
            this.router.navigate(["crearProductos/documentos-rechazados"]);
            break;
          default:
            break;
        }
        this.activeLoading.emit(false);
      },
      err => {
        console.log(err);
        this.activeLoading.emit(false);
      }
    );
  }

  /* Método para refrescar la lista */
  refreshList(listResponse: Task[]) {
    if (!(JSON.stringify(this.tasksList) === JSON.stringify(listResponse))) {
      listResponse.forEach(task => {
        this.addToList(task);
      });
    }
  }

  /* Método para agregar tarea a la lista */
  addToList(task: Task) {
    if (
      !(this.tasksList.filter(task => task.tkiid === task.tkiid).length > 0)
    ) {
      this.tasksList.push(task);
    }
  }

  // Paginación
  setPageInitial(page: number, target?: boolean) {
    this.pageSelected = page;
/*     if (this.newest) {
      this.tasksList.reverse();
    } */
    this.pager = this._pagination.getPager(this.tasksList.length, page);
    this.pagedItemsInitial = this.tasksList.slice(
      this.pager.startIndex,
      this.pager.endIndex + 1
    );
    if (target) {
      document
        .getElementById("para-ti")
        .scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }

  /* Método para navegar entre la paginación */
  setPageSearch(page: number, target?: boolean) {
    this.pagedItemsSearch = [];
/*     if (this.newest) {
      this.resultList.reverse();
    } */
    this.pagerSearch = this._pagination.getPager(this.resultList.length, page);
    this.pagedItemsSearch = this.resultList.slice(
      this.pagerSearch.startIndex,
      this.pagerSearch.endIndex + 1
    );
    if (target) {
      document
        .getElementById("para-ti")
        .scrollIntoView({ block: "start", behavior: "auto" });
    }
  }

  /* Metodo para colapsar y expandir los contenedores */
  changeContainerTask() {
    if (this.collapseContainerTask) {
      this.collapseContainerTask = false;
    } else {
      this.collapseContainerTask = true;
    }
  }

  /* Metodo para ordenar la lista */
  oderList(value: boolean) {
     if (value) {
      this.tasksList.reverse();
      this.setPageInitial(this.pageSelected, true);
      this.oldestInitial = !this.oldestInitial;
    } else {
      this.resultList.reverse();
      this.setPageSearch(this.pageSelected, true);
      this.oldestSearch = !this.oldestSearch;
      }
    }
}
