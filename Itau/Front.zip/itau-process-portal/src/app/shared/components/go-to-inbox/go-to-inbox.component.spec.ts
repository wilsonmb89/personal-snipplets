import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GoToInboxComponent } from './go-to-inbox.component';

describe('GoToInboxComponent', () => {
  let component: GoToInboxComponent;
  let fixture: ComponentFixture<GoToInboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GoToInboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoToInboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
