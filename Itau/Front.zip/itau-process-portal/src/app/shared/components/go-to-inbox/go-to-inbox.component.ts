import { Component, OnInit, Input, HostListener } from "@angular/core";
import { Router } from "@angular/router";
import { AppComponent } from '../../../app.component';

@Component({
  selector: "app-go-to-inbox",
  templateUrl: "./go-to-inbox.component.html",
  styleUrls: ["./go-to-inbox.component.scss"]
})
export class GoToInboxComponent implements OnInit {

  public isSticky = false;
  constructor(
      private app: AppComponent,
      private router: Router
    ) {
    }
  @HostListener('window:scroll', ['$event'])
    checkScroll() {
      this.isSticky = window.pageYOffset >= 20;

  }

  ngOnInit() {}

  goToInbox() {
    sessionStorage.removeItem("taskId");
    sessionStorage.removeItem("instanceId");
    this.router.navigate(["portal/bandeja-tareas"]);
    this.app.global.scrollHide = false;
  }
}
