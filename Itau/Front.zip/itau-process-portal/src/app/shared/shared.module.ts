import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Components
import { LoadingModalComponent } from './components/modals/loading-modal/loading-modal.component';
import { GoToInboxComponent } from './components/go-to-inbox/go-to-inbox.component';

// Pipes
import { ItauHomologacionDataPipe } from './pipes/itau-homologacion-data.pipe';

@NgModule({
    imports: [
       CommonModule
    ],
    declarations: [
        LoadingModalComponent,
        GoToInboxComponent,
        ItauHomologacionDataPipe
    ],
    exports: [
        LoadingModalComponent,
        GoToInboxComponent,
        ItauHomologacionDataPipe
    ]

})
export class SharedModule { }
