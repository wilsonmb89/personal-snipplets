import { ItauCurrencyMoneyPipe } from './itau-currency-money.pipe';

describe('ItauCurrencyMoneyPipe', () => {
  it('create an instance', () => {
    const pipe = new ItauCurrencyMoneyPipe();
    expect(pipe).toBeTruthy();
  });
});
