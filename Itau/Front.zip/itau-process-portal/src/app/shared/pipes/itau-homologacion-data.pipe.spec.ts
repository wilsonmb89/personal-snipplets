import { ItauHomologacionDataPipe } from './itau-homologacion-data.pipe';

describe('ItauHomologacionDataPipe', () => {
  it('create an instance', () => {
    const pipe = new ItauHomologacionDataPipe();
    expect(pipe).toBeTruthy();
  });
});
