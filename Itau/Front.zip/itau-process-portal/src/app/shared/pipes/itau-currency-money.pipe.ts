import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'itauCurrencyMoney'
})
export class ItauCurrencyMoneyPipe implements PipeTransform {

  transform(value: any): any {
    let transform = value.toString().replace(/[$.\""]/g, "");
    transform = transform.toString().replace(/(\d)(?=(\d{3})+\b)/g, "$1.");
    return (!!transform ? "$" + transform : "");
  }

  revert(value: any): any {
    return value.toString().replace(/[$.\""]/g, "");
  }
}
