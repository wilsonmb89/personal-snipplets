import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateFormat'
})
export class DateFormatPipe implements PipeTransform {

  transform(value: any, completeMonth: any): any {
    const meses = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC'];
    const mesesCompletos = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    const onlyNumbersRegex = /^\d+$/;
    if (!!value
        && onlyNumbersRegex.test(value)
        && value.length === 8) {
      const formatFechaNacimiento = value.substring(0, 4) + "/" + value.substring(4, 6) + "/" + value.substring(6, 8);
      value = formatFechaNacimiento;
    }
    if (!!value) {
      try {
        const date = new Date(value);
        if (!!completeMonth && completeMonth) {
          return date.getDate() + " de " + mesesCompletos[date.getMonth()] + " " + date.getFullYear();
        } else {
          return date.getDate() + " " + meses[date.getMonth()] + " " + date.getFullYear();
        }
      } catch (e) {
        return "-";
      }
    } else {
      return "-";
    }
  }

}
