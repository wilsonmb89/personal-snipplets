import { AddressNormalizePipe } from './addrees-normalize.pipe';

describe('AddressNormalizePipe', () => {
  it('create an instance', () => {
    const pipe = new AddressNormalizePipe();
    expect(pipe).toBeTruthy();
  });
});
