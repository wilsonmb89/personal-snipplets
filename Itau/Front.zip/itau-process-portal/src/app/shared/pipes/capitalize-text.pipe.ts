import { Pipe, PipeTransform, Renderer, ElementRef } from '@angular/core';

@Pipe({
    name: 'capitalizeText'
})
export class CapitalizeTextPipe implements PipeTransform {
    transform(value: any): any {

        const re = /(^|[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ])(?:([a-záéíóúüñ])|([A-ZÁÉÍÓÚÜÑ]))|([A-ZÁÉÍÓÚÜÑ]+)/gu;
        return value.replace(re,
            (m, caracterPrevio, minuscInicial, mayuscInicial, mayuscIntermedias) => {
                const locale = ['es', 'gl', 'ca', 'pt', 'en'];
                if (mayuscIntermedias) {
                    return mayuscIntermedias.toLocaleLowerCase(locale);
                }
                return caracterPrevio
                    + (minuscInicial ? minuscInicial.toLocaleUpperCase(locale) : mayuscInicial);
            }
        );
    }
}
