import { Pipe, PipeTransform } from '@angular/core';
import { ValidAddress } from './../functions/util/validations/ValidAddress';

@Pipe({
    name: 'addressNormalize'
})
export class AddressNormalizePipe implements PipeTransform {
    public validAddress = new ValidAddress();

    transform(value: any): any {
        return this.validAddress.validacionDireccion(value);
    }

}
