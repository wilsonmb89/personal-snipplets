import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'itauHomologacionData'
})
export class ItauHomologacionDataPipe implements PipeTransform {

  transform(value: any, tipoHom: any): any {
    value = !!value ? value : "";
    let result = value;
    if (tipoHom === "codProds") {
      switch (value) {
        case "36":
          result = "Empleado";
          break;
        case "37":
          result = "Independiente";
          break;
        case "40":
          result = "Hogar";
          break;
        case "41":
          result = "Pensionado";
          break;
        case "39":
          result = "Estudiante";
          break;
      }
    } else if (tipoHom === "sinoHom") {
      switch (value) {
        case "S":
          result = "Si";
          break;
        case "N":
          result = "No";
          break;
      }
    } else if (tipoHom === "dateHom") {
      if (value.length >= 2 && value.length <= 4) {
        result = value.substring(0, 2) + "/" + value.substring(2, value.length);
      } else if (value.length >= 4) {
        result = value.substring(0, 2) + "/" + value.substring(2, 4) + "/" + value.substring(4, value.length);
      }
    } else if (tipoHom === "sexoHom") {
      switch (value) {
        case "M":
          result = "Masculino";
          break;
        case "F":
          result = "Femenino";
          break;
      }
    } else if (tipoHom === "tipoIdentificacion") {
      switch (value) {
        case "1":
          result = "CC";
          break;
        case "2":
          result = "CE";
          break;
        case "9":
          result = "Código de Empleado";
          break;
        case "10":
          result = "Grupo economico";
          break;
        case "11":
          result = "Nit Persona Natural";
          break;
        case "3":
          result = "Número de Identificación Tributario";
          break;
        case "5":
          result = "Pasaporte";
          break;
        case "17":
          result = "Pase Diplomático";
          break;
        case "24":
          result = "Registro Civil";
          break;
        case "7":
          result = "Soc.Ext.Sin Nit en Colombia";
          break;
        case "15":
          result = "Sucursal";
          break;
        case "4":
          result = "TI";
          break;
        }
    } else if (tipoHom === "valorDefecto") {
      result = '-';
    }
    return result;
  }
}
