export class IniciarServicio {
    idService: string;
    parameters: string;
}
