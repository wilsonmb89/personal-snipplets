export interface Task {
  NAME: string;
  PI_DISPLAY_NAME: string;
  TAD_DISPLAY_NAME: string;
  PI_PIID: string;
  TKIID: string;
  ACTIVATED: Date;
  status: string;
  TAD_DESCRIPTION: string;
}

export interface TaskListOrigin {
  NAME: string;
  TAD_DESCRIPTION: string;
}
