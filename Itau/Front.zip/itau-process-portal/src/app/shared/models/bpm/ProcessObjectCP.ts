export class ProcessObjectCP {
    seleccionProductos: boolean;
    numeroSolicitud: string;
    nombreCliente: string;
    numIdentificacion: string;
    desTipoIdentificacion: string;
    documentosAprobados: boolean;
    loginRedSubGerenteOp: string;
    decisionEnrutamiento: string;
}
