export class ProcessObjectVP {
    numeroSolicitud: string;
    nombreCliente: string;
    cumplimientoAprobo: boolean;
    desTipoIdentificacion: string;
    numIdentificacion: string;
    imprimirPDF: boolean;
    decisionEnrutamiento: string;
}
