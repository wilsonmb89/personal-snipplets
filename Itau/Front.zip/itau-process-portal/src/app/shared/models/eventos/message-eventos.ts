export class EventMessage {
    api: string;
    currentTime: string;
    id: string;
    ip: string;
    level: string;
    messageBody: any;
    operation: string;
    user: string;
}
