export class Catalogo {
    llave: string;
    valor: string;
    llavePadre: string;
    valorPadre: string;
    estado: string;
    id: string;
    tipoCatalogo: string;
}
