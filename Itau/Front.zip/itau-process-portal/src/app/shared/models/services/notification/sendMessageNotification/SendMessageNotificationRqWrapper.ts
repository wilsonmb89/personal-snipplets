import { SendMessageNotificationRqType } from './SendMessageNotificationRqType';

export class SendMessageNotificationRqWrapper {
    sendMessageNotificationRqType: SendMessageNotificationRqType;
    datosSMS: any;
    codigoNotificacion: string;
}
