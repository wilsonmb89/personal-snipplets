import { EmailType } from './EmailType';
import { PhoneNumType } from './PhoneNumType';

export class DeliveryInstructionType {
    email: EmailType;
    deliveryMethod: string;
    phoneNum: PhoneNumType;
}
