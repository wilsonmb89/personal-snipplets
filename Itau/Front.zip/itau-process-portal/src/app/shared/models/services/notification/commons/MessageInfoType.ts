export class MessageInfoType {
    originatorName: string;
    originatorType: number;
    systemId: string;
    terminalId: string;
}
