export class PhoneNumType {
    phone: string;
}
