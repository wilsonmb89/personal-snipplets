import { HeaderRequestType } from '../commons/HeaderRequestType';
import { NotificationInfoType } from '../commons/NotificationInfoType';


export class SendMessageNotificationRqType {
    headerRequest: HeaderRequestType;
    notificationInfo: NotificationInfoType;
}
