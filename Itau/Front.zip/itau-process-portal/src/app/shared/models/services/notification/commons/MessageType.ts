export class MessageType {
    from: string;
    subject: string;
}
