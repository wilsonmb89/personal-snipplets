import { SendEMailNotificationRqType } from './SendEMailNotificationRqType';

export class SendEmailNotificationRqWrapper {
    sendEmailNotificationRqType: SendEMailNotificationRqType;
    datosEmail: any;
    codigoNotificacion: string;
}
