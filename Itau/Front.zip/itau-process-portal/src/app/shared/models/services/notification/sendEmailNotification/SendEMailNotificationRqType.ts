import { HeaderRequestType } from '../commons/HeaderRequestType';
import { NotificationInfoType } from '../commons/NotificationInfoType';


export class SendEMailNotificationRqType {
    headerRequest: HeaderRequestType;
    notificationInfo: NotificationInfoType;
}
