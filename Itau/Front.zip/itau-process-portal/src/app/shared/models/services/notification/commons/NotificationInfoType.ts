import { MessageType } from './MessageType';
import { DeliveryInstructionType } from './DeliveryInstructionType';


export class NotificationInfoType {
    message: MessageType;
    deliveryInstruction: DeliveryInstructionType;
}
