export class FinalizarTarea {
    idTask: string;
    parameters: string;
}
