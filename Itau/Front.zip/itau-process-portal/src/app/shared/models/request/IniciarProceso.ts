export interface IniciarProceso {
    idBpd: string;
    idSnapshot: string;
    idBranch: string;
    idAppProcess: string;
    parameters?: string;
}
