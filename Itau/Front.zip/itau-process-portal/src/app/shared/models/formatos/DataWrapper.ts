export class DataWrapper {

    idClase: string;
    dataObjeto: string;

    constructor (idClase_p, dataObjeto_p) {
        this.idClase = idClase_p;
        this.dataObjeto = dataObjeto_p;
    }
}
