import {NgModule} from '@angular/core';
import {MatButtonModule} from '@angular/material';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatIconModule} from '@angular/material/icon';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSelectModule} from '@angular/material/select';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatChipsModule} from '@angular/material/chips';
import {MatStepperModule} from '@angular/material/stepper';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatListModule} from '@angular/material/list';
import {MatCheckboxModule} from '@angular/material/checkbox';

@NgModule({
  imports: [MatCheckboxModule, MatListModule, MatExpansionModule, MatButtonModule, MatProgressBarModule, MatStepperModule, MatChipsModule, MatSlideToggleModule, MatAutocompleteModule, MatGridListModule, MatTooltipModule, MatSelectModule, MatIconModule, MatButtonToggleModule, MatInputModule, MatFormFieldModule, MatNativeDateModule, MatDatepickerModule],
  exports: [MatCheckboxModule, MatListModule, MatExpansionModule, MatButtonModule, MatProgressBarModule, MatStepperModule, MatChipsModule, MatSlideToggleModule, MatAutocompleteModule, MatGridListModule, MatTooltipModule, MatSelectModule, MatIconModule, MatButtonToggleModule, MatInputModule, MatFormFieldModule, MatNativeDateModule, MatDatepickerModule],
})
export class MaterialModule { }
