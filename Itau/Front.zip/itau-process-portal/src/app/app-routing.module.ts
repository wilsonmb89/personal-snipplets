import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'portal', pathMatch: 'full' },
  { path: 'portal', loadChildren: './portal/portal.module#PortalModule' },
  { path: 'cliente360', loadChildren: './cliente-360/cliente-360.module#Cliente360Module' },
  { path: 'crearProductos', loadChildren: './crear-producto/crear-producto.module#CrearProductoModule' }
];
@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule {}
