export const environment = {
    enviroment: "PRE",
    production: false,
    API_GATEWAY: "/api-gateway",
    KIBANA: "/analytics",
    emailAddressCumplimiento: "enrique.cabrera.ext@itau.co,fabian.daza.ext@itau.co"
};
