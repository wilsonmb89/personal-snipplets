export const environment = {
    enviroment: "PROD",
    production: true,
    API_GATEWAY: "/api-gateway",
    KIBANA: "/analytics",
    emailAddressCumplimiento: "finscan@itau.co"
};

